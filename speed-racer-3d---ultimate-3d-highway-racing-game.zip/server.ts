import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface OnlinePlayer {
  id: string;
  name: string;
  carId: string;
  carColor: string;
  x: number;
  z: number;
  speed: number;
  distance: number;
  nitro: boolean;
  ws: WebSocket;
  lastUpdate: number;
}

interface RaceRoom {
  id: string;
  players: Map<string, OnlinePlayer>;
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Data directory for persistent messages storage
  const DATA_DIR = path.resolve(__dirname, 'data');
  const MESSAGES_FILE = path.join(DATA_DIR, 'contact_messages.json');

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  // Functional Contact Form Submission API
  app.post('/api/contact', (req, res) => {
    try {
      const { name, email, category, message } = req.body;

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Please provide your name or driver callsign.',
        });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(email.trim())) {
        return res.status(400).json({
          success: false,
          error: 'Please provide a valid email address (e.g., driver@speedracer3d.com).',
        });
      }

      if (!message || typeof message !== 'string' || message.trim().length < 15) {
        return res.status(400).json({
          success: false,
          error: 'Message must be at least 15 characters long.',
        });
      }

      const ticketId = `SR3D-${Math.floor(100000 + Math.random() * 900000)}`;
      const submission = {
        ticketId,
        name: name.trim(),
        email: email.trim(),
        category: category || 'General Inquiry',
        message: message.trim(),
        submittedAt: new Date().toISOString(),
        forwardRecipient: 'perwezansari59@gmail.com',
        status: 'received',
      };

      let existing: unknown[] = [];
      if (fs.existsSync(MESSAGES_FILE)) {
        try {
          existing = JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf-8'));
        } catch {
          existing = [];
        }
      }
      existing.unshift(submission);
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(existing.slice(0, 100), null, 2));

      return res.status(200).json({
        success: true,
        ticketId,
        submittedAt: submission.submittedAt,
        recipient: 'perwezansari59@gmail.com',
        message: `Your dispatch has been successfully recorded in the SPEED RACER 3D queue. Ticket ID #${ticketId}. Our team will review and reply within 24-48 business hours.`,
      });
    } catch (err: unknown) {
      console.error('Contact submit error:', err);
      return res.status(500).json({
        success: false,
        error: 'Internal server error processing dispatch. Please try again or reach out directly via email.',
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // --- REAL-TIME WEBSOCKET MULTIPLAYER BACKEND ---
  const rooms = new Map<string, RaceRoom>();
  const wss = new WebSocketServer({ server });

  function getOrCreateRoom(roomId: string): RaceRoom {
    let room = rooms.get(roomId);
    if (!room) {
      room = { id: roomId, players: new Map() };
      rooms.set(roomId, room);
    }
    return room;
  }

  function broadcastRoomState(room: RaceRoom, excludeId?: string) {
    const playerSummaries = Array.from(room.players.values())
      .map((p) => ({
        id: p.id,
        name: p.name,
        carId: p.carId,
        carColor: p.carColor,
        x: p.x,
        z: p.z,
        speed: p.speed,
        distance: p.distance,
        nitro: p.nitro,
      }))
      .sort((a, b) => b.distance - a.distance)
      .map((p, idx) => ({ ...p, rank: idx + 1 }));

    const payload = JSON.stringify({
      type: 'players_update',
      players: playerSummaries,
    });

    room.players.forEach((player) => {
      if (player.id !== excludeId && player.ws.readyState === WebSocket.OPEN) {
        player.ws.send(payload);
      }
    });
  }

  wss.on('connection', (ws: WebSocket) => {
    let currentRoomId: string | null = null;
    let playerId: string | null = null;

    ws.on('message', (data: string) => {
      try {
        const msg = JSON.parse(data.toString());

        if (msg.type === 'join') {
          const roomKey = String(msg.roomId || 'GLOBAL_CIRCUIT');
          currentRoomId = roomKey;
          playerId = `p_${Math.random().toString(36).slice(2, 8)}`;
          const room = getOrCreateRoom(roomKey);

          const newPlayer: OnlinePlayer = {
            id: playerId,
            name: msg.name || `Racer_${playerId.slice(2, 6)}`,
            carId: msg.carId || 'car_venom_gt',
            carColor: msg.carColor || '#00d4ff',
            x: 0,
            z: 0,
            speed: 0,
            distance: 0,
            nitro: false,
            ws,
            lastUpdate: Date.now(),
          };

          room.players.set(playerId, newPlayer);

          // Reply with self id
          ws.send(
            JSON.stringify({
              type: 'joined',
              id: playerId,
              roomId: currentRoomId,
            })
          );

          broadcastRoomState(room);
        } else if (msg.type === 'update' && currentRoomId && playerId) {
          const room = rooms.get(currentRoomId);
          if (room) {
            const player = room.players.get(playerId);
            if (player) {
              player.x = typeof msg.x === 'number' ? msg.x : player.x;
              player.z = typeof msg.z === 'number' ? msg.z : player.z;
              player.speed = typeof msg.speed === 'number' ? msg.speed : player.speed;
              player.distance = typeof msg.distance === 'number' ? msg.distance : player.distance;
              player.nitro = Boolean(msg.nitro);
              player.lastUpdate = Date.now();
            }
            broadcastRoomState(room, playerId);
          }
        } else if (msg.type === 'chat' && currentRoomId && playerId) {
          const room = rooms.get(currentRoomId);
          if (room) {
            const player = room.players.get(playerId);
            const chatPayload = JSON.stringify({
              type: 'chat',
              id: playerId,
              name: player ? player.name : 'Racer',
              text: String(msg.text || '').slice(0, 100),
              timestamp: Date.now(),
            });
            room.players.forEach((p) => {
              if (p.ws.readyState === WebSocket.OPEN) p.ws.send(chatPayload);
            });
          }
        }
      } catch (err) {
        // parse error
      }
    });

    ws.on('close', () => {
      if (currentRoomId && playerId) {
        const room = rooms.get(currentRoomId);
        if (room) {
          room.players.delete(playerId);
          broadcastRoomState(room);
          if (room.players.size === 0) {
            rooms.delete(currentRoomId);
          }
        }
      }
    });
  });

  // Vite development middleware or static production serve
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`SPEED RACER 3D server running on http://0.0.0.0:${PORT} (HTTP + WebSockets)`);
  });
}

startServer();
