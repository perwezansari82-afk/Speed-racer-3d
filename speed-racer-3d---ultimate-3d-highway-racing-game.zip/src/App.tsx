import React from 'react';
import { GameProvider, useGame } from './context/GameContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { DailyBonusModal } from './components/DailyBonusModal';
import { LuckySpinModal } from './components/LuckySpinModal';
import { DailyMissionsModal } from './components/DailyMissionsModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';

import { HomePage } from './pages/HomePage';
import { PlayPage } from './pages/PlayPage';
import { GaragePage } from './pages/GaragePage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { TermsPage } from './pages/TermsPage';
import { DisclaimerPage } from './pages/DisclaimerPage';

function MainApp() {
  const { activePage } = useGame();

  const renderActivePage = () => {
    switch (activePage) {
      case 'home':
        return <HomePage />;
      case 'play':
        return <PlayPage />;
      case 'garage':
        return <GaragePage />;
      case 'leaderboard':
        return <LeaderboardPage />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      case 'privacy':
        return <PrivacyPolicyPage />;
      case 'terms':
        return <TermsPage />;
      case 'disclaimer':
        return <DisclaimerPage />;
      default:
        return <HomePage />;
    }
  };

  const isPlayingGame = activePage === 'play';

  return (
    <div className="min-h-screen flex flex-col bg-[#080c16] text-slate-100 selection:bg-cyan-500 selection:text-black">
      {/* Top Navbar */}
      <Navbar />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col">
        {renderActivePage()}
      </main>

      {/* Global Modals */}
      <DailyBonusModal />
      <LuckySpinModal />
      <DailyMissionsModal />
      <ProfileModal />
      <SettingsModal />

      {/* Footer (hidden while actively racing for 100% immersive canvas viewport) */}
      {!isPlayingGame && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <GameProvider>
      <MainApp />
    </GameProvider>
  );
}
