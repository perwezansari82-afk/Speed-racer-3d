import React from 'react';

interface AdBannerProps {
  slotId?: string;
  format?: 'leaderboard' | 'rectangle' | 'horizontal-fluid';
  className?: string;
}

export function AdBanner({ slotId = 'default_slot', format = 'leaderboard', className = '' }: AdBannerProps) {
  return (
    <div className={`my-6 flex flex-col items-center justify-center ${className}`}>
      {/* Explicit Advertisement Marker per Google AdSense Policies */}
      <span className="text-[10px] uppercase font-rajdhani font-semibold tracking-widest text-slate-500 mb-1">
        Advertisement
      </span>

      <div
        className={`w-full bg-[#070b14] border border-dashed border-slate-700/60 rounded-xl flex flex-col items-center justify-center p-4 text-center transition-all ${
          format === 'leaderboard'
            ? 'max-w-4xl min-h-[90px]'
            : format === 'rectangle'
            ? 'max-w-xs min-h-[250px]'
            : 'max-w-full min-h-[80px]'
        }`}
      >
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-cyan-500/80" />
          <span className="font-orbitron text-xs text-slate-400 font-bold">
            SPEED RACER 3D SPONSOR ZONE
          </span>
        </div>
        <p className="text-xs text-slate-500 max-w-md font-rajdhani">
          Google AdSense responsive placement zone. Ad content renders securely outside interactive gameplay zones.
        </p>
      </div>
    </div>
  );
}
