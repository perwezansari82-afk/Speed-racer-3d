import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { X, Gift, Coins, CheckCircle, Clock, Sparkles } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { getTimeUntilNextMidnight } from '../utils/storage';
import { DAILY_BONUS_AMOUNT } from '../utils/constants';

export function DailyBonusModal() {
  const {
    profile,
    isDailyBonusModalOpen,
    setIsDailyBonusModalOpen,
    canClaimDailyBonus,
    claimDailyBonus,
  } = useGame();

  const [timeLeft, setTimeLeft] = useState(getTimeUntilNextMidnight());
  const [claimFeedback, setClaimFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (!isDailyBonusModalOpen) return;
    const interval = setInterval(() => {
      setTimeLeft(getTimeUntilNextMidnight());
    }, 1000);
    return () => clearInterval(interval);
  }, [isDailyBonusModalOpen]);

  if (!isDailyBonusModalOpen) return null;

  const handleClaim = () => {
    const res = claimDailyBonus();
    if (res.success) {
      setClaimFeedback(res.message);
      // Trigger festive celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00d4ff', '#f97316', '#facc15', '#a855f7'],
        });
      } catch {
        // ignore
      }
    } else {
      setClaimFeedback(res.message);
    }
  };

  const streak = profile.dailyBonus.streak || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0a0f1d] border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
        {/* Header Banner */}
        <div className="relative bg-gradient-to-r from-cyan-900/60 via-blue-900/60 to-orange-950/60 p-6 text-center border-b border-cyan-500/30">
          <button
            onClick={() => setIsDailyBonusModalOpen(false)}
            className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 p-0.5 shadow-lg shadow-orange-500/40 mb-3 flex items-center justify-center">
            <div className="w-full h-full bg-[#0d1322] rounded-[14px] flex items-center justify-center">
              <Gift className="w-8 h-8 text-amber-400 animate-bounce" />
            </div>
          </div>

          <h3 className="font-orbitron font-black text-2xl text-white tracking-wide">
            DAILY LOGIN BONUS
          </h3>
          <p className="font-rajdhani text-sm text-cyan-300 font-semibold mt-1">
            Claim your daily reward of exactly {DAILY_BONUS_AMOUNT} free gold coins!
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {/* Reward Amount Display */}
          <div className="bg-gradient-to-br from-slate-900 to-[#070b14] border border-amber-500/30 rounded-xl p-5 text-center relative overflow-hidden">
            <div className="flex items-center justify-center gap-3">
              <Coins className="w-8 h-8 text-amber-400 fill-amber-400/30 animate-pulse" />
              <span className="font-orbitron font-black text-4xl text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-orange-400">
                +{DAILY_BONUS_AMOUNT}
              </span>
              <span className="font-orbitron font-bold text-lg text-amber-300/80">
                COINS
              </span>
            </div>

            <p className="text-xs text-slate-400 font-rajdhani mt-2">
              Credited directly to your wallet. Use coins to buy supercars & boost engine stats.
            </p>

            <div className="mt-3 flex items-center justify-center gap-2 text-xs font-rajdhani font-semibold text-cyan-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Current Daily Streak: {streak} {streak === 1 ? 'Day' : 'Days'}</span>
            </div>
          </div>

          {/* Feedback message */}
          {claimFeedback && (
            <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs font-rajdhani font-bold text-center">
              {claimFeedback}
            </div>
          )}

          {/* Claim or Countdown Button */}
          {canClaimDailyBonus ? (
            <button
              onClick={handleClaim}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-orbitron font-extrabold text-base tracking-wider shadow-lg shadow-orange-500/30 glow-orange transition-all transform active:scale-95 cursor-pointer"
            >
              CLAIM 20 FREE COINS NOW
            </button>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-400 font-rajdhani font-bold text-sm">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>Claimed for today! Next bonus in:</span>
              </div>

              {/* Countdown Ticker */}
              <div className="grid grid-cols-3 gap-2 text-center font-orbitron">
                <div className="p-2.5 rounded-lg bg-slate-900/90 border border-cyan-500/20">
                  <span className="text-xl font-bold text-cyan-300">{String(timeLeft.hours).padStart(2, '0')}</span>
                  <span className="block text-[10px] text-slate-500 tracking-wider">HOURS</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900/90 border border-cyan-500/20">
                  <span className="text-xl font-bold text-cyan-300">{String(timeLeft.minutes).padStart(2, '0')}</span>
                  <span className="block text-[10px] text-slate-500 tracking-wider">MINUTES</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900/90 border border-cyan-500/20">
                  <span className="text-xl font-bold text-cyan-300">{String(timeLeft.seconds).padStart(2, '0')}</span>
                  <span className="block text-[10px] text-slate-500 tracking-wider">SECONDS</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-slate-950/60 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-500 font-rajdhani">
            Reset occurs at 00:00 midnight daily. Streak continues as long as you log in daily!
          </p>
        </div>
      </div>
    </div>
  );
}
