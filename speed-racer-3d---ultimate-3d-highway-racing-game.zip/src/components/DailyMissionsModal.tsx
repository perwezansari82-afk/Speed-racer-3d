import React from 'react';
import { X, Target, Coins, CheckCircle, Gift, Award, Flame, Gauge } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { sound } from '../utils/audio';

export function DailyMissionsModal() {
  const {
    profile,
    isMissionsModalOpen,
    setIsMissionsModalOpen,
    claimMissionReward,
  } = useGame();

  if (!isMissionsModalOpen) return null;

  const missions = profile.dailyMissions?.missions || [];

  const handleClaim = (id: string) => {
    claimMissionReward(id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0a0f1d] border border-cyan-500/40 rounded-3xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/60 p-5 border-b border-cyan-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-orbitron font-black text-xl text-white">
                DAILY RACING MISSIONS
              </h3>
              <p className="font-rajdhani text-xs text-cyan-300">
                Complete objectives during races to claim bonus coin bounties.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsMissionsModalOpen(false)}
            className="p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Missions List */}
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          {missions.map((mission) => {
            const progressRatio = Math.min(1.0, mission.current / mission.target);

            return (
              <div
                key={mission.id}
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="font-orbitron font-bold text-sm text-white">
                      {mission.title}
                    </h4>
                    <p className="font-rajdhani text-xs text-slate-400 mt-0.5">
                      {mission.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 font-orbitron font-bold text-xs shrink-0">
                    <Coins className="w-3.5 h-3.5 text-amber-400" />
                    <span>+{mission.rewardCoins}</span>
                  </div>
                </div>

                {/* Progress bar */}
                <div>
                  <div className="flex justify-between text-[11px] font-rajdhani font-semibold text-slate-400 mb-1">
                    <span>Progress: {mission.current.toLocaleString()} / {mission.target.toLocaleString()} {mission.unit}</span>
                    <span>{Math.round(progressRatio * 100)}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
                      style={{ width: `${progressRatio * 100}%` }}
                    />
                  </div>
                </div>

                {/* Action button */}
                <div className="pt-1 flex justify-end">
                  {mission.claimed ? (
                    <span className="flex items-center gap-1.5 text-xs font-rajdhani font-bold text-slate-500">
                      <CheckCircle className="w-4 h-4" />
                      <span>CLAIMED</span>
                    </span>
                  ) : mission.completed ? (
                    <button
                      onClick={() => handleClaim(mission.id)}
                      className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-orbitron font-black text-xs tracking-wider cursor-pointer shadow-md shadow-orange-500/30 animate-pulse"
                    >
                      CLAIM +{mission.rewardCoins} COINS
                    </button>
                  ) : (
                    <span className="text-xs font-rajdhani text-slate-500 font-semibold">
                      In Progress
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs font-rajdhani text-slate-400">
            Resets automatically every 24 hours.
          </span>
          <button
            onClick={() => setIsMissionsModalOpen(false)}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-orbitron text-xs font-bold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
