import React from 'react';
import { Flame, Shield, FileText, AlertTriangle, Mail, HelpCircle } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { sound } from '../utils/audio';

export function Footer() {
  const { setActivePage } = useGame();

  const handleNav = (page: string) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    sound.playClick();
  };

  return (
    <footer className="w-full bg-[#060a12] border-t border-slate-800 text-slate-400 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand Info */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-orange-500 p-0.5">
                <div className="w-full h-full bg-[#090d16] rounded-[6px] flex items-center justify-center">
                  <Flame className="w-4 h-4 text-orange-400" />
                </div>
              </div>
              <span className="font-orbitron font-bold text-lg text-white">SPEED RACER 3D</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed font-rajdhani text-sm">
              The premier web-based 3D highway racing experience. Push high-octane sports cars, supercars, and hypercars through bustling traffic, earn coins, tune performance, and dominate the highway.
            </p>
            <div className="flex items-center gap-2 text-[11px] font-rajdhani text-cyan-400/90">
              <span className="px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">WebGL 2.0</span>
              <span className="px-2 py-0.5 rounded bg-orange-950/60 border border-orange-800/40">60 FPS Optimized</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-orbitron text-xs font-bold text-white uppercase tracking-wider mb-3">
              Fast Track
            </h4>
            <ul className="space-y-2 text-sm font-rajdhani">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-cyan-400 transition-colors">
                  Home Screen
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('play')} className="hover:text-cyan-400 transition-colors">
                  Play Game (Live 3D)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('garage')} className="hover:text-cyan-400 transition-colors">
                  3D Car Garage
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('leaderboard')} className="hover:text-cyan-400 transition-colors">
                  Leaderboards & Records
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Support */}
          <div>
            <h4 className="font-orbitron text-xs font-bold text-white uppercase tracking-wider mb-3">
              Support & About
            </h4>
            <ul className="space-y-2 text-sm font-rajdhani">
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-cyan-400 transition-colors">
                  About SPEED RACER 3D
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-cyan-400 transition-colors">
                  Contact Us
                </button>
              </li>
              <li>
                <a href="/ads.txt" target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400 transition-colors">
                  ads.txt Verification
                </a>
              </li>
            </ul>
          </div>

          {/* Legal Pages */}
          <div>
            <h4 className="font-orbitron text-xs font-bold text-white uppercase tracking-wider mb-3">
              Legal & Safety
            </h4>
            <ul className="space-y-2 text-sm font-rajdhani">
              <li>
                <button onClick={() => handleNav('privacy')} className="hover:text-cyan-400 transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('terms')} className="hover:text-cyan-400 transition-colors">
                  Terms and Conditions
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('disclaimer')} className="hover:text-cyan-400 transition-colors">
                  Safety Disclaimer
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Disclaimer Notice */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-rajdhani">
          <p>© {new Date().getFullYear()} SPEED RACER 3D. All rights reserved. High-speed racing simulation game.</p>
          <p className="text-[11px] text-slate-500">
            Drive responsibly in real life. In-game coins and rewards are purely virtual.
          </p>
        </div>
      </div>
    </footer>
  );
}
