import React from 'react';
import {
  Pause,
  Play,
  Flame,
  Coins,
  Zap,
  Timer,
  Compass,
  Siren,
  Users,
  Wifi,
  WifiOff,
  AlertOctagon,
  ShieldAlert
} from 'lucide-react';
import { GameHUDState } from '../game/RacingGame';
import { GameMode, WeatherMode } from '../types/game';

interface GameHUDProps {
  hudState: GameHUDState;
  gameMode: GameMode;
  weather: WeatherMode;
  onTogglePause: () => void;
  nearMissFlash: number | null;
}

export function GameHUD({
  hudState,
  gameMode,
  weather,
  onTogglePause,
  nearMissFlash,
}: GameHUDProps) {
  const speedRatio = Math.min(1.0, hudState.speedKmh / 350);

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden z-20">
      {/* Top Header Bar */}
      <div className="p-4 sm:p-6 flex items-start justify-between">
        {/* Left: Distance & Coins & Police Wanted */}
        <div className="flex flex-col gap-2 pointer-events-auto">
          {/* Distance */}
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900/85 border border-cyan-500/30 backdrop-blur-sm flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400" />
            <div>
              <span className="font-orbitron font-black text-lg sm:text-xl text-white">
                {hudState.distanceMeters.toLocaleString()}
              </span>
              <span className="ml-1 text-[11px] font-rajdhani text-slate-400 font-bold">M</span>
            </div>
          </div>

          {/* Coins gathered during race */}
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900/85 border border-amber-500/30 backdrop-blur-sm flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-orbitron font-black text-lg sm:text-xl text-amber-300">
              +{hudState.coinsEarned}
            </span>
          </div>

          {/* Magnet Active indicator */}
          {hudState.magnetActive && (
            <div className="px-3 py-1 rounded-lg bg-purple-950/85 border border-purple-500/50 backdrop-blur-sm flex items-center gap-1.5 text-purple-300 text-xs font-orbitron font-bold">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              <span>COIN MAGNET ON</span>
            </div>
          )}

          {/* Police Chase Wanted Level */}
          {gameMode === 'policeChase' && (
            <div className="px-3 py-1.5 rounded-xl bg-rose-950/90 border border-rose-500/60 backdrop-blur-sm flex items-center gap-2 shadow-lg shadow-rose-950/40">
              <Siren className="w-4 h-4 text-rose-400 animate-bounce" />
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span
                    key={i}
                    className={`text-sm ${
                      i < hudState.wantedLevel ? 'text-amber-400 font-bold' : 'text-slate-600'
                    }`}
                  >
                    ★
                  </span>
                ))}
              </div>
              <span className="text-[10px] font-orbitron font-bold text-rose-300 ml-1">
                {hudState.policeDistance}M
              </span>
            </div>
          )}

          {/* Traffic Challenge Counter */}
          {gameMode === 'trafficChallenge' && (
            <div className="px-3 py-1 rounded-lg bg-orange-950/85 border border-orange-500/50 text-orange-300 text-xs font-orbitron font-bold flex items-center gap-1.5">
              <AlertOctagon className="w-3.5 h-3.5 text-orange-400" />
              <span>HEAVY TRAFFIC WAVE</span>
            </div>
          )}
        </div>

        {/* Center: Mode Timer, Near Miss Popups, Multiplayer Standings */}
        <div className="flex flex-col items-center">
          {gameMode === 'timeAttack' && (
            <div className={`px-5 py-2 rounded-2xl border backdrop-blur-md flex items-center gap-2 ${
              hudState.timeRemainingSeconds <= 10
                ? 'bg-rose-950/85 border-rose-500 text-rose-300 animate-pulse'
                : 'bg-slate-900/85 border-cyan-500/40 text-cyan-300'
            }`}>
              <Timer className="w-5 h-5 text-orange-400" />
              <span className="font-orbitron font-black text-2xl tracking-wider">
                00:{String(hudState.timeRemainingSeconds).padStart(2, '0')}
              </span>
            </div>
          )}

          {/* Near miss popup banner */}
          {nearMissFlash !== null && (
            <div className="mt-3 px-5 py-2 rounded-xl bg-orange-600/90 text-white border border-yellow-300 font-orbitron font-black text-sm tracking-wider shadow-lg shadow-orange-500/50 glow-orange animate-bounce">
              ⚡ NEAR MISS! +{3 + Math.min(10, nearMissFlash)} COINS ({nearMissFlash}x COMBO)
            </div>
          )}

          {/* Multiplayer Race Rank HUD */}
          {gameMode === 'multiplayer' && (
            <div className="mt-2 px-4 py-1.5 rounded-xl bg-slate-900/90 border border-cyan-500/50 backdrop-blur-md flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs font-orbitron text-cyan-300">
                <Users className="w-3.5 h-3.5" />
                <span>POSITION:</span>
                <span className="font-black text-base text-amber-300">#{hudState.currentRank}</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-rajdhani text-slate-400">
                {hudState.isMultiplayerConnected ? (
                  <span className="flex items-center gap-1 text-emerald-400 font-bold">
                    <Wifi className="w-3 h-3" /> Live
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-rose-400 font-bold">
                    <WifiOff className="w-3 h-3" /> Connecting...
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right: Score & Pause Button */}
        <div className="flex items-center gap-3 pointer-events-auto">
          {/* Score display */}
          <div className="text-right px-3.5 py-1.5 rounded-xl bg-slate-900/85 border border-slate-700/60 backdrop-blur-sm">
            <span className="block text-[10px] font-rajdhani font-semibold text-slate-400 uppercase tracking-wider">
              SCORE
            </span>
            <span className="font-orbitron font-black text-lg sm:text-xl text-white">
              {hudState.score.toLocaleString()}
            </span>
          </div>

          {/* Pause Button */}
          <button
            onClick={onTogglePause}
            className="p-3 rounded-xl bg-slate-900/85 border border-slate-700 text-slate-200 hover:text-cyan-400 hover:border-cyan-500/50 transition-all cursor-pointer backdrop-blur-sm"
            title="Pause Game (Esc / P)"
          >
            {hudState.isPaused ? <Play className="w-5 h-5 text-emerald-400" /> : <Pause className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Bottom Telemetry HUD: Speedometer & Nitro Boost */}
      <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
        {/* Speedometer Gauge */}
        <div className="flex items-end gap-3 p-3.5 sm:p-4 rounded-2xl bg-slate-950/85 border border-cyan-500/30 backdrop-blur-md">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="font-orbitron font-black text-3xl sm:text-5xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-200 to-white">
                {hudState.speedKmh}
              </span>
              <span className="font-orbitron font-bold text-xs sm:text-sm text-cyan-400">
                KM/H
              </span>
            </div>

            <div className="w-28 sm:w-40 h-2 bg-slate-800 rounded-full mt-1.5 overflow-hidden border border-slate-700">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-orange-500 transition-all duration-75"
                style={{ width: `${speedRatio * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Nitro Meter */}
        <div className="flex flex-col items-end p-3.5 sm:p-4 rounded-2xl bg-slate-950/85 border border-orange-500/30 backdrop-blur-md">
          <div className="flex items-center gap-1.5 text-xs font-orbitron font-bold text-orange-400 mb-1.5">
            <Flame className="w-4 h-4 text-orange-400 animate-pulse" />
            <span>NITRO BOOST</span>
            <span className="text-white text-xs">{hudState.nitroPercent}%</span>
          </div>

          <div className="w-28 sm:w-44 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-cyan-400 transition-all duration-75"
              style={{ width: `${hudState.nitroPercent}%` }}
            />
          </div>
          <span className="text-[10px] text-slate-400 font-rajdhani mt-1">
            Press [Shift] or [Space]
          </span>
        </div>
      </div>

      {/* Pause Screen Overlay */}
      {hudState.isPaused && (
        <div className="absolute inset-0 bg-black/75 backdrop-blur-md flex items-center justify-center pointer-events-auto">
          <div className="p-8 rounded-3xl bg-[#0a0f1d] border border-cyan-500/40 text-center max-w-sm w-full shadow-2xl">
            <h3 className="font-orbitron font-black text-3xl text-white mb-2">
              GAME PAUSED
            </h3>
            <p className="font-rajdhani text-sm text-slate-400 mb-6">
              Take a breath, racer. Ready to hit the asphalt?
            </p>
            <button
              onClick={onTogglePause}
              className="w-full py-3.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-orbitron font-black text-sm tracking-wider shadow-lg shadow-cyan-500/30 cursor-pointer"
            >
              RESUME RACE
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
