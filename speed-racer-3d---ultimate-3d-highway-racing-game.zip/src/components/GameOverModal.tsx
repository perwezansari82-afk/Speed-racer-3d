import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Wrench, Trophy, Coins, Flame, Gauge, Compass } from 'lucide-react';
import { RaceResult } from '../types/game';
import { sound } from '../utils/audio';

interface GameOverModalProps {
  result: RaceResult;
  isNewHighScore: boolean;
  onRestart: () => void;
  onGoToGarage: () => void;
}

export function GameOverModal({
  result,
  isNewHighScore,
  onRestart,
  onGoToGarage,
}: GameOverModalProps) {
  useEffect(() => {
    if (isNewHighScore) {
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
          colors: ['#00d4ff', '#f97316', '#facc15', '#a855f7'],
        });
      } catch {
        // ignore
      }
    }
  }, [isNewHighScore]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg bg-[#0a0f1d] border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-slate-900 via-rose-950/60 to-slate-900 p-6 text-center border-b border-rose-500/30">
          {isNewHighScore && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 text-xs font-orbitron font-bold mb-3 shadow-md shadow-amber-500/30">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>NEW HIGH SCORE!</span>
            </div>
          )}

          <h3 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-wider">
            RACE COMPLETE
          </h3>
          <p className="font-rajdhani text-sm text-slate-300 mt-1">
            Telemetry recorded & coins deposited to your wallet.
          </p>
        </div>

        {/* Stats Summary */}
        <div className="p-6 space-y-5">
          {/* Main Score Banner */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/40 via-slate-900 to-orange-950/40 border border-cyan-500/30 text-center">
            <span className="block text-xs font-rajdhani font-semibold text-slate-400 uppercase tracking-widest">
              TOTAL RACE SCORE
            </span>
            <span className="font-orbitron font-black text-4xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-200 to-orange-400">
              {result.score.toLocaleString()}
            </span>
          </div>

          {/* Grid of Results */}
          <div className="grid grid-cols-2 gap-3 text-sm font-rajdhani">
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
              <Compass className="w-5 h-5 text-cyan-400 shrink-0" />
              <div>
                <span className="block text-[11px] text-slate-400 uppercase">Distance</span>
                <span className="font-orbitron font-bold text-white text-base">
                  {result.distance.toLocaleString()} M
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-amber-500/30 flex items-center gap-3">
              <Coins className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="block text-[11px] text-slate-400 uppercase">Coins Earned</span>
                <span className="font-orbitron font-bold text-amber-300 text-base">
                  +{result.coinsCollected}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
              <Flame className="w-5 h-5 text-orange-400 shrink-0" />
              <div>
                <span className="block text-[11px] text-slate-400 uppercase">Near Misses</span>
                <span className="font-orbitron font-bold text-orange-300 text-base">
                  {result.nearMisses}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
              <Gauge className="w-5 h-5 text-sky-400 shrink-0" />
              <div>
                <span className="block text-[11px] text-slate-400 uppercase">Top Speed</span>
                <span className="font-orbitron font-bold text-sky-300 text-base">
                  {result.topSpeedReached} KM/H
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => {
                sound.playClick();
                onRestart();
              }}
              className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-orbitron font-black text-sm tracking-wider shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>RESTART RACE</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                onGoToGarage();
              }}
              className="flex-1 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-orbitron font-bold text-sm tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Wrench className="w-4 h-4 text-orange-400" />
              <span>VISIT GARAGE</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
