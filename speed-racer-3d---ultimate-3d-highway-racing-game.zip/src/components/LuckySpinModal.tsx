import React, { useRef, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { X, Sparkles, Coins, Clock, CheckCircle, Flame } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { LUCKY_SPIN_PRIZES } from '../utils/constants';
import { getTimeUntilNextMidnight } from '../utils/storage';
import { sound } from '../utils/audio';

export function LuckySpinModal() {
  const {
    isLuckySpinModalOpen,
    setIsLuckySpinModalOpen,
    canSpinLuckyWheel,
    spinLuckyWheel,
  } = useGame();

  const [timeLeft, setTimeLeft] = useState(getTimeUntilNextMidnight());
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [wonPrize, setWonPrize] = useState<{ coins: number; label: string } | null>(null);

  useEffect(() => {
    if (!isLuckySpinModalOpen) return;
    const interval = setInterval(() => {
      setTimeLeft(getTimeUntilNextMidnight());
    }, 1000);
    return () => clearInterval(interval);
  }, [isLuckySpinModalOpen]);

  if (!isLuckySpinModalOpen) return null;

  const handleSpin = () => {
    if (isSpinning || !canSpinLuckyWheel) return;

    setIsSpinning(true);
    setWonPrize(null);

    const res = spinLuckyWheel();
    if (!res.success) {
      setIsSpinning(false);
      return;
    }

    const sliceAngle = 360 / LUCKY_SPIN_PRIZES.length;
    // Calculate target angle so pointer (top at 270 deg) lands on prizeIndex
    const fullRounds = 5 + Math.floor(Math.random() * 3);
    const targetSliceCenter = res.prizeIndex * sliceAngle + sliceAngle / 2;
    // Pointer is at the top (90 deg or 270 deg depending on orientation)
    const targetAngle = fullRounds * 360 + (360 - targetSliceCenter) + 270;

    setRotationAngle(targetAngle);

    // Audio ticks during spin
    let tickCount = 0;
    const tickInterval = setInterval(() => {
      sound.playWheelTick();
      tickCount++;
      if (tickCount > 24) clearInterval(tickInterval);
    }, 140);

    setTimeout(() => {
      setIsSpinning(false);
      clearInterval(tickInterval);
      setWonPrize({ coins: res.coinsWon, label: res.label });

      if (res.coinsWon >= 500) {
        sound.playWheelJackpot();
      } else {
        sound.playUpgradeSuccess();
      }

      try {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#00d4ff', '#f97316', '#facc15', '#a855f7'],
        });
      } catch {
        // ignore
      }
    }, 4000);
  };

  const sliceAngle = 360 / LUCKY_SPIN_PRIZES.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0a0f1d] border border-cyan-500/40 rounded-3xl shadow-2xl shadow-cyan-500/20 overflow-hidden text-center">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-amber-950/60 via-slate-900 to-cyan-950/60 p-5 border-b border-amber-500/30">
          <button
            onClick={() => setIsLuckySpinModalOpen(false)}
            className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center justify-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h3 className="font-orbitron font-black text-2xl text-white">
              DAILY LUCKY SPIN
            </h3>
          </div>
          <p className="font-rajdhani text-xs text-amber-300 font-semibold">
            One free daily spin! Win up to 1,000 in-game gold coins.
          </p>
        </div>

        {/* Wheel Container */}
        <div className="p-6 flex flex-col items-center">
          <div className="relative w-64 h-64 my-2">
            {/* Top Pointer */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[22px] border-t-amber-400 filter drop-shadow-[0_2px_8px_rgba(251,191,36,0.8)]" />

            {/* Spinning Circle */}
            <div
              className="w-full h-full rounded-full border-4 border-amber-400 shadow-2xl shadow-amber-500/30 overflow-hidden relative transition-transform ease-out"
              style={{
                transform: `rotate(${rotationAngle}deg)`,
                transitionDuration: isSpinning ? '4000ms' : '0ms',
                background: '#090d16',
              }}
            >
              {LUCKY_SPIN_PRIZES.map((prize, idx) => {
                const angle = idx * sliceAngle;
                return (
                  <div
                    key={prize.id}
                    className="absolute top-0 left-1/2 w-32 h-32 origin-bottom-left flex items-start justify-center pt-2"
                    style={{
                      transform: `rotate(${angle}deg)`,
                      clipPath: 'polygon(0 0, 100% 0, 0 100%)',
                      backgroundColor: prize.color,
                      opacity: 0.9,
                    }}
                  >
                    <span
                      className="font-orbitron font-extrabold text-[11px] text-black tracking-tighter"
                      style={{
                        transform: 'rotate(25deg) translateY(8px)',
                      }}
                    >
                      {prize.coins}
                    </span>
                  </div>
                );
              })}

              {/* Center Hub */}
              <div className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-slate-950 border-2 border-amber-400 flex items-center justify-center shadow-lg z-10">
                <Coins className="w-6 h-6 text-amber-400" />
              </div>
            </div>
          </div>

          {/* Won Prize Notice */}
          {wonPrize && (
            <div className="my-3 p-3 rounded-xl bg-amber-950/80 border border-amber-500/60 text-amber-300 font-orbitron font-bold text-sm animate-bounce">
              🎉 Congratulations! Won {wonPrize.label}!
            </div>
          )}

          {/* Action Button or Countdown */}
          {canSpinLuckyWheel ? (
            <button
              onClick={handleSpin}
              disabled={isSpinning}
              className="mt-4 w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 disabled:opacity-60 text-black font-orbitron font-black text-sm tracking-wider shadow-lg shadow-orange-500/30 cursor-pointer transition-all transform active:scale-95"
            >
              {isSpinning ? 'SPINNING THE WHEEL...' : 'SPIN FOR FREE (1 DAILY SPIN)'}
            </button>
          ) : (
            <div className="mt-4 w-full space-y-3">
              <div className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 font-rajdhani font-bold text-xs">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Spun today! Next free spin unlocks in:</span>
              </div>

              <div className="grid grid-cols-3 gap-2 font-orbitron text-xs">
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-lg font-bold text-cyan-300">{String(timeLeft.hours).padStart(2, '0')}</span>
                  <span className="block text-[9px] text-slate-500">HOURS</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-lg font-bold text-cyan-300">{String(timeLeft.minutes).padStart(2, '0')}</span>
                  <span className="block text-[9px] text-slate-500">MINUTES</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-lg font-bold text-cyan-300">{String(timeLeft.seconds).padStart(2, '0')}</span>
                  <span className="block text-[9px] text-slate-500">SECONDS</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer legal disclosure */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <p className="text-[10px] text-slate-500 font-rajdhani">
            Free entertainment reward wheel. No real-money gambling or purchases involved.
          </p>
        </div>
      </div>
    </div>
  );
}
