import React from 'react';
import { ArrowLeft, ArrowRight, Flame, Disc3 } from 'lucide-react';
import { RacingGame } from '../game/RacingGame';

interface MobileControlsProps {
  gameInstance: RacingGame | null;
}

export function MobileControls({ gameInstance }: MobileControlsProps) {
  if (!gameInstance) return null;

  const handleSteerStart = (dir: -1 | 1) => {
    gameInstance.setSteerAxis(dir);
  };

  const handleSteerEnd = () => {
    gameInstance.setSteerAxis(0);
  };

  const handleGasStart = () => {
    gameInstance.setTouchAccelerate(true);
  };

  const handleGasEnd = () => {
    gameInstance.setTouchAccelerate(false);
  };

  const handleBrakeStart = () => {
    gameInstance.setTouchBrake(true);
  };

  const handleBrakeEnd = () => {
    gameInstance.setTouchBrake(false);
  };

  const handleNitroStart = () => {
    gameInstance.setTouchNitro(true);
  };

  const handleNitroEnd = () => {
    gameInstance.setTouchNitro(false);
  };

  return (
    <div className="md:hidden absolute inset-x-0 bottom-24 px-4 flex items-end justify-between pointer-events-none select-none z-30">
      {/* Left Steering Block */}
      <div className="flex items-center gap-3 pointer-events-auto">
        {/* Turn Left */}
        <button
          onTouchStart={() => handleSteerStart(-1)}
          onTouchEnd={handleSteerEnd}
          onMouseDown={() => handleSteerStart(-1)}
          onMouseUp={handleSteerEnd}
          className="w-16 h-16 rounded-2xl bg-slate-900/90 border border-cyan-500/50 active:bg-cyan-600/40 text-cyan-300 flex items-center justify-center shadow-lg active:scale-95 transition-transform touch-control-btn"
          aria-label="Steer Left"
        >
          <ArrowLeft className="w-8 h-8" />
        </button>

        {/* Turn Right */}
        <button
          onTouchStart={() => handleSteerStart(1)}
          onTouchEnd={handleSteerEnd}
          onMouseDown={() => handleSteerStart(1)}
          onMouseUp={handleSteerEnd}
          className="w-16 h-16 rounded-2xl bg-slate-900/90 border border-cyan-500/50 active:bg-cyan-600/40 text-cyan-300 flex items-center justify-center shadow-lg active:scale-95 transition-transform touch-control-btn"
          aria-label="Steer Right"
        >
          <ArrowRight className="w-8 h-8" />
        </button>
      </div>

      {/* Right Pedals Block (Brake, Nitro, Gas) */}
      <div className="flex items-end gap-2.5 pointer-events-auto">
        {/* Brake */}
        <button
          onTouchStart={handleBrakeStart}
          onTouchEnd={handleBrakeEnd}
          onMouseDown={handleBrakeStart}
          onMouseUp={handleBrakeEnd}
          className="w-13 h-14 rounded-2xl bg-rose-950/80 border border-rose-500/50 active:bg-rose-600/60 text-rose-300 flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform touch-control-btn"
          aria-label="Brake"
        >
          <Disc3 className="w-5 h-5 mb-0.5" />
          <span className="font-orbitron font-bold text-[9px]">BRAKE</span>
        </button>

        {/* Nitro */}
        <button
          onTouchStart={handleNitroStart}
          onTouchEnd={handleNitroEnd}
          onMouseDown={handleNitroStart}
          onMouseUp={handleNitroEnd}
          className="w-14 h-15 rounded-2xl bg-orange-950/80 border border-orange-500/60 active:bg-orange-600/60 text-orange-400 flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform glow-orange touch-control-btn"
          aria-label="Nitro Boost"
        >
          <Flame className="w-6 h-6 mb-0.5 text-orange-400" />
          <span className="font-orbitron font-black text-[9px]">NITRO</span>
        </button>

        {/* Gas / Accelerate */}
        <button
          onTouchStart={handleGasStart}
          onTouchEnd={handleGasEnd}
          onMouseDown={handleGasStart}
          onMouseUp={handleGasEnd}
          className="w-16 h-18 rounded-2xl bg-cyan-950/90 border-2 border-cyan-400 active:bg-cyan-600/60 text-cyan-200 flex flex-col items-center justify-center shadow-xl active:scale-95 transition-transform glow-cyan touch-control-btn"
          aria-label="Accelerate"
        >
          <span className="font-orbitron font-black text-xs tracking-wider">GAS</span>
          <span className="text-[9px] font-rajdhani text-cyan-400 font-bold">DRIVE</span>
        </button>
      </div>
    </div>
  );
}
