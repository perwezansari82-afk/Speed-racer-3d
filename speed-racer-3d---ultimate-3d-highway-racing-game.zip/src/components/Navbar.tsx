import React, { useState } from 'react';
import {
  Trophy,
  Volume2,
  VolumeX,
  User,
  Settings,
  Gift,
  Coins,
  Menu,
  X,
  Flame,
  Info,
  Mail,
  CarFront,
  Sparkles,
  Compass
} from 'lucide-react';
import { useGame } from '../context/GameContext';
import { sound } from '../utils/audio';

export function Navbar() {
  const {
    profile,
    activePage,
    setActivePage,
    canClaimDailyBonus,
    canSpinLuckyWheel,
    setIsDailyBonusModalOpen,
    setIsLuckySpinModalOpen,
    setIsMissionsModalOpen,
    setIsProfileModalOpen,
    setIsSettingsModalOpen,
  } = useGame();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(sound.isMuted);

  const toggleSound = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'play', label: 'Play Game' },
    { id: 'garage', label: 'Garage' },
    { id: 'leaderboard', label: 'Leaderboard' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact Us' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#090d16]/90 border-b border-cyan-500/20 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => {
            setActivePage('home');
            sound.playClick();
          }}
          className="flex items-center gap-3 group text-left cursor-pointer focus:outline-none"
        >
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-orange-500 p-0.5 shadow-lg shadow-cyan-500/30 group-hover:shadow-cyan-400/50 transition-all">
            <div className="w-full h-full bg-[#080d1a] rounded-[10px] flex items-center justify-center">
              <Flame className="w-6 h-6 text-orange-400 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-orbitron font-black text-xl sm:text-2xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-orange-400">
                SPEED RACER
              </span>
              <span className="font-orbitron font-extrabold text-xs px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/40">
                3D
              </span>
            </div>
            <p className="text-[10px] font-rajdhani font-semibold tracking-widest text-cyan-400/80 uppercase">
              Highway Apex Simulator
            </p>
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id);
                  sound.playClick();
                }}
                className={`px-3.5 py-2 rounded-lg font-rajdhani font-bold text-sm tracking-wide transition-all cursor-pointer ${
                  isActive
                    ? 'text-cyan-300 bg-cyan-950/60 border border-cyan-500/40 glow-cyan'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action Widgets */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Lucky Spin Button */}
          <button
            onClick={() => {
              setIsLuckySpinModalOpen(true);
              sound.playClick();
            }}
            className="relative p-2 rounded-lg bg-slate-800/80 border border-purple-500/30 text-purple-300 hover:border-purple-400 hover:text-white transition-all cursor-pointer"
            title="Lucky Spin Wheel"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            {canSpinLuckyWheel && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400" />
            )}
          </button>

          {/* Missions Button */}
          <button
            onClick={() => {
              setIsMissionsModalOpen(true);
              sound.playClick();
            }}
            className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition-all cursor-pointer"
            title="Daily Missions"
          >
            <Compass className="w-4 h-4 text-cyan-400" />
          </button>

          {/* Daily Bonus Button */}
          <button
            onClick={() => {
              setIsDailyBonusModalOpen(true);
              sound.playClick();
            }}
            className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 text-amber-300 hover:border-amber-400 transition-all font-rajdhani font-bold text-xs sm:text-sm cursor-pointer"
            title="Daily Bonus"
          >
            <Gift className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Bonus</span>
            {canClaimDailyBonus && (
              <span className="flex h-2 w-2 relative">
                <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-400 animate-ping" />
              </span>
            )}
          </button>

          {/* Coins Wallet */}
          <button
            onClick={() => {
              setActivePage('garage');
              sound.playClick();
            }}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-cyan-300 hover:border-cyan-400 transition-all cursor-pointer"
            title="Your Coins Wallet"
          >
            <Coins className="w-4 h-4 text-amber-400 fill-amber-400/20" />
            <span className="font-orbitron font-bold text-xs sm:text-sm text-amber-300">
              {profile.coins.toLocaleString()}
            </span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition-all cursor-pointer"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Profile Button */}
          <button
            onClick={() => {
              setIsProfileModalOpen(true);
              sound.playClick();
            }}
            className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition-all cursor-pointer"
            title="Driver Profile"
          >
            <User className="w-4 h-4 text-slate-300" />
          </button>

          {/* Settings Button */}
          <button
            onClick={() => {
              setIsSettingsModalOpen(true);
              sound.playClick();
            }}
            className="p-2 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition-all cursor-pointer"
            title="Game Settings"
          >
            <Settings className="w-4 h-4 text-slate-300" />
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-cyan-400 transition-all cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#0a0f1d] border-b border-cyan-500/30 px-4 py-3 space-y-1">
          <div className="grid grid-cols-2 gap-2 pb-2 mb-2 border-b border-slate-800">
            <button
              onClick={() => {
                setIsLuckySpinModalOpen(true);
                setIsMobileMenuOpen(false);
                sound.playClick();
              }}
              className="py-2 px-3 rounded-lg bg-purple-950/60 border border-purple-500/40 text-purple-300 text-xs font-rajdhani font-bold flex items-center justify-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>Lucky Spin</span>
            </button>
            <button
              onClick={() => {
                setIsMissionsModalOpen(true);
                setIsMobileMenuOpen(false);
                sound.playClick();
              }}
              className="py-2 px-3 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-rajdhani font-bold flex items-center justify-center gap-2"
            >
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Missions</span>
            </button>
          </div>
          {navItems.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id);
                  setIsMobileMenuOpen(false);
                  sound.playClick();
                }}
                className={`w-full text-left px-4 py-2.5 rounded-lg font-rajdhani font-bold text-base transition-all ${
                  isActive
                    ? 'text-cyan-300 bg-cyan-950/70 border border-cyan-500/40'
                    : 'text-slate-300 hover:bg-slate-800/50'
                }`}
              >
                {item.label}
              </button>
            );
          })}
          <div className="pt-2 border-t border-slate-800 grid grid-cols-3 gap-1 text-[11px] font-rajdhani text-slate-400">
            <button
              onClick={() => {
                setActivePage('privacy');
                setIsMobileMenuOpen(false);
                sound.playClick();
              }}
              className="py-1.5 px-1 hover:text-cyan-400 text-center"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => {
                setActivePage('terms');
                setIsMobileMenuOpen(false);
                sound.playClick();
              }}
              className="py-1.5 px-1 hover:text-cyan-400 text-center"
            >
              Terms & Conditions
            </button>
            <button
              onClick={() => {
                setActivePage('disclaimer');
                setIsMobileMenuOpen(false);
                sound.playClick();
              }}
              className="py-1.5 px-1 hover:text-cyan-400 text-center"
            >
              Disclaimer
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
