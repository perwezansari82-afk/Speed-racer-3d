import React, { useState } from 'react';
import { X, User, Trophy, Gauge, Coins, Flame, Award, Car, Check } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { CARS_CATALOG } from '../utils/constants';
import { sound } from '../utils/audio';

export function ProfileModal() {
  const { profile, isProfileModalOpen, setIsProfileModalOpen, updateProfileName } = useGame();
  const [nameInput, setNameInput] = useState(profile.name);
  const [isEditing, setIsEditing] = useState(false);

  if (!isProfileModalOpen) return null;

  const handleSaveName = () => {
    updateProfileName(nameInput);
    setIsEditing(false);
    sound.playClick();
  };

  // Compute driver rank title
  const totalDist = profile.totalDistanceKm;
  let driverRank = 'Rookie Speedster';
  let badgeColor = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/40';

  if (totalDist > 50) {
    driverRank = 'Highway Apex Legend';
    badgeColor = 'text-amber-400 bg-amber-950/60 border-amber-500/40';
  } else if (totalDist > 20) {
    driverRank = 'Master Asphalt Drifter';
    badgeColor = 'text-purple-400 bg-purple-950/60 border-purple-500/40';
  } else if (totalDist > 5) {
    driverRank = 'Pro Circuit Racer';
    badgeColor = 'text-blue-400 bg-blue-950/60 border-blue-500/40';
  }

  const selectedCar = CARS_CATALOG.find((c) => c.id === profile.selectedCarId) || CARS_CATALOG[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0a0f1d] border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 p-6 border-b border-cyan-500/30">
          <button
            onClick={() => setIsProfileModalOpen(false)}
            className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-orange-500 p-0.5 shadow-lg shadow-cyan-500/30">
              <div className="w-full h-full bg-[#0a0f1d] rounded-[14px] flex items-center justify-center">
                <User className="w-8 h-8 text-cyan-400" />
              </div>
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2">
                {isEditing ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      maxLength={16}
                      className="px-2.5 py-1 bg-slate-800 border border-cyan-500/60 rounded text-white font-orbitron text-sm focus:outline-none focus:ring-1 focus:ring-cyan-400"
                    />
                    <button
                      onClick={handleSaveName}
                      className="p-1 rounded bg-cyan-600 hover:bg-cyan-500 text-black cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <h3 className="font-orbitron font-extrabold text-xl text-white">
                      {profile.name}
                    </h3>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-xs text-cyan-400 hover:underline font-rajdhani cursor-pointer"
                    >
                      [Edit]
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-1 flex items-center gap-2">
                <span className={`text-[11px] font-rajdhani font-bold px-2 py-0.5 rounded border ${badgeColor}`}>
                  {driverRank}
                </span>
                <span className="text-xs text-slate-400 font-rajdhani">
                  Car: {selectedCar.name}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Career Stats Grid */}
        <div className="p-6 space-y-5">
          <h4 className="font-orbitron text-xs font-bold text-slate-300 uppercase tracking-wider">
            Driver Telemetry & Career Stats
          </h4>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center gap-2 text-cyan-400 text-xs font-rajdhani">
                <Gauge className="w-4 h-4" />
                <span>Odometer</span>
              </div>
              <p className="font-orbitron font-black text-lg text-white mt-1">
                {profile.totalDistanceKm.toFixed(1)} <span className="text-xs font-normal text-slate-400">KM</span>
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-rajdhani">
                <Coins className="w-4 h-4" />
                <span>Total Earned</span>
              </div>
              <p className="font-orbitron font-black text-lg text-amber-300 mt-1">
                {profile.totalCoinsEarned.toLocaleString()}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center gap-2 text-orange-400 text-xs font-rajdhani">
                <Flame className="w-4 h-4" />
                <span>Near Misses</span>
              </div>
              <p className="font-orbitron font-black text-lg text-orange-300 mt-1">
                {profile.nearMisses}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center gap-2 text-purple-400 text-xs font-rajdhani">
                <Trophy className="w-4 h-4" />
                <span>Races Run</span>
              </div>
              <p className="font-orbitron font-black text-lg text-purple-300 mt-1">
                {profile.totalRaces}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-rajdhani">
                <Car className="w-4 h-4" />
                <span>Cars Owned</span>
              </div>
              <p className="font-orbitron font-black text-lg text-emerald-300 mt-1">
                {profile.unlockedCars.length} / {CARS_CATALOG.length}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="flex items-center gap-2 text-sky-400 text-xs font-rajdhani">
                <Award className="w-4 h-4" />
                <span>Best Run</span>
              </div>
              <p className="font-orbitron font-black text-lg text-sky-300 mt-1">
                {profile.bestDistance} <span className="text-xs font-normal text-slate-400">M</span>
              </p>
            </div>
          </div>

          {/* Mode High Scores */}
          <div className="p-4 rounded-xl bg-slate-900/50 border border-cyan-500/20 space-y-2.5">
            <h5 className="font-orbitron text-xs font-bold text-cyan-300 uppercase">
              Mode High Scores
            </h5>
            <div className="flex items-center justify-between text-sm font-rajdhani border-b border-slate-800 pb-1.5">
              <span className="text-slate-400">Endless Highway</span>
              <span className="font-orbitron font-bold text-white">{profile.highScores.endless.toLocaleString()} pts</span>
            </div>
            <div className="flex items-center justify-between text-sm font-rajdhani border-b border-slate-800 pb-1.5">
              <span className="text-slate-400">Time Challenge</span>
              <span className="font-orbitron font-bold text-white">{profile.highScores.timeAttack.toLocaleString()} pts</span>
            </div>
            <div className="flex items-center justify-between text-sm font-rajdhani">
              <span className="text-slate-400">Coin Rush</span>
              <span className="font-orbitron font-bold text-white">{profile.highScores.coinRush.toLocaleString()} pts</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/60 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => setIsProfileModalOpen(false)}
            className="px-5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-rajdhani font-bold text-sm cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
