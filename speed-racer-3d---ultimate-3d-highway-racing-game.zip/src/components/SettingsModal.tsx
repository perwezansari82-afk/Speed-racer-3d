import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Music,
  Eye,
  RotateCcw,
  AlertCircle,
  Camera,
  Smartphone,
  CloudSun,
  ShieldCheck
} from 'lucide-react';
import { useGame } from '../context/GameContext';
import { WEATHER_ENVIRONMENTS } from '../utils/constants';
import { CameraView, WeatherMode } from '../types/game';
import { sound } from '../utils/audio';

export function SettingsModal() {
  const {
    profile,
    isSettingsModalOpen,
    setIsSettingsModalOpen,
    updateSettings,
    resetAllProgress,
    selectedWeather,
    setSelectedWeather,
  } = useGame();

  const [showResetConfirm, setShowResetConfirm] = useState(false);

  if (!isSettingsModalOpen) return null;

  const handleSoundChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    updateSettings({ soundVolume: vol });
    sound.setVolumes(vol, profile.settings.musicVolume);
  };

  const handleMusicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    updateSettings({ musicVolume: vol });
    sound.setVolumes(profile.settings.soundVolume, vol);
  };

  const handleReset = () => {
    resetAllProgress();
    setShowResetConfirm(false);
    setIsSettingsModalOpen(false);
    sound.playClick();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0a0f1d] border border-cyan-500/40 rounded-3xl shadow-2xl shadow-cyan-500/20 overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 p-5 border-b border-cyan-500/30 flex items-center justify-between">
          <div>
            <h3 className="font-orbitron font-extrabold text-xl text-white">
              GAME & RACING SETTINGS
            </h3>
            <p className="font-rajdhani text-xs text-slate-400">
              Tune graphics, audio levels, camera perspective, and mobile touch inputs.
            </p>
          </div>

          <button
            onClick={() => setIsSettingsModalOpen(false)}
            className="p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Audio levels */}
          <div className="space-y-4">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-cyan-400" />
              <span>Audio & Synth Soundtrack</span>
            </h4>

            {/* Sound FX */}
            <div>
              <div className="flex justify-between text-xs font-rajdhani font-semibold text-slate-300 mb-1.5">
                <span>Sound FX (Engine, Sirens, Nitro, Crashes)</span>
                <span>{Math.round(profile.settings.soundVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={profile.settings.soundVolume}
                onChange={handleSoundChange}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Music */}
            <div>
              <div className="flex justify-between text-xs font-rajdhani font-semibold text-slate-300 mb-1.5">
                <span className="flex items-center gap-1">
                  <Music className="w-3.5 h-3.5 text-orange-400" />
                  <span>Synthwave Racing Soundtrack</span>
                </span>
                <span>{Math.round(profile.settings.musicVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={profile.settings.musicVolume}
                onChange={handleMusicChange}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-400"
              />
            </div>
          </div>

          {/* Graphics Quality */}
          <div className="space-y-3">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-cyan-400" />
              <span>Graphics Quality & Shadows</span>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as const).map((qual) => (
                <button
                  key={qual}
                  onClick={() => {
                    updateSettings({ quality: qual });
                    sound.playClick();
                  }}
                  className={`py-2 rounded-xl font-orbitron text-xs uppercase tracking-wider transition-all cursor-pointer ${
                    profile.settings.quality === qual
                      ? 'bg-cyan-600 text-black font-extrabold shadow-md shadow-cyan-500/30'
                      : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {qual}
                </button>
              ))}
            </div>
          </div>

          {/* Weather Selection */}
          <div className="space-y-3">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <CloudSun className="w-4 h-4 text-cyan-400" />
              <span>Active 3D Environment</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-rajdhani font-bold">
              {WEATHER_ENVIRONMENTS.map((env) => {
                const isSelected = selectedWeather === env.id;
                return (
                  <button
                    key={env.id}
                    onClick={() => {
                      setSelectedWeather(env.id);
                      sound.playClick();
                    }}
                    className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'border-cyan-400 bg-cyan-950/80 text-cyan-300 shadow-sm'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-white'
                    }`}
                  >
                    {env.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Camera View */}
          <div className="space-y-3">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-cyan-400" />
              <span>Camera Perspective</span>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              {([
                { id: 'chase', label: 'Chase Third-Person' },
                { id: 'hood', label: 'Hood Close-Up' },
                { id: 'cinematic', label: 'Wide Cinematic' },
              ] as const).map((cam) => (
                <button
                  key={cam.id}
                  onClick={() => {
                    updateSettings({ cameraView: cam.id as CameraView });
                    sound.playClick();
                  }}
                  className={`py-2 px-2 rounded-xl font-rajdhani text-xs font-bold transition-all cursor-pointer ${
                    profile.settings.cameraView === cam.id
                      ? 'bg-cyan-600 text-black shadow-md'
                      : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {cam.label}
                </button>
              ))}
            </div>
          </div>

          {/* Mobile Touch Control Mode */}
          <div className="space-y-3">
            <h4 className="font-orbitron text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span>Mobile Touch Layout</span>
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'buttons', label: 'Classic On-Screen Buttons' },
                { id: 'pedals', label: 'Split Steering & Pedals' },
              ].map((style) => (
                <button
                  key={style.id}
                  onClick={() => {
                    updateSettings({ mobileControlStyle: style.id as 'buttons' | 'pedals' });
                    sound.playClick();
                  }}
                  className={`py-2 px-3 rounded-xl font-rajdhani text-xs font-bold transition-all cursor-pointer ${
                    profile.settings.mobileControlStyle === style.id
                      ? 'bg-cyan-600 text-black shadow-md'
                      : 'bg-slate-800/80 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {style.label}
                </button>
              ))}
            </div>
          </div>

          {/* Reset progress */}
          <div className="pt-4 border-t border-slate-800">
            {showResetConfirm ? (
              <div className="p-3 bg-rose-950/40 border border-rose-500/50 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-rose-400 text-xs font-rajdhani font-bold">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Are you sure? This will reset all unlocked cars and coins.</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleReset}
                    className="flex-1 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-rajdhani font-bold text-xs cursor-pointer"
                  >
                    Yes, Reset Everything
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 font-rajdhani text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowResetConfirm(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-slate-700 hover:border-rose-500/50 text-slate-400 hover:text-rose-400 transition-colors font-rajdhani font-semibold text-xs cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Save Data & Career Progress</span>
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => setIsSettingsModalOpen(false)}
            className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-orbitron font-bold text-xs cursor-pointer"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
}
