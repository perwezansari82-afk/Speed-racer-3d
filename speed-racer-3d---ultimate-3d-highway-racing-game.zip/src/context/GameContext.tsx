import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  PlayerProfile,
  CarUpgrades,
  CarCustomization,
  GameMode,
  WeatherMode,
  RaceResult,
  LeaderboardEntry
} from '../types/game';
import {
  loadProfile,
  saveProfile,
  getDefaultProfile,
  getTodayDateString,
  isDailyBonusAvailable,
  isLuckySpinAvailable
} from '../utils/storage';
import {
  CARS_CATALOG,
  UPGRADE_TIER_COSTS,
  DAILY_BONUS_AMOUNT,
  MAX_UPGRADE_LEVEL,
  LUCKY_SPIN_PRIZES,
  generateDailyMissions
} from '../utils/constants';
import { sound } from '../utils/audio';

interface GameContextType {
  profile: PlayerProfile;
  activePage: string;
  setActivePage: (page: string) => void;
  selectedGameMode: GameMode;
  setSelectedGameMode: (mode: GameMode) => void;
  selectedWeather: WeatherMode;
  setSelectedWeather: (weather: WeatherMode) => void;
  isDailyBonusModalOpen: boolean;
  setIsDailyBonusModalOpen: (open: boolean) => void;
  isLuckySpinModalOpen: boolean;
  setIsLuckySpinModalOpen: (open: boolean) => void;
  isMissionsModalOpen: boolean;
  setIsMissionsModalOpen: (open: boolean) => void;
  isProfileModalOpen: boolean;
  setIsProfileModalOpen: (open: boolean) => void;
  isSettingsModalOpen: boolean;
  setIsSettingsModalOpen: (open: boolean) => void;
  canClaimDailyBonus: boolean;
  canSpinLuckyWheel: boolean;
  claimDailyBonus: () => { success: boolean; coinsAdded: number; message: string };
  spinLuckyWheel: () => { success: boolean; prizeIndex: number; coinsWon: number; label: string };
  selectCar: (carId: string) => void;
  buyCar: (carId: string) => { success: boolean; message: string };
  changeCarColor: (carId: string, colorHex: string) => void;
  updateCarCustomization: (carId: string, partial: Partial<CarCustomization>) => void;
  upgradeCar: (carId: string, attribute: keyof CarUpgrades) => { success: boolean; cost: number; message: string };
  claimMissionReward: (missionId: string) => { success: boolean; rewardCoins: number };
  updateMissionProgress: (type: 'dist' | 'nearmiss' | 'coins' | 'speed', amount: number) => void;
  recordRaceResult: (result: RaceResult) => { isNewHighScore: boolean; totalCoinsEarned: number };
  updateProfileName: (name: string) => void;
  updateSettings: (settings: Partial<PlayerProfile['settings']>) => void;
  resetAllProgress: () => void;
  leaderboardEntries: LeaderboardEntry[];
}

const GameContext = createContext<GameContextType | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<PlayerProfile>(() => loadProfile());
  const [activePage, setActivePage] = useState<string>('home');
  const [selectedGameMode, setSelectedGameMode] = useState<GameMode>('endless');
  const [selectedWeather, setSelectedWeather] = useState<WeatherMode>('day');

  // Modals
  const [isDailyBonusModalOpen, setIsDailyBonusModalOpen] = useState<boolean>(false);
  const [isLuckySpinModalOpen, setIsLuckySpinModalOpen] = useState<boolean>(false);
  const [isMissionsModalOpen, setIsMissionsModalOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    sound.setVolumes(profile.settings.soundVolume, profile.settings.musicVolume);
  }, [profile.settings.soundVolume, profile.settings.musicVolume]);

  useEffect(() => {
    saveProfile(profile);
  }, [profile]);

  const canClaimDailyBonus = isDailyBonusAvailable(profile.dailyBonus.lastClaimDate);
  const canSpinLuckyWheel = isLuckySpinAvailable(profile.luckySpin.lastSpinDate);

  const claimDailyBonus = () => {
    if (!canClaimDailyBonus) {
      return { success: false, coinsAdded: 0, message: 'Daily bonus already claimed today. Come back tomorrow!' };
    }

    const today = getTodayDateString();
    const newStreak = profile.dailyBonus.lastClaimDate ? profile.dailyBonus.streak + 1 : 1;

    setProfile((prev) => ({
      ...prev,
      coins: prev.coins + DAILY_BONUS_AMOUNT,
      totalCoinsEarned: prev.totalCoinsEarned + DAILY_BONUS_AMOUNT,
      dailyBonus: {
        lastClaimDate: today,
        streak: newStreak,
      },
    }));

    sound.playUpgradeSuccess();
    return {
      success: true,
      coinsAdded: DAILY_BONUS_AMOUNT,
      message: `Claimed +${DAILY_BONUS_AMOUNT} Coins! (Day streak: ${newStreak})`,
    };
  };

  const spinLuckyWheel = () => {
    if (!canSpinLuckyWheel) {
      return { success: false, prizeIndex: 0, coinsWon: 0, label: 'Already spun today' };
    }

    const today = getTodayDateString();
    const prizeIndex = Math.floor(Math.random() * LUCKY_SPIN_PRIZES.length);
    const prize = LUCKY_SPIN_PRIZES[prizeIndex];

    setProfile((prev) => ({
      ...prev,
      coins: prev.coins + prize.coins,
      totalCoinsEarned: prev.totalCoinsEarned + prize.coins,
      luckySpin: {
        lastSpinDate: today,
        totalSpins: prev.luckySpin.totalSpins + 1,
      },
    }));

    return {
      success: true,
      prizeIndex,
      coinsWon: prize.coins,
      label: prize.label,
    };
  };

  const selectCar = (carId: string) => {
    if (!profile.unlockedCars.includes(carId)) return;
    setProfile((prev) => ({ ...prev, selectedCarId: carId }));
    sound.playClick();
  };

  const buyCar = (carId: string) => {
    const carDef = CARS_CATALOG.find((c) => c.id === carId);
    if (!carDef) return { success: false, message: 'Vehicle not found.' };

    if (profile.unlockedCars.includes(carId)) {
      return { success: false, message: 'You already own this car.' };
    }

    if (profile.coins < carDef.price) {
      return {
        success: false,
        message: `Insufficient coins! Need ${carDef.price} coins, you have ${profile.coins}.`,
      };
    }

    setProfile((prev) => ({
      ...prev,
      coins: prev.coins - carDef.price,
      unlockedCars: [...prev.unlockedCars, carId],
      selectedCarId: carId,
    }));

    sound.playUpgradeSuccess();
    return { success: true, message: `Successfully purchased ${carDef.name}!` };
  };

  const changeCarColor = (carId: string, colorHex: string) => {
    setProfile((prev) => ({
      ...prev,
      carColors: {
        ...prev.carColors,
        [carId]: colorHex,
      },
      carCustomizations: {
        ...prev.carCustomizations,
        [carId]: {
          ...(prev.carCustomizations[carId] || {}),
          color: colorHex,
        },
      },
    }));
    sound.playClick();
  };

  const updateCarCustomization = (carId: string, partial: Partial<CarCustomization>) => {
    setProfile((prev) => ({
      ...prev,
      carCustomizations: {
        ...prev.carCustomizations,
        [carId]: {
          ...(prev.carCustomizations[carId] || {}),
          ...partial,
        },
      },
    }));
    sound.playClick();
  };

  const upgradeCar = (carId: string, attribute: keyof CarUpgrades) => {
    const currentUpgrades = profile.carUpgrades[carId] || { engine: 0, speed: 0, handling: 0, nitro: 0 };
    const currentLevel = currentUpgrades[attribute];

    if (currentLevel >= MAX_UPGRADE_LEVEL) {
      return { success: false, cost: 0, message: 'Already reached maximum level!' };
    }

    const cost = UPGRADE_TIER_COSTS[currentLevel];
    if (profile.coins < cost) {
      return { success: false, cost, message: `Need ${cost} coins to upgrade ${attribute}.` };
    }

    setProfile((prev) => ({
      ...prev,
      coins: prev.coins - cost,
      carUpgrades: {
        ...prev.carUpgrades,
        [carId]: {
          ...currentUpgrades,
          [attribute]: currentLevel + 1,
        },
      },
    }));

    sound.playUpgradeSuccess();
    return { success: true, cost, message: `${attribute.toUpperCase()} upgraded to Level ${currentLevel + 1}!` };
  };

  // Missions tracking
  const updateMissionProgress = (type: 'dist' | 'nearmiss' | 'coins' | 'speed', amount: number) => {
    setProfile((prev) => {
      const today = getTodayDateString();
      let missions = prev.dailyMissions.missions;
      if (prev.dailyMissions.date !== today) {
        missions = generateDailyMissions();
      }

      const updatedMissions = missions.map((m) => {
        if (m.claimed) return m;

        let newCurrent = m.current;
        if (type === 'dist' && m.id === 'm_dist') {
          newCurrent += amount;
        } else if (type === 'nearmiss' && m.id === 'm_nearmiss') {
          newCurrent += amount;
        } else if (type === 'coins' && m.id === 'm_coins') {
          newCurrent += amount;
        } else if (type === 'speed' && m.id === 'm_speed') {
          newCurrent = Math.max(newCurrent, amount);
        }

        const completed = newCurrent >= m.target;
        return {
          ...m,
          current: Math.min(newCurrent, m.target),
          completed,
        };
      });

      return {
        ...prev,
        dailyMissions: {
          date: today,
          missions: updatedMissions,
        },
      };
    });
  };

  const claimMissionReward = (missionId: string) => {
    const mission = profile.dailyMissions.missions.find((m) => m.id === missionId);
    if (!mission || !mission.completed || mission.claimed) {
      return { success: false, rewardCoins: 0 };
    }

    setProfile((prev) => ({
      ...prev,
      coins: prev.coins + mission.rewardCoins,
      totalCoinsEarned: prev.totalCoinsEarned + mission.rewardCoins,
      dailyMissions: {
        ...prev.dailyMissions,
        missions: prev.dailyMissions.missions.map((m) =>
          m.id === missionId ? { ...m, claimed: true } : m
        ),
      },
    }));

    sound.playUpgradeSuccess();
    return { success: true, rewardCoins: mission.rewardCoins };
  };

  const recordRaceResult = (result: RaceResult) => {
    const currentHigh = (profile.highScores as Record<string, number>)[result.mode] || 0;
    const isNewHighScore = result.score > currentHigh;

    setProfile((prev) => {
      const updatedHigh = Math.max((prev.highScores as Record<string, number>)[result.mode] || 0, result.score);
      const updatedCoins = prev.coins + result.coinsCollected;
      const updatedTotalCoins = prev.totalCoinsEarned + result.coinsCollected;
      const updatedDistanceKm = Number((prev.totalDistanceKm + result.distance / 1000).toFixed(2));
      const updatedBestDist = Math.max(prev.bestDistance, result.distance);
      const updatedPoliceEvaded = prev.policeEvaded + (result.policeEvadedCount || 0);

      return {
        ...prev,
        coins: updatedCoins,
        totalCoinsEarned: updatedTotalCoins,
        totalDistanceKm: updatedDistanceKm,
        bestDistance: updatedBestDist,
        totalRaces: prev.totalRaces + 1,
        nearMisses: prev.nearMisses + result.nearMisses,
        policeEvaded: updatedPoliceEvaded,
        highScores: {
          ...prev.highScores,
          [result.mode]: updatedHigh,
        },
      };
    });

    return { isNewHighScore, totalCoinsEarned: result.coinsCollected };
  };

  const updateProfileName = (name: string) => {
    const trimmed = name.trim().slice(0, 16);
    if (!trimmed) return;
    setProfile((prev) => ({ ...prev, name: trimmed }));
  };

  const updateSettings = (newSettings: Partial<PlayerProfile['settings']>) => {
    setProfile((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...newSettings },
    }));
  };

  const resetAllProgress = () => {
    const fresh = getDefaultProfile();
    setProfile(fresh);
    saveProfile(fresh);
  };

  const rawLeaderboard: Array<{ id: string; name: string; score: number; car: string; mode: GameMode; date: string }> = [
    { id: '1', name: 'ApexPhantom_99', score: 32450, car: 'Shadow Stealth', mode: 'policeChase', date: 'Today' },
    { id: '2', name: 'CyberDrifter', score: 28100, car: 'Valkyrie Hyper', mode: 'endless', date: 'Yesterday' },
    { id: 'player', name: profile.name, score: Math.max(profile.highScores.endless, 19500), car: CARS_CATALOG.find((c) => c.id === profile.selectedCarId)?.name || 'Venom GT', mode: 'endless', date: 'Just now' },
    { id: '4', name: 'NitroStorm', score: 18400, car: 'Cyber Neon 2077', mode: 'trafficChallenge', date: '2 days ago' },
    { id: '5', name: 'RedlineQueen', score: 16890, car: 'Crimson Fury', mode: 'policeChase', date: '3 days ago' },
    { id: '6', name: 'TurboViper', score: 13400, car: 'Apex Phantom', mode: 'endless', date: '4 days ago' },
    { id: '7', name: 'HighwayGhost', score: 10200, car: 'Venom GT', mode: 'timeAttack', date: '5 days ago' },
  ];

  const leaderboardEntries: LeaderboardEntry[] = rawLeaderboard
    .sort((a, b) => b.score - a.score)
    .map((item, idx) => ({ ...item, rank: idx + 1 }));

  return (
    <GameContext.Provider
      value={{
        profile,
        activePage,
        setActivePage,
        selectedGameMode,
        setSelectedGameMode,
        selectedWeather,
        setSelectedWeather,
        isDailyBonusModalOpen,
        setIsDailyBonusModalOpen,
        isLuckySpinModalOpen,
        setIsLuckySpinModalOpen,
        isMissionsModalOpen,
        setIsMissionsModalOpen,
        isProfileModalOpen,
        setIsProfileModalOpen,
        isSettingsModalOpen,
        setIsSettingsModalOpen,
        canClaimDailyBonus,
        canSpinLuckyWheel,
        claimDailyBonus,
        spinLuckyWheel,
        selectCar,
        buyCar,
        changeCarColor,
        updateCarCustomization,
        upgradeCar,
        claimMissionReward,
        updateMissionProgress,
        recordRaceResult,
        updateProfileName,
        updateSettings,
        resetAllProgress,
        leaderboardEntries,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used within GameProvider');
  return ctx;
}
