import * as THREE from 'three';
import { CarCustomization, SpoilerStyle, WheelStyle } from '../types/game';

export interface CarMeshContainer extends THREE.Group {
  userData: {
    wheels: THREE.Mesh[];
    headlights: THREE.Mesh[];
    taillights: THREE.Mesh[];
    exhausts: THREE.Mesh[];
    underglow: THREE.Mesh | null;
    bodyMeshes: THREE.Mesh[];
    nitroFlames: THREE.Mesh[];
    policeLightBlue?: THREE.Mesh;
    policeLightRed?: THREE.Mesh;
  };
}

// Procedural rubber tire texture generator
function createTireTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#1e2124';
  ctx.fillRect(0, 0, 128, 128);

  // Tire treads
  ctx.fillStyle = '#111315';
  for (let i = 0; i < 128; i += 8) {
    ctx.fillRect(i, 0, 4, 128);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const sharedTireTexture = createTireTexture();

// Helper to construct procedural custom wheels based on style and color
function createProceduralWheel(
  radius: number,
  width: number,
  style: WheelStyle = 'sport5',
  rimColorHex = '#d1d5db'
): THREE.Mesh {
  const wheelGroup = new THREE.Group();
  const rimColor = new THREE.Color(rimColorHex);

  // Tire outer rubber
  const tireGeo = new THREE.CylinderGeometry(radius, radius, width, 24);
  tireGeo.rotateZ(Math.PI / 2);
  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x1f2429,
    roughness: 0.85,
    metalness: 0.1,
    map: sharedTireTexture,
  });
  const tireMesh = new THREE.Mesh(tireGeo, tireMat);
  tireMesh.castShadow = true;
  wheelGroup.add(tireMesh);

  // Alloy Rim (outer circle)
  const rimGeo = new THREE.CylinderGeometry(radius * 0.72, radius * 0.72, width * 1.02, 18);
  rimGeo.rotateZ(Math.PI / 2);
  const rimMat = new THREE.MeshStandardMaterial({
    color: rimColor,
    metalness: 0.9,
    roughness: 0.2,
  });
  const rimMesh = new THREE.Mesh(rimGeo, rimMat);
  wheelGroup.add(rimMesh);

  // Spokes based on style
  if (style === 'cyberDish') {
    // Solid aerodisc with brake vents
    const discGeo = new THREE.CylinderGeometry(radius * 0.68, radius * 0.68, width * 1.04, 24);
    discGeo.rotateZ(Math.PI / 2);
    const discMat = new THREE.MeshStandardMaterial({
      color: rimColor,
      metalness: 0.95,
      roughness: 0.15,
    });
    const disc = new THREE.Mesh(discGeo, discMat);
    wheelGroup.add(disc);

    // Accent vent ring
    const ventRingGeo = new THREE.TorusGeometry(radius * 0.45, 0.02, 8, 24);
    ventRingGeo.rotateY(Math.PI / 2);
    const ventRingMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const ring = new THREE.Mesh(ventRingGeo, ventRingMat);
    ring.position.x = width * 0.53;
    wheelGroup.add(ring);
  } else if (style === 'mesh12') {
    // 12-spoke motorsport mesh
    const spokeGeo = new THREE.BoxGeometry(radius * 1.35, width * 1.04, radius * 0.08);
    const spokeMat = new THREE.MeshStandardMaterial({
      color: rimColor,
      metalness: 0.95,
      roughness: 0.2,
    });
    for (let i = 0; i < 6; i++) {
      const spoke = new THREE.Mesh(spokeGeo, spokeMat);
      spoke.rotation.x = (i * Math.PI) / 6;
      wheelGroup.add(spoke);
    }
  } else if (style === 'concave') {
    // Deep concave monoblock
    const spokeGeo = new THREE.BoxGeometry(radius * 1.35, width * 1.04, radius * 0.16);
    const spokeMat = new THREE.MeshStandardMaterial({
      color: rimColor,
      metalness: 0.92,
      roughness: 0.18,
    });
    for (let i = 0; i < 4; i++) {
      const spoke = new THREE.Mesh(spokeGeo, spokeMat);
      spoke.rotation.x = (i * Math.PI) / 4;
      wheelGroup.add(spoke);
    }
  } else {
    // Classic 5-spoke star alloy
    const spokeGeo = new THREE.BoxGeometry(radius * 1.35, width * 1.04, radius * 0.14);
    const spokeMat = new THREE.MeshStandardMaterial({
      color: rimColor,
      metalness: 0.95,
      roughness: 0.15,
    });
    for (let i = 0; i < 3; i++) {
      const spoke = new THREE.Mesh(spokeGeo, spokeMat);
      spoke.rotation.x = (i * Math.PI) / 3;
      wheelGroup.add(spoke);
    }
  }

  // Center hubcap
  const hubGeo = new THREE.CylinderGeometry(radius * 0.22, radius * 0.22, width * 1.06, 16);
  hubGeo.rotateZ(Math.PI / 2);
  const hubMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    metalness: 0.9,
    roughness: 0.3,
  });
  const hubMesh = new THREE.Mesh(hubGeo, hubMat);
  wheelGroup.add(hubMesh);

  const composite = new THREE.Mesh();
  composite.add(wheelGroup);
  return composite;
}

export function buildCar3D(
  carId: string,
  bodyColorHex: string,
  isTraffic = false,
  customization?: Partial<CarCustomization>
): CarMeshContainer {
  const root = new THREE.Group() as CarMeshContainer;
  const bodyMeshes: THREE.Mesh[] = [];
  const wheels: THREE.Mesh[] = [];
  const headlights: THREE.Mesh[] = [];
  const taillights: THREE.Mesh[] = [];
  const exhausts: THREE.Mesh[] = [];
  const nitroFlames: THREE.Mesh[] = [];

  const mainColor = new THREE.Color(customization?.color || bodyColorHex);

  // Paint material with metallic clearcoat gloss
  const paintMat = new THREE.MeshPhysicalMaterial({
    color: mainColor,
    metalness: isTraffic ? 0.6 : 0.85,
    roughness: isTraffic ? 0.35 : 0.18,
    clearcoat: 0.9,
    clearcoatRoughness: 0.15,
  });

  // Secondary carbon / matte trim
  const carbonMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.6,
    metalness: 0.4,
  });

  // Tinted glass for windows
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x0f172a,
    roughness: 0.1,
    metalness: 0.9,
    transparent: true,
    opacity: 0.75,
  });

  // LED headlights
  const headLightMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    emissive: 0x38bdf8,
    emissiveIntensity: 2.5,
    roughness: 0.2,
  });

  // LED taillights
  const tailLightMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xff002b,
    emissiveIntensity: 2.8,
    roughness: 0.2,
  });

  // Exhaust chrome
  const exhaustMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.95,
    roughness: 0.15,
  });

  // 1. Lower Chassis base
  const chassisGeo = new THREE.BoxGeometry(2.1, 0.28, 4.4);
  const chassis = new THREE.Mesh(chassisGeo, carbonMat);
  chassis.position.y = 0.38;
  chassis.castShadow = true;
  chassis.receiveShadow = true;
  root.add(chassis);

  // 2. Main aerodynamic bodywork
  let mainBodyGeo: THREE.BufferGeometry;
  let cabinGeo: THREE.BufferGeometry;

  if (carId === 'car_valkyrie_hyper' || carId === 'car_shadow_stealth') {
    mainBodyGeo = new THREE.BoxGeometry(2.18, 0.48, 4.6);
    cabinGeo = new THREE.BoxGeometry(1.4, 0.45, 2.1);
  } else if (carId === 'car_crimson_fury' || carId === 'car_cyber_neon') {
    mainBodyGeo = new THREE.BoxGeometry(2.12, 0.46, 4.4);
    cabinGeo = new THREE.BoxGeometry(1.45, 0.44, 2.2);
  } else {
    mainBodyGeo = new THREE.BoxGeometry(2.0, 0.45, 4.2);
    cabinGeo = new THREE.BoxGeometry(1.4, 0.45, 2.1);
  }

  // Main body mesh
  const mainBody = new THREE.Mesh(mainBodyGeo, paintMat);
  mainBody.position.set(0, 0.58, 0);
  mainBody.castShadow = true;
  mainBody.receiveShadow = true;
  root.add(mainBody);
  bodyMeshes.push(mainBody);

  // Front slanted hood scoop / nose
  const noseGeo = new THREE.BoxGeometry(1.9, 0.22, 1.1);
  const nose = new THREE.Mesh(noseGeo, paintMat);
  nose.position.set(0, 0.5, 1.7);
  nose.rotation.x = 0.08;
  nose.castShadow = true;
  root.add(nose);
  bodyMeshes.push(nose);

  // Front splitter (aerodynamic carbon lip)
  const splitterGeo = new THREE.BoxGeometry(2.06, 0.06, 0.4);
  const splitter = new THREE.Mesh(splitterGeo, carbonMat);
  splitter.position.set(0, 0.26, 2.2);
  splitter.castShadow = true;
  root.add(splitter);

  // Cockpit / Glass cabin
  const cabin = new THREE.Mesh(cabinGeo, glassMat);
  cabin.position.set(0, 0.94, -0.2);
  cabin.castShadow = true;
  root.add(cabin);

  // Roof cap
  const roofCapGeo = new THREE.BoxGeometry(1.3, 0.06, 1.8);
  const roofCap = new THREE.Mesh(roofCapGeo, paintMat);
  roofCap.position.set(0, 1.18, -0.2);
  roofCap.castShadow = true;
  root.add(roofCap);
  bodyMeshes.push(roofCap);

  // Side vents
  const ventL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.25, 1.4), carbonMat);
  ventL.position.set(-1.08, 0.56, -0.3);
  root.add(ventL);

  const ventR = ventL.clone();
  ventR.position.x = 1.08;
  root.add(ventR);

  // Diffuser
  const diffuser = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.24, 0.3), carbonMat);
  diffuser.position.set(0, 0.38, -2.15);
  root.add(diffuser);

  // Spoiler customization logic
  const spoilerType: SpoilerStyle = customization?.spoiler || (
    carId === 'car_valkyrie_hyper' ? 'extremeCarbon' :
    carId === 'car_cyber_neon' ? 'cyberFins' :
    carId === 'car_apex_phantom' || carId === 'car_crimson_fury' ? 'gtWing' : 'none'
  );

  if (spoilerType === 'lip') {
    const lip = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.08, 0.22), carbonMat);
    lip.position.set(0, 0.88, -2.05);
    lip.rotation.x = -0.15;
    root.add(lip);
  } else if (spoilerType === 'gtWing') {
    const wing = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.07, 0.4), paintMat);
    wing.position.set(0, 1.35, -1.9);
    wing.castShadow = true;
    root.add(wing);
    bodyMeshes.push(wing);

    [-0.65, 0.65].forEach((x) => {
      const strut = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.45, 0.15), carbonMat);
      strut.position.set(x, 1.1, -1.9);
      root.add(strut);
    });
  } else if (spoilerType === 'cyberFins') {
    // Twin vertical angular fins
    [-0.85, 0.85].forEach((x) => {
      const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.55, 0.7), paintMat);
      fin.position.set(x, 1.15, -1.85);
      fin.rotation.z = x > 0 ? -0.12 : 0.12;
      root.add(fin);
      bodyMeshes.push(fin);

      // Neon accent edge on fins
      const edge = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.72), new THREE.MeshBasicMaterial({ color: 0x06b6d4 }));
      edge.position.set(x, 1.42, -1.85);
      root.add(edge);
    });
  } else if (spoilerType === 'extremeCarbon') {
    // Valkyrie dual element wide wing
    const wingUpper = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.08, 0.45), carbonMat);
    wingUpper.position.set(0, 1.46, -1.95);
    wingUpper.castShadow = true;
    root.add(wingUpper);

    [-0.75, 0.75].forEach((x) => {
      const pylon = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.56, 0.22), carbonMat);
      pylon.position.set(x, 1.18, -1.95);
      root.add(pylon);
    });
  }

  // Wheels with custom style and rim color
  const wheelRadius = 0.38;
  const wheelWidth = 0.3;
  const wheelStyle: WheelStyle = customization?.wheelStyle || 'sport5';
  const wheelColorHex = customization?.wheelColor || '#d1d5db';

  const wheelPositions = [
    { x: -1.06, y: 0.38, z: 1.35 },
    { x: 1.06, y: 0.38, z: 1.35 },
    { x: -1.08, y: 0.40, z: -1.35 },
    { x: 1.08, y: 0.40, z: -1.35 },
  ];

  wheelPositions.forEach((pos) => {
    const wheel = createProceduralWheel(wheelRadius, wheelWidth, wheelStyle, wheelColorHex);
    wheel.position.set(pos.x, pos.y, pos.z);
    root.add(wheel);
    wheels.push(wheel);
  });

  // Headlights
  [-0.72, 0.72].forEach((x) => {
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.1, 0.08), headLightMat);
    head.position.set(x, 0.54, 2.18);
    head.rotation.y = x > 0 ? -0.1 : 0.1;
    root.add(head);
    headlights.push(head);
  });

  // Taillights
  [-0.55, 0.55].forEach((x) => {
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.08, 0.06), tailLightMat);
    tail.position.set(x, 0.66, -2.18);
    root.add(tail);
    taillights.push(tail);
  });

  // Exhausts
  [-0.35, 0.35].forEach((x) => {
    const exhGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.22, 12);
    exhGeo.rotateX(Math.PI / 2);
    const exh = new THREE.Mesh(exhGeo, exhaustMat);
    exh.position.set(x, 0.34, -2.24);
    root.add(exh);
    exhausts.push(exh);

    // Nitro flame
    const flameGeo = new THREE.ConeGeometry(0.09, 0.6, 12);
    flameGeo.rotateX(-Math.PI / 2);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0x00d4ff,
      transparent: true,
      opacity: 0.9,
    });
    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(x, 0.34, -2.55);
    flame.visible = false;
    root.add(flame);
    nitroFlames.push(flame);
  });

  // Neon Underglow
  let underglowMesh: THREE.Mesh | null = null;
  const underglowChoice = customization?.neonUnderglow || mainColor.getHexString();

  if (!isTraffic && underglowChoice !== 'none') {
    const underGeo = new THREE.PlaneGeometry(2.1, 4.2);
    underGeo.rotateX(-Math.PI / 2);
    const underMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(underglowChoice.startsWith('#') ? underglowChoice : `#${underglowChoice}`),
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    underglowMesh = new THREE.Mesh(underGeo, underMat);
    underglowMesh.position.y = 0.08;
    root.add(underglowMesh);
  }

  // Ground Contact shadow
  const shadowGeo = new THREE.PlaneGeometry(2.4, 4.6);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.65,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.03;
  root.add(shadow);

  root.userData = {
    wheels,
    headlights,
    taillights,
    exhausts,
    underglow: underglowMesh,
    bodyMeshes,
    nitroFlames,
  };

  return root;
}

// Dedicated Police Interceptor Pursuit Cruiser
export function buildPoliceCruiser(): CarMeshContainer {
  const root = new THREE.Group() as CarMeshContainer;
  const wheels: THREE.Mesh[] = [];

  // Black and white police bodywork
  const blackMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.8, roughness: 0.2 });
  const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, metalness: 0.6, roughness: 0.25 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.9, transparent: true, opacity: 0.85 });

  // Chassis
  const mainBody = new THREE.Mesh(new THREE.BoxGeometry(2.15, 0.5, 4.4), blackMat);
  mainBody.position.set(0, 0.6, 0);
  mainBody.castShadow = true;
  root.add(mainBody);

  // White front doors / middle section
  const whiteDoor = new THREE.Mesh(new THREE.BoxGeometry(2.17, 0.48, 1.8), whiteMat);
  whiteDoor.position.set(0, 0.6, 0);
  root.add(whiteDoor);

  // Cabin
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.48, 2.3), glassMat);
  cabin.position.set(0, 1.0, -0.2);
  root.add(cabin);

  // White Roof
  const roof = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.06, 1.9), whiteMat);
  roof.position.set(0, 1.25, -0.2);
  root.add(roof);

  // Heavy duty steel push-bumper / bull-bar on front
  const bumperMat = new THREE.MeshStandardMaterial({ color: 0x030712, metalness: 0.9, roughness: 0.2 });
  const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.4, 0.2), bumperMat);
  bumper.position.set(0, 0.45, 2.3);
  root.add(bumper);

  // Overhead Emergency Siren Lightbar
  const barBase = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 0.22), bumperMat);
  barBase.position.set(0, 1.31, -0.1);
  root.add(barBase);

  // Blue Strobe LED
  const blueLightMat = new THREE.MeshBasicMaterial({ color: 0x0066ff });
  const blueLight = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.18), blueLightMat);
  blueLight.position.set(-0.3, 1.38, -0.1);
  root.add(blueLight);

  // Red Strobe LED
  const redLightMat = new THREE.MeshBasicMaterial({ color: 0xff002b });
  const redLight = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.18), redLightMat);
  redLight.position.set(0.3, 1.38, -0.1);
  root.add(redLight);

  // 4 Wheels
  const wheelRadius = 0.38;
  const wheelPositions = [
    { x: -1.08, y: 0.38, z: 1.35 },
    { x: 1.08, y: 0.38, z: 1.35 },
    { x: -1.08, y: 0.40, z: -1.35 },
    { x: 1.08, y: 0.40, z: -1.35 },
  ];
  wheelPositions.forEach((pos) => {
    const wheel = createProceduralWheel(wheelRadius, 0.3, 'mesh12', '#18181b');
    wheel.position.set(pos.x, pos.y, pos.z);
    root.add(wheel);
    wheels.push(wheel);
  });

  // Contact shadow
  const shadowGeo = new THREE.PlaneGeometry(2.4, 4.6);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.6, depthWrite: false });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.03;
  root.add(shadow);

  root.userData = {
    wheels,
    headlights: [],
    taillights: [],
    exhausts: [],
    underglow: null,
    bodyMeshes: [mainBody],
    nitroFlames: [],
    policeLightBlue: blueLight,
    policeLightRed: redLight,
  };

  return root;
}
