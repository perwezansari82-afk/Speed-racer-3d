import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { buildCar3D, CarMeshContainer } from './CarModels';
import { CarCustomization } from '../types/game';

export class GarageScene {
  private container: HTMLDivElement;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private currentCar: CarMeshContainer | null = null;
  private turntablePlatform!: THREE.Group;
  private frameId = 0;
  private isDestroyed = false;

  // Interaction
  private isDragging = false;
  private previousMouseX = 0;
  private targetRotationY = 0.6;
  private currentRotationY = 0.6;
  private autoRotate = true;

  constructor(
    container: HTMLDivElement,
    initialCarId: string,
    initialColorHex: string,
    initialCustomization?: Partial<CarCustomization>
  ) {
    this.container = container;
    this.init();
    this.buildShowroom();
    this.loadCar(initialCarId, initialColorHex, initialCustomization);
    this.setupEvents();
    this.startLoop();
  }

  private init() {
    const width = this.container.clientWidth || 600;
    const height = this.container.clientHeight || 450;

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.renderer.shadowMap.enabled = !isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x070b13);

    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();
    } catch {
      // fallback
    }

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.camera.position.set(0, 2.6, 6.8);
    this.camera.lookAt(0, 0.6, 0);
  }

  private buildShowroom() {
    this.turntablePlatform = new THREE.Group();
    this.scene.add(this.turntablePlatform);

    // 1. Circular Turntable Platform
    const platRadius = 3.6;
    const platGeo = new THREE.CylinderGeometry(platRadius, platRadius * 1.05, 0.35, 48);
    const platMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.25,
      metalness: 0.85,
    });
    const platform = new THREE.Mesh(platGeo, platMat);
    platform.position.y = -0.18;
    platform.receiveShadow = true;
    this.turntablePlatform.add(platform);

    // 2. Halo Glowing Rim
    const haloGeo = new THREE.TorusGeometry(platRadius + 0.02, 0.06, 16, 64);
    haloGeo.rotateX(Math.PI / 2);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0x00d4ff,
    });
    const halo = new THREE.Mesh(haloGeo, haloMat);
    halo.position.y = -0.02;
    this.turntablePlatform.add(halo);

    // 3. Grid floor pattern surrounding the stage
    const gridGeo = new THREE.PlaneGeometry(30, 30);
    gridGeo.rotateX(-Math.PI / 2);
    const gridMat = new THREE.MeshStandardMaterial({
      color: 0x030712,
      roughness: 0.85,
      metalness: 0.2,
    });
    const grid = new THREE.Mesh(gridGeo, gridMat);
    grid.position.y = -0.36;
    grid.receiveShadow = true;
    this.scene.add(grid);

    // Studio Lighting
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    this.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x06b6d4, 1.4);
    fillLight.position.set(-6, 5, -4);
    this.scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xf97316, 1.8);
    rimLight.position.set(0, 4, -6);
    this.scene.add(rimLight);

    const spot = new THREE.SpotLight(0xffffff, 2.2, 20, Math.PI / 4, 0.5);
    spot.position.set(0, 7, 0);
    spot.target = platform;
    this.scene.add(spot);
  }

  public loadCar(carId: string, colorHex: string, customization?: Partial<CarCustomization>) {
    if (this.currentCar) {
      this.turntablePlatform.remove(this.currentCar);
    }
    this.currentCar = buildCar3D(carId, colorHex, false, customization);
    this.currentCar.position.set(0, 0, 0);
    this.turntablePlatform.add(this.currentCar);
  }

  public updateColor(colorHex: string) {
    if (!this.currentCar) return;
    const newColor = new THREE.Color(colorHex);

    this.currentCar.userData.bodyMeshes.forEach((mesh) => {
      if (Array.isArray(mesh.material)) {
        mesh.material.forEach((m) => {
          if ('color' in m) (m as THREE.MeshStandardMaterial).color.copy(newColor);
        });
      } else if (mesh.material && 'color' in mesh.material) {
        (mesh.material as THREE.MeshStandardMaterial).color.copy(newColor);
      }
    });
  }

  public updateNeonUnderglow(colorHex: string) {
    if (!this.currentCar) return;
    if (this.currentCar.userData.underglow) {
      if (colorHex === 'none') {
        this.currentCar.userData.underglow.visible = false;
      } else {
        this.currentCar.userData.underglow.visible = true;
        const underMat = this.currentCar.userData.underglow.material as THREE.MeshBasicMaterial;
        underMat.color.set(colorHex);
      }
    }
  }

  private setupEvents() {
    const el = this.container;

    const onPointerDown = (clientX: number) => {
      this.isDragging = true;
      this.autoRotate = false;
      this.previousMouseX = clientX;
    };

    const onPointerMove = (clientX: number) => {
      if (!this.isDragging) return;
      const deltaX = clientX - this.previousMouseX;
      this.previousMouseX = clientX;
      this.targetRotationY += deltaX * 0.008;
    };

    const onPointerUp = () => {
      this.isDragging = false;
      setTimeout(() => {
        if (!this.isDragging) this.autoRotate = true;
      }, 3000);
    };

    el.addEventListener('mousedown', (e) => onPointerDown(e.clientX));
    window.addEventListener('mousemove', (e) => onPointerMove(e.clientX));
    window.addEventListener('mouseup', onPointerUp);

    el.addEventListener('touchstart', (e) => {
      if (e.touches.length > 0) onPointerDown(e.touches[0].clientX);
    }, { passive: true });

    window.addEventListener('touchmove', (e) => {
      if (e.touches.length > 0) onPointerMove(e.touches[0].clientX);
    }, { passive: true });

    window.addEventListener('touchend', onPointerUp);
    window.addEventListener('resize', this.handleResize);
  }

  private handleResize = () => {
    if (this.isDestroyed || !this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private startLoop() {
    const tick = () => {
      if (this.isDestroyed) return;
      this.frameId = requestAnimationFrame(tick);

      if (this.autoRotate) {
        this.targetRotationY += 0.004;
      }

      this.currentRotationY = THREE.MathUtils.damp(this.currentRotationY, this.targetRotationY, 10, 0.016);
      this.turntablePlatform.rotation.y = this.currentRotationY;

      this.renderer.render(this.scene, this.camera);
    };
    this.frameId = requestAnimationFrame(tick);
  }

  public destroy() {
    this.isDestroyed = true;
    cancelAnimationFrame(this.frameId);
    window.removeEventListener('resize', this.handleResize);
    try {
      if (this.renderer.domElement && this.renderer.domElement.parentNode) {
        this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
      }
      this.renderer.dispose();
    } catch {
      // ignore
    }
  }
}
