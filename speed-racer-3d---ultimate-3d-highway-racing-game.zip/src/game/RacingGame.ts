import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  CarDefinition,
  CarUpgrades,
  CarCustomization,
  GameMode,
  WeatherMode,
  RaceResult,
  RemotePlayerState
} from '../types/game';
import { buildCar3D, buildPoliceCruiser, CarMeshContainer } from './CarModels';
import { buildTrafficVehicle, TrafficVehicle } from './TrafficCars';
import { sound } from '../utils/audio';

const _vec3 = new THREE.Vector3();
const _boxPlayer = new THREE.Box3();
const _boxTarget = new THREE.Box3();

export interface GameHUDState {
  speedKmh: number;
  distanceMeters: number;
  score: number;
  coinsEarned: number;
  nitroPercent: number;
  timeRemainingSeconds: number;
  nearMissCombo: number;
  magnetActive: boolean;
  isPaused: boolean;
  isGameOver: boolean;
  wantedLevel: number;
  policeDistance: number;
  policeEvadedCount: number;
  multiplayerPlayers: RemotePlayerState[];
  currentRank: number;
  isMultiplayerConnected: boolean;
}

export interface RacingGameOptions {
  container: HTMLDivElement;
  carDef: CarDefinition;
  upgrades: CarUpgrades;
  carColor: string;
  customization?: Partial<CarCustomization>;
  gameMode: GameMode;
  weather: WeatherMode;
  playerName: string;
  multiplayerRoomId?: string;
  onHUDUpdate: (hud: GameHUDState) => void;
  onGameOver: (result: RaceResult) => void;
  onNearMissBonus: (combo: number) => void;
  onCheckpointHit?: () => void;
  onMissionProgress?: (type: 'dist' | 'nearmiss' | 'coins' | 'speed', amount: number) => void;
}

const LANE_X_POSITIONS = [-5.25, -1.75, 1.75, 5.25];
const ROAD_WIDTH = 14;

export class RacingGame {
  private container: HTMLDivElement;
  private carDef: CarDefinition;
  private upgrades: CarUpgrades;
  private carColor: string;
  private customization?: Partial<CarCustomization>;
  private gameMode: GameMode;
  private weather: WeatherMode;
  private playerName: string;
  private multiplayerRoomId: string;
  private onHUDUpdate: (hud: GameHUDState) => void;
  private onGameOver: (result: RaceResult) => void;
  private onNearMissBonus: (combo: number) => void;
  private onCheckpointHit?: () => void;
  private onMissionProgress?: (type: 'dist' | 'nearmiss' | 'coins' | 'speed', amount: number) => void;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private frameId = 0;
  private isDestroyed = false;

  // Car and physics
  private playerCar!: CarMeshContainer;
  private carX = 0;
  private carZ = 0;
  private carSpeed = 0; // m/s
  private maxSpeed = 65; // m/s (~234 km/h base)
  private acceleration = 22; // m/s^2
  private handlingFactor = 1.0;
  private carRoll = 0;
  private carYaw = 0;

  // Nitro
  private nitro = 100;
  private isNitroActive = false;
  private nitroDurationFactor = 1.0;

  // Road chunks
  private roadChunks: THREE.Group[] = [];
  private chunkLength = 120;
  private totalChunks = 5;

  // Traffic
  private trafficList: TrafficVehicle[] = [];
  private maxTraffic = 8;

  // Police Chase System
  private policeCruisers: CarMeshContainer[] = [];
  private wantedLevel = 1; // 1 to 5 Stars
  private policeDistance = 35; // meters behind player
  private policeEvadedCount = 0;
  private policeSirenTimer = 0;
  private policeRoadblockTimer = 0;

  // Collectibles
  private coins: { mesh: THREE.Mesh; type: 'gold' | 'diamond' | 'nitro' | 'magnet'; active: boolean }[] = [];
  private magnetTimer = 0;

  // Atmospheric particle systems
  private weatherParticles: THREE.Points | null = null;
  private oceanWaterMesh: THREE.Mesh | null = null;

  // Game state
  private isPaused = false;
  private isGameOver = false;
  private distance = 0;
  private lastReportedDist = 0;
  private score = 0;
  private coinsCollected = 0;
  private nearMisses = 0;
  private nearMissCombo = 0;
  private comboResetTimer = 0;
  private timeSurvived = 0;
  private timeRemaining = 60;
  private nextCheckpointDist = 450;
  private topSpeedReached = 0;

  // Crash sequence
  private isCrashing = false;
  private crashTimer = 0;
  private crashVelocity = new THREE.Vector3();
  private crashSparks: THREE.Points | null = null;

  // Multiplayer WebSocket
  private ws: WebSocket | null = null;
  private myPlayerId: string | null = null;
  private remotePlayers = new Map<string, { state: RemotePlayerState; mesh: CarMeshContainer; nameSprite: THREE.Sprite }>();
  private remotePlayerList: RemotePlayerState[] = [];
  private lastNetworkSendTime = 0;
  private isMultiplayerConnected = false;

  // Input states
  public inputs = {
    left: false,
    right: false,
    accelerate: false,
    brake: false,
    nitro: false,
    steerAxis: 0,
  };

  constructor(options: RacingGameOptions) {
    this.container = options.container;
    this.carDef = options.carDef;
    this.upgrades = options.upgrades;
    this.carColor = options.carColor;
    this.customization = options.customization;
    this.gameMode = options.gameMode;
    this.weather = options.weather;
    this.playerName = options.playerName || 'VelocityRacer';
    this.multiplayerRoomId = options.multiplayerRoomId || 'GLOBAL_CIRCUIT';
    this.onHUDUpdate = options.onHUDUpdate;
    this.onGameOver = options.onGameOver;
    this.onNearMissBonus = options.onNearMissBonus;
    this.onCheckpointHit = options.onCheckpointHit;
    this.onMissionProgress = options.onMissionProgress;

    this.calculateStats();
    this.initThree();
    this.buildScene();
    this.setupListeners();

    if (this.gameMode === 'policeChase') {
      this.initPoliceChase();
    } else if (this.gameMode === 'multiplayer') {
      this.initMultiplayerWebSocket();
    }

    this.startLoop();

    sound.startEngine();
    sound.startMusic();
  }

  private calculateStats() {
    const speedRating = this.carDef.baseSpeed + this.upgrades.speed * 0.7;
    this.maxSpeed = 55 + speedRating * 4.2;

    const accelRating = this.carDef.baseAcceleration + this.upgrades.engine * 0.7;
    this.acceleration = 16 + accelRating * 2.8;

    const handlingRating = this.carDef.baseHandling + this.upgrades.handling * 0.7;
    this.handlingFactor = 0.75 + (handlingRating / 10) * 0.7;

    const nitroRating = this.carDef.baseNitro + this.upgrades.nitro * 0.7;
    this.nitroDurationFactor = 0.8 + (nitroRating / 10) * 0.6;

    if (this.gameMode === 'trafficChallenge') {
      this.maxTraffic = 14; // heavy dense traffic
    } else if (this.gameMode === 'coinRush') {
      this.maxTraffic = 4;
    } else {
      this.maxTraffic = 8;
    }
  }

  private initThree() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();

    try {
      const pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();
    } catch {
      // fallback
    }

    this.camera = new THREE.PerspectiveCamera(60, width / height, 0.2, 500);
    this.camera.position.set(0, 4.2, -7.5);
    this.camera.lookAt(0, 1.5, 6);
  }

  private buildScene() {
    this.setupWeatherAndLights();

    for (let i = -1; i < this.totalChunks - 1; i++) {
      const chunk = this.createRoadChunk(i * this.chunkLength);
      this.scene.add(chunk);
      this.roadChunks.push(chunk);
    }

    // Build Player Car with visual customizations
    this.playerCar = buildCar3D(this.carDef.id, this.carColor, false, this.customization);
    this.playerCar.position.set(0, 0, 0);
    this.scene.add(this.playerCar);

    // Initial Traffic
    const count = this.gameMode === 'trafficChallenge' ? 12 : this.maxTraffic;
    for (let i = 0; i < count; i++) {
      this.spawnTrafficCar(60 + i * (this.gameMode === 'trafficChallenge' ? 24 : 45));
    }

    // Initial Collectibles
    this.spawnInitialCoins();
  }

  // --- 8 WEATHER ENVIRONMENTS & ATMOSPHERES ---
  private setupWeatherAndLights() {
    let skyColor = 0x60a5fa;
    let fogColor = 0xbae6fd;
    let lightIntensity = 2.0;

    switch (this.weather) {
      case 'night':
        skyColor = 0x030712;
        fogColor = 0x020617;
        lightIntensity = 0.6;
        break;
      case 'rain':
        skyColor = 0x1e293b;
        fogColor = 0x0f172a;
        lightIntensity = 1.2;
        break;
      case 'snow':
        skyColor = 0x94a3b8;
        fogColor = 0xcfd8dc;
        lightIntensity = 1.5;
        break;
      case 'desert':
        skyColor = 0xd97706;
        fogColor = 0x92400e;
        lightIntensity = 2.4;
        break;
      case 'forest':
        skyColor = 0x14532d;
        fogColor = 0x064e3b;
        lightIntensity = 1.4;
        break;
      case 'ocean':
        skyColor = 0x0284c7;
        fogColor = 0x38bdf8;
        lightIntensity = 2.1;
        break;
      case 'sunset':
        skyColor = 0x3b0764;
        fogColor = 0x4c0519;
        lightIntensity = 1.6;
        break;
      case 'day':
      default:
        skyColor = 0x60a5fa;
        fogColor = 0xbae6fd;
        lightIntensity = 2.0;
        break;
    }

    this.scene.background = new THREE.Color(skyColor);
    this.scene.fog = new THREE.FogExp2(fogColor, this.weather === 'desert' || this.weather === 'snow' ? 0.009 : 0.0075);

    // Directional Sun / Moon Light
    const sunLight = new THREE.DirectionalLight(
      this.weather === 'night' ? 0x93c5fd : this.weather === 'sunset' || this.weather === 'desert' ? 0xf97316 : 0xfff7ed,
      lightIntensity
    );
    sunLight.position.set(25, 45, 30);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 120;
    sunLight.shadow.camera.left = -25;
    sunLight.shadow.camera.right = 25;
    sunLight.shadow.camera.top = 25;
    sunLight.shadow.camera.bottom = -25;
    sunLight.shadow.bias = -0.0005;
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(skyColor, 0x0f172a, 1.2);
    this.scene.add(hemiLight);

    // Night stars & moon
    if (this.weather === 'night') {
      const starCount = 600;
      const starGeo = new THREE.BufferGeometry();
      const starPositions = new Float32Array(starCount * 3);
      for (let i = 0; i < starCount; i++) {
        starPositions[i * 3] = (Math.random() - 0.5) * 400;
        starPositions[i * 3 + 1] = 40 + Math.random() * 90;
        starPositions[i * 3 + 2] = (Math.random() - 0.5) * 400;
      }
      starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
      const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.8, transparent: true, opacity: 0.9 });
      this.scene.add(new THREE.Points(starGeo, starMat));

      // Glowing Moon
      const moonGeo = new THREE.SphereGeometry(14, 24, 24);
      const moonMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
      const moon = new THREE.Mesh(moonGeo, moonMat);
      moon.position.set(80, 110, 220);
      this.scene.add(moon);
    }

    // Weather Particles (Rain / Snow / Desert Dust)
    if (this.weather === 'rain' || this.weather === 'snow' || this.weather === 'desert') {
      const pCount = this.weather === 'rain' ? 1400 : this.weather === 'snow' ? 1200 : 700;
      const pGeo = new THREE.BufferGeometry();
      const pPositions = new Float32Array(pCount * 3);
      for (let i = 0; i < pCount; i++) {
        pPositions[i * 3] = (Math.random() - 0.5) * 80;
        pPositions[i * 3 + 1] = Math.random() * 45;
        pPositions[i * 3 + 2] = (Math.random() - 0.5) * 160;
      }
      pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));

      let pColor = 0x93c5fd;
      let pSize = 0.2;
      if (this.weather === 'snow') {
        pColor = 0xffffff;
        pSize = 0.35;
      } else if (this.weather === 'desert') {
        pColor = 0xd97706;
        pSize = 0.45;
      }

      const pMat = new THREE.PointsMaterial({
        color: pColor,
        size: pSize,
        transparent: true,
        opacity: 0.75,
      });
      this.weatherParticles = new THREE.Points(pGeo, pMat);
      this.scene.add(this.weatherParticles);
    }

    // Ocean Mode: water plane on the right
    if (this.weather === 'ocean') {
      const waterGeo = new THREE.PlaneGeometry(80, 400, 32, 32);
      waterGeo.rotateX(-Math.PI / 2);
      const waterMat = new THREE.MeshStandardMaterial({
        color: 0x0284c7,
        roughness: 0.1,
        metalness: 0.8,
        transparent: true,
        opacity: 0.88,
      });
      this.oceanWaterMesh = new THREE.Mesh(waterGeo, waterMat);
      this.oceanWaterMesh.position.set(48, -0.2, 100);
      this.scene.add(this.oceanWaterMesh);
    }
  }

  // --- ROAD & ENVIRONMENT CHUNKS ---
  private createRoadChunk(zOffset: number): THREE.Group {
    const chunk = new THREE.Group();
    chunk.position.z = zOffset;

    // Asphalt surface (reflectivity depends on weather)
    let asphaltColor = 0x181e26;
    let asphaltRoughness = 0.82;
    let asphaltMetalness = 0.1;

    if (this.weather === 'rain') {
      asphaltColor = 0x090d14;
      asphaltRoughness = 0.15;
      asphaltMetalness = 0.55;
    } else if (this.weather === 'snow') {
      asphaltColor = 0x475569;
      asphaltRoughness = 0.7;
    } else if (this.weather === 'desert') {
      asphaltColor = 0x292524;
      asphaltRoughness = 0.85;
    }

    const asphaltGeo = new THREE.PlaneGeometry(ROAD_WIDTH, this.chunkLength);
    asphaltGeo.rotateX(-Math.PI / 2);
    const asphaltMat = new THREE.MeshStandardMaterial({
      color: asphaltColor,
      roughness: asphaltRoughness,
      metalness: asphaltMetalness,
    });
    const asphalt = new THREE.Mesh(asphaltGeo, asphaltMat);
    asphalt.position.y = 0;
    asphalt.receiveShadow = true;
    chunk.add(asphalt);

    // Shoulder & verge color (green for day/forest, white for snow, sand for desert)
    let vergeColor = 0x334155;
    if (this.weather === 'snow') vergeColor = 0xe2e8f0;
    else if (this.weather === 'desert') vergeColor = 0xb45309;
    else if (this.weather === 'forest' || this.weather === 'day') vergeColor = 0x15803d;

    const shoulderMat = new THREE.MeshStandardMaterial({ color: vergeColor, roughness: 0.85 });
    [-ROAD_WIDTH / 2 - 1.25, ROAD_WIDTH / 2 + 1.25].forEach((x) => {
      const shoulderGeo = new THREE.BoxGeometry(2.5, 0.22, this.chunkLength);
      const shoulder = new THREE.Mesh(shoulderGeo, shoulderMat);
      shoulder.position.set(x, 0.08, 0);
      shoulder.receiveShadow = true;
      chunk.add(shoulder);
    });

    // Guard rails
    const railMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.85, roughness: 0.3 });
    [-ROAD_WIDTH / 2 - 2.4, ROAD_WIDTH / 2 + 2.4].forEach((x) => {
      const railGeo = new THREE.BoxGeometry(0.2, 0.65, this.chunkLength);
      const rail = new THREE.Mesh(railGeo, railMat);
      rail.position.set(x, 0.45, 0);
      chunk.add(rail);
    });

    // Lane markings
    const dashMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
    const dashGeo = new THREE.PlaneGeometry(0.2, 3.5);
    dashGeo.rotateX(-Math.PI / 2);
    [-3.5, 0, 3.5].forEach((x) => {
      for (let z = -this.chunkLength / 2; z < this.chunkLength / 2; z += 9) {
        const dash = new THREE.Mesh(dashGeo, dashMat);
        dash.position.set(x, 0.02, z + 2);
        chunk.add(dash);
      }
    });

    // Street Lamps
    const lampMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8 });
    const lampBulbMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });

    for (let z = -this.chunkLength / 2 + 10; z < this.chunkLength / 2; z += 40) {
      [-ROAD_WIDTH / 2 - 2.8, ROAD_WIDTH / 2 + 2.8].forEach((x, isRight) => {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 7, 8), lampMat);
        pole.position.set(x, 3.5, z);
        chunk.add(pole);

        const arm = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 0.12), lampMat);
        arm.position.set(isRight ? x - 1.0 : x + 1.0, 6.9, z);
        chunk.add(arm);

        const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 0.3), lampBulbMat);
        bulb.position.set(isRight ? x - 1.8 : x + 1.8, 6.78, z);
        chunk.add(bulb);
      });
    }

    // Roadside Props & Scenery by Weather
    if (this.weather === 'forest' || this.weather === 'snow' || this.weather === 'day') {
      // Procedural trees (pines or palms)
      for (let z = -this.chunkLength / 2 + 6; z < this.chunkLength / 2; z += 18) {
        [-ROAD_WIDTH / 2 - 5, ROAD_WIDTH / 2 + 5].forEach((x) => {
          const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.35, 3.5, 8), new THREE.MeshStandardMaterial({ color: 0x543d2b, roughness: 0.9 }));
          trunk.position.set(x + (Math.random() - 0.5) * 2, 1.75, z);
          chunk.add(trunk);

          const foliageColor = this.weather === 'snow' ? 0xdfe6e9 : 0x166534;
          const foliage = new THREE.Mesh(new THREE.ConeGeometry(2.2, 5.5, 8), new THREE.MeshStandardMaterial({ color: foliageColor, roughness: 0.7 }));
          foliage.position.set(trunk.position.x, 5.2, z);
          chunk.add(foliage);
        });
      }
    } else if (this.weather === 'desert') {
      // Sand dunes & rock outcrops
      for (let z = -this.chunkLength / 2 + 10; z < this.chunkLength / 2; z += 25) {
        [-20, 20].forEach((x) => {
          const dune = new THREE.Mesh(new THREE.SphereGeometry(12, 16, 8), new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.95 }));
          dune.position.set(x, 2, z);
          dune.scale.set(1.5, 0.4, 2);
          chunk.add(dune);
        });
      }
    } else {
      // City buildings & skyscrapers
      const buildingPalette = [0x0f172a, 0x1e293b, 0x111827, 0x090d16];
      for (let z = -this.chunkLength / 2 + 15; z < this.chunkLength / 2; z += 30) {
        [-24, 24].forEach((x) => {
          const bHeight = 25 + Math.random() * 45;
          const bMat = new THREE.MeshStandardMaterial({
            color: buildingPalette[Math.floor(Math.random() * buildingPalette.length)],
            roughness: 0.4,
            metalness: 0.6,
          });
          const building = new THREE.Mesh(new THREE.BoxGeometry(14, bHeight, 18), bMat);
          building.position.set(x, bHeight / 2, z);
          chunk.add(building);

          // Neon billboards
          if (Math.random() > 0.4) {
            const board = new THREE.Mesh(
              new THREE.BoxGeometry(7, 3, 0.4),
              new THREE.MeshBasicMaterial({ color: Math.random() > 0.5 ? 0x06b6d4 : 0xf97316 })
            );
            board.position.set(x > 0 ? x - 7 : x + 7, 12, z);
            chunk.add(board);
          }
        });
      }
    }

    return chunk;
  }

  // --- TRAFFIC ---
  private spawnTrafficCar(targetZ: number) {
    const types: ('sedan' | 'suv' | 'truck' | 'sport')[] = ['sedan', 'sedan', 'suv', 'truck', 'sport'];
    const chosenType = types[Math.floor(Math.random() * types.length)];
    const traffic = buildTrafficVehicle(chosenType);

    const laneIndex = Math.floor(Math.random() * LANE_X_POSITIONS.length);
    const laneX = LANE_X_POSITIONS[laneIndex];

    let speed = 25 + Math.random() * 15;
    if (chosenType === 'truck') speed = 18 + Math.random() * 6;
    if (chosenType === 'sport') speed = 34 + Math.random() * 10;

    traffic.position.set(laneX, 0, targetZ);
    traffic.userData.speed = speed;
    traffic.userData.targetSpeed = speed;
    traffic.userData.lane = laneIndex;
    traffic.userData.passedPlayer = false;

    this.scene.add(traffic);
    this.trafficList.push(traffic);
  }

  // --- POLICE CHASE SYSTEM ---
  private initPoliceChase() {
    this.wantedLevel = 1;
    this.policeDistance = 35;
    sound.startPoliceSiren();

    // Spawn 2 initial pursuit cruisers behind player
    for (let i = 0; i < 2; i++) {
      const cruiser = buildPoliceCruiser();
      cruiser.position.set(i === 0 ? -2.5 : 2.5, 0, -35 - i * 12);
      this.scene.add(cruiser);
      this.policeCruisers.push(cruiser);
    }
  }

  private updatePoliceChase(delta: number) {
    if (this.gameMode !== 'policeChase' || this.isCrashing || this.isGameOver) return;

    this.policeSirenTimer += delta * 12;
    const isBlueStrobe = Math.sin(this.policeSirenTimer) > 0;

    // Wanted Level escalation
    if (this.distance > 800 && this.wantedLevel < 2) this.wantedLevel = 2;
    if (this.distance > 1800 && this.wantedLevel < 3) this.wantedLevel = 3;
    if (this.distance > 3000 && this.wantedLevel < 4) this.wantedLevel = 4;
    if (this.distance > 4500 && this.wantedLevel < 5) this.wantedLevel = 5;

    // Police target speed scales with wanted level
    const policeBaseSpeed = this.carSpeed * (0.92 + this.wantedLevel * 0.02);

    this.policeCruisers.forEach((cruiser, idx) => {
      // Strobe emergency lights
      if (cruiser.userData.policeLightBlue) {
        cruiser.userData.policeLightBlue.visible = isBlueStrobe;
      }
      if (cruiser.userData.policeLightRed) {
        cruiser.userData.policeLightRed.visible = !isBlueStrobe;
      }

      // Rotate wheels
      const rot = (this.carSpeed * delta) / 0.38;
      cruiser.userData.wheels.forEach((w) => {
        w.children[0].rotation.x += rot;
      });

      // Target position
      const desiredZ = this.carZ - (18 + idx * 14 - (this.wantedLevel * 2));
      const desiredX = idx === 0 ? this.carX - 1.8 : this.carX + 1.8;

      cruiser.position.z = THREE.MathUtils.damp(cruiser.position.z, desiredZ, 2.5, delta);
      cruiser.position.x = THREE.MathUtils.damp(cruiser.position.x, desiredX, 3.5, delta);

      // Distance from player
      const distToPlayer = this.carZ - cruiser.position.z;
      this.policeDistance = Math.max(5, Math.round(distToPlayer));

      // BUSTED collision check if police overtakes and box rams player
      if (Math.abs(cruiser.position.z - this.carZ) < 3.2 && Math.abs(cruiser.position.x - this.carX) < 1.8) {
        if (this.carSpeed < 20) {
          this.triggerGameOver('BUSTED! Intercepted by Police');
          return;
        }
      }
    });

    // Roadblock spawn ahead
    this.policeRoadblockTimer += delta;
    if (this.policeRoadblockTimer > 18 - this.wantedLevel * 2) {
      this.policeRoadblockTimer = 0;
      this.spawnPoliceRoadblock();
    }
  }

  private spawnPoliceRoadblock() {
    const roadblockZ = this.carZ + 140;
    const lane = LANE_X_POSITIONS[Math.floor(Math.random() * LANE_X_POSITIONS.length)];
    const rbCruiser = buildPoliceCruiser();
    rbCruiser.position.set(lane, 0, roadblockZ);
    rbCruiser.rotation.y = Math.PI / 4; // parked diagonally
    this.scene.add(rbCruiser);

    // Treat as obstacle
    this.trafficList.push({
      ...rbCruiser,
      userData: {
        speed: 0,
        targetSpeed: 0,
        lane: 0,
        length: 4.4,
        width: 2.2,
        collisionRadius: 2.2,
        type: 'sport',
        wheels: rbCruiser.userData.wheels,
        passedPlayer: false,
      },
    } as unknown as TrafficVehicle);
  }

  // --- MULTIPLAYER WEBSOCKET SYSTEM ---
  private initMultiplayerWebSocket() {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isMultiplayerConnected = true;
        this.ws?.send(
          JSON.stringify({
            type: 'join',
            roomId: this.multiplayerRoomId,
            name: this.playerName,
            carId: this.carDef.id,
            carColor: this.carColor,
          })
        );
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'joined') {
            this.myPlayerId = msg.id;
          } else if (msg.type === 'players_update') {
            const players: RemotePlayerState[] = msg.players || [];
            this.remotePlayerList = players;
            this.syncRemotePlayerMeshes(players);
          }
        } catch {
          // ignore
        }
      };

      this.ws.onclose = () => {
        this.isMultiplayerConnected = false;
      };
    } catch {
      this.isMultiplayerConnected = false;
    }
  }

  private syncRemotePlayerMeshes(players: RemotePlayerState[]) {
    const activeIds = new Set<string>();

    players.forEach((p) => {
      if (p.id === this.myPlayerId) return; // don't render self
      activeIds.add(p.id);

      let remote = this.remotePlayers.get(p.id);
      if (!remote) {
        // Build 3D mesh for remote racer
        const mesh = buildCar3D(p.carId || 'car_venom_gt', p.carColor || '#00d4ff', true);
        this.scene.add(mesh);

        // Driver name sprite
        const sprite = this.createPlayerNameSprite(p.name);
        mesh.add(sprite);
        sprite.position.y = 2.2;

        remote = { state: p, mesh, nameSprite: sprite };
        this.remotePlayers.set(p.id, remote);
      }

      remote.state = p;
      remote.mesh.position.set(p.x, 0, p.z);
    });

    // Remove disconnected players
    this.remotePlayers.forEach((val, id) => {
      if (!activeIds.has(id)) {
        this.scene.remove(val.mesh);
        this.remotePlayers.delete(id);
      }
    });
  }

  private createPlayerNameSprite(name: string): THREE.Sprite {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = 'rgba(9, 13, 22, 0.85)';
    ctx.roundRect(10, 10, 236, 44, 10);
    ctx.fill();
    ctx.strokeStyle = '#00d4ff';
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px Orbitron, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(name.slice(0, 12), 128, 32);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    const material = new THREE.SpriteMaterial({ map: texture });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(3.2, 0.8, 1);
    return sprite;
  }

  // --- COLLECTIBLES ---
  private spawnInitialCoins() {
    const coinCount = this.gameMode === 'coinRush' ? 32 : 18;
    for (let i = 0; i < coinCount; i++) {
      this.spawnCoin(40 + i * 22);
    }
  }

  private spawnCoin(zPos: number) {
    const lane = LANE_X_POSITIONS[Math.floor(Math.random() * LANE_X_POSITIONS.length)];
    const roll = Math.random();
    let type: 'gold' | 'diamond' | 'nitro' | 'magnet' = 'gold';

    if (roll > 0.93) type = 'magnet';
    else if (roll > 0.85) type = 'nitro';
    else if (roll > 0.72) type = 'diamond';

    let mesh: THREE.Mesh;
    if (type === 'diamond') {
      const geo = new THREE.OctahedronGeometry(0.55, 0);
      const mat = new THREE.MeshStandardMaterial({
        color: 0xa855f7,
        emissive: 0x9333ea,
        emissiveIntensity: 1.2,
        metalness: 0.9,
      });
      mesh = new THREE.Mesh(geo, mat);
    } else if (type === 'nitro') {
      const geo = new THREE.CylinderGeometry(0.28, 0.28, 0.9, 12);
      const mat = new THREE.MeshStandardMaterial({
        color: 0x06b6d4,
        emissive: 0x0891b2,
        emissiveIntensity: 1.5,
        metalness: 0.8,
      });
      mesh = new THREE.Mesh(geo, mat);
    } else if (type === 'magnet') {
      const geo = new THREE.TorusGeometry(0.45, 0.18, 12, 24);
      const mat = new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        emissive: 0xd97706,
        emissiveIntensity: 1.3,
        metalness: 0.9,
      });
      mesh = new THREE.Mesh(geo, mat);
    } else {
      const geo = new THREE.CylinderGeometry(0.48, 0.48, 0.12, 18);
      geo.rotateX(Math.PI / 2);
      const mat = new THREE.MeshStandardMaterial({
        color: 0xfacc15,
        emissive: 0xeab308,
        emissiveIntensity: 0.9,
        metalness: 0.95,
      });
      mesh = new THREE.Mesh(geo, mat);
    }

    mesh.position.set(lane, 0.65, zPos);
    this.scene.add(mesh);
    this.coins.push({ mesh, type, active: true });
  }

  // --- KEYBOARD LISTENERS ---
  private setupListeners() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('resize', this.handleResize);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    if (this.isGameOver) return;
    if (e.code === 'KeyP' || e.code === 'Escape') {
      this.togglePause();
      return;
    }
    if (e.code === 'KeyA' || e.code === 'ArrowLeft') this.inputs.left = true;
    if (e.code === 'KeyD' || e.code === 'ArrowRight') this.inputs.right = true;
    if (e.code === 'KeyW' || e.code === 'ArrowUp') this.inputs.accelerate = true;
    if (e.code === 'KeyS' || e.code === 'ArrowDown') this.inputs.brake = true;
    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'Space') {
      this.inputs.nitro = true;
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    if (e.code === 'KeyA' || e.code === 'ArrowLeft') this.inputs.left = false;
    if (e.code === 'KeyD' || e.code === 'ArrowRight') this.inputs.right = false;
    if (e.code === 'KeyW' || e.code === 'ArrowUp') this.inputs.accelerate = false;
    if (e.code === 'KeyS' || e.code === 'ArrowDown') this.inputs.brake = false;
    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'Space') {
      this.inputs.nitro = false;
    }
  };

  private handleResize = () => {
    if (this.isDestroyed || !this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  public togglePause() {
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      sound.stopEngine();
      sound.stopNitro();
      sound.stopPoliceSiren();
    } else {
      sound.startEngine();
      if (this.gameMode === 'policeChase') sound.startPoliceSiren();
    }
  }

  public setSteerAxis(val: number) {
    this.inputs.steerAxis = Math.max(-1, Math.min(1, val));
  }
  public setTouchAccelerate(val: boolean) { this.inputs.accelerate = val; }
  public setTouchBrake(val: boolean) { this.inputs.brake = val; }
  public setTouchNitro(val: boolean) { this.inputs.nitro = val; }

  // --- GAME LOOP ---
  private startLoop() {
    const tick = () => {
      if (this.isDestroyed) return;
      this.frameId = requestAnimationFrame(tick);
      const delta = Math.min(this.clock.getDelta(), 0.1);
      this.update(delta);
      this.renderer.render(this.scene, this.camera);
    };
    this.frameId = requestAnimationFrame(tick);
  }

  private update(delta: number) {
    if (this.isPaused) {
      this.broadcastHUD();
      return;
    }

    if (this.isCrashing) {
      this.updateCrashSequence(delta);
      return;
    }

    if (this.isGameOver) return;

    this.timeSurvived += delta;

    if (this.gameMode === 'timeAttack') {
      this.timeRemaining -= delta;
      if (this.timeRemaining <= 0) {
        this.timeRemaining = 0;
        this.triggerGameOver('Time Expired!');
        return;
      }
    }

    // 1. Car Physics & Driving
    this.updatePlayerCar(delta);

    // 2. Road chunk recycling
    this.updateRoadChunks();

    // 3. Traffic AI
    this.updateTraffic(delta);

    // 4. Police Chase system
    if (this.gameMode === 'policeChase') {
      this.updatePoliceChase(delta);
    }

    // 5. Collectibles & Magnets
    this.updateCollectibles(delta);

    // 6. Atmospheric animations
    this.updateAtmosphere(delta);

    // 7. Camera Chase
    this.updateCamera(delta);

    // 8. Time Challenge Checkpoint
    if (this.gameMode === 'timeAttack' && this.distance >= this.nextCheckpointDist) {
      this.nextCheckpointDist += 450;
      this.timeRemaining += 14;
      sound.playUpgradeSuccess();
      if (this.onCheckpointHit) this.onCheckpointHit();
    }

    // 9. Combo decay
    if (this.comboResetTimer > 0) {
      this.comboResetTimer -= delta;
      if (this.comboResetTimer <= 0) {
        this.nearMissCombo = 0;
      }
    }

    // 10. Missions Progress Dispatch
    const distDelta = this.distance - this.lastReportedDist;
    if (distDelta >= 25 && this.onMissionProgress) {
      this.onMissionProgress('dist', distDelta);
      this.lastReportedDist = this.distance;
    }

    // 11. Multiplayer network sync
    if (this.gameMode === 'multiplayer' && this.ws && this.ws.readyState === WebSocket.OPEN) {
      const now = performance.now();
      if (now - this.lastNetworkSendTime > 50) { // 20 times per second
        this.lastNetworkSendTime = now;
        this.ws.send(
          JSON.stringify({
            type: 'update',
            x: Number(this.carX.toFixed(2)),
            z: Number(this.carZ.toFixed(1)),
            speed: Math.round(this.carSpeed * 3.6),
            distance: this.distance,
            nitro: this.isNitroActive,
          })
        );
      }
    }

    // 12. Score calculation
    this.score = Math.floor(
      this.distance * 1.2 +
      this.coinsCollected * 25 +
      this.nearMisses * 80 +
      this.policeEvadedCount * 250
    );

    // 13. Audio & HUD
    const speedRatio = this.carSpeed / this.maxSpeed;
    sound.updateEnginePitch(speedRatio, this.inputs.accelerate || this.isNitroActive);
    this.broadcastHUD();
  }

  private updatePlayerCar(delta: number) {
    // Nitro state
    if (this.inputs.nitro && this.nitro > 2 && this.carSpeed > 10) {
      this.isNitroActive = true;
      this.nitro = Math.max(0, this.nitro - (22 / this.nitroDurationFactor) * delta);
      sound.startNitro();
    } else {
      this.isNitroActive = false;
      this.nitro = Math.min(100, this.nitro + 4 * delta);
      sound.stopNitro();
    }

    this.playerCar.userData.nitroFlames.forEach((flame) => {
      flame.visible = this.isNitroActive;
      if (this.isNitroActive) {
        flame.scale.set(1 + Math.random() * 0.4, 1 + Math.random() * 0.8, 1);
      }
    });

    const currentMaxSpeed = this.isNitroActive ? this.maxSpeed * 1.35 : this.maxSpeed;

    if (this.inputs.accelerate) {
      const accelRate = this.isNitroActive ? this.acceleration * 1.8 : this.acceleration;
      this.carSpeed = Math.min(currentMaxSpeed, this.carSpeed + accelRate * delta);
    } else if (this.inputs.brake) {
      this.carSpeed = Math.max(0, this.carSpeed - 32 * delta);
    } else {
      this.carSpeed = Math.max(0, this.carSpeed - 8 * delta);
    }

    const kmh = Math.round(this.carSpeed * 3.6);
    if (kmh > this.topSpeedReached) {
      this.topSpeedReached = kmh;
      if (this.onMissionProgress) this.onMissionProgress('speed', kmh);
    }

    // Steering
    let steerDir = 0;
    if (this.inputs.left) steerDir -= 1;
    if (this.inputs.right) steerDir += 1;
    if (this.inputs.steerAxis !== 0) steerDir = this.inputs.steerAxis;

    const speedTurnFactor = Math.min(1.0, this.carSpeed / 15);
    const lateralSpeed = 14 * this.handlingFactor * speedTurnFactor;
    this.carX += steerDir * lateralSpeed * delta;

    const maxBound = ROAD_WIDTH / 2 - 1.3;
    if (this.carX < -maxBound) {
      this.carX = -maxBound;
      this.carSpeed *= 0.95;
    }
    if (this.carX > maxBound) {
      this.carX = maxBound;
      this.carSpeed *= 0.95;
    }

    this.carZ += this.carSpeed * delta;
    this.distance = Math.floor(this.carZ);

    this.carRoll = THREE.MathUtils.damp(this.carRoll, -steerDir * 0.12, 10, delta);
    this.carYaw = THREE.MathUtils.damp(this.carYaw, -steerDir * 0.08, 12, delta);

    let carPitch = 0;
    if (this.inputs.accelerate) carPitch = -0.02;
    if (this.inputs.brake) carPitch = 0.04;

    this.playerCar.position.set(this.carX, 0, this.carZ);
    this.playerCar.rotation.set(carPitch, this.carYaw, this.carRoll);

    const wheelRot = (this.carSpeed * delta) / 0.38;
    this.playerCar.userData.wheels.forEach((w) => {
      w.children[0].rotation.x += wheelRot;
    });

    if (this.playerCar.userData.wheels.length >= 2) {
      this.playerCar.userData.wheels[0].rotation.y = steerDir * 0.35;
      this.playerCar.userData.wheels[1].rotation.y = steerDir * 0.35;
    }
  }

  private updateRoadChunks() {
    this.roadChunks.forEach((chunk) => {
      if (chunk.position.z < this.carZ - this.chunkLength * 1.5) {
        chunk.position.z += this.totalChunks * this.chunkLength;
      }
    });

    if (this.oceanWaterMesh) {
      this.oceanWaterMesh.position.z = this.carZ + 80;
    }
  }

  private updateTraffic(delta: number) {
    _boxPlayer.setFromObject(this.playerCar);

    for (let i = this.trafficList.length - 1; i >= 0; i--) {
      const traffic = this.trafficList[i];
      traffic.position.z += traffic.userData.speed * delta;

      const rot = (traffic.userData.speed * delta) / 0.35;
      traffic.userData.wheels.forEach((w) => {
        w.rotation.x += rot;
      });

      _boxTarget.setFromObject(traffic);
      if (_boxPlayer.intersectsBox(_boxTarget)) {
        this.triggerCrash(traffic);
        return;
      }

      // Near-Miss check
      if (!traffic.userData.passedPlayer && this.carZ > traffic.position.z + 2.5) {
        traffic.userData.passedPlayer = true;
        const lateralDist = Math.abs(this.carX - traffic.position.x);

        if (lateralDist < 2.3 && this.carSpeed > traffic.userData.speed + 8) {
          this.nearMisses++;
          this.nearMissCombo++;
          this.comboResetTimer = 3.5;
          const multiplier = this.gameMode === 'trafficChallenge' ? Math.min(10, this.nearMissCombo) : Math.min(7, this.nearMissCombo);
          const bonusCoins = 3 + multiplier;
          this.coinsCollected += bonusCoins;
          sound.playNearMiss();
          this.onNearMissBonus(this.nearMissCombo);

          if (this.onMissionProgress) {
            this.onMissionProgress('nearmiss', 1);
          }
        }
      }

      if (traffic.position.z < this.carZ - 30) {
        const spawnDist = 130 + Math.random() * (this.gameMode === 'trafficChallenge' ? 50 : 90);
        const newLane = Math.floor(Math.random() * LANE_X_POSITIONS.length);
        traffic.position.set(LANE_X_POSITIONS[newLane], 0, this.carZ + spawnDist);
        traffic.userData.lane = newLane;
        traffic.userData.passedPlayer = false;
      }
    }
  }

  private updateCollectibles(delta: number) {
    if (this.magnetTimer > 0) this.magnetTimer -= delta;

    const playerPos = this.playerCar.position;

    this.coins.forEach((coinItem) => {
      if (!coinItem.active) return;
      const mesh = coinItem.mesh;
      mesh.rotation.y += 2.5 * delta;

      if (this.magnetTimer > 0) {
        const dist = mesh.position.distanceTo(playerPos);
        if (dist < 18) mesh.position.lerp(playerPos, 14 * delta);
      }

      const dist = mesh.position.distanceTo(playerPos);
      if (dist < 1.9) {
        coinItem.active = false;
        mesh.visible = false;

        let addedCoins = 1;
        if (coinItem.type === 'diamond') {
          addedCoins = 5;
          this.coinsCollected += 5;
          sound.playBigCoin();
        } else if (coinItem.type === 'nitro') {
          this.nitro = 100;
          sound.playUpgradeSuccess();
        } else if (coinItem.type === 'magnet') {
          this.magnetTimer = 8;
          sound.playUpgradeSuccess();
        } else {
          this.coinsCollected += 1;
          sound.playCoin();
        }

        if (this.onMissionProgress) {
          this.onMissionProgress('coins', addedCoins);
        }
      }

      if (mesh.position.z < this.carZ - 20) {
        mesh.position.z = this.carZ + 120 + Math.random() * 80;
        mesh.position.x = LANE_X_POSITIONS[Math.floor(Math.random() * LANE_X_POSITIONS.length)];
        mesh.visible = true;
        coinItem.active = true;
      }
    });
  }

  private updateAtmosphere(delta: number) {
    if (this.weatherParticles) {
      this.weatherParticles.position.z = this.carZ;
      const positions = this.weatherParticles.geometry.attributes.position.array as Float32Array;
      const fallSpeed = this.weather === 'rain' ? 42 : this.weather === 'snow' ? 14 : 8;

      for (let i = 1; i < positions.length; i += 3) {
        positions[i] -= fallSpeed * delta;
        if (positions[i] < 0) positions[i] = 45;
      }
      this.weatherParticles.geometry.attributes.position.needsUpdate = true;
    }
  }

  private updateCamera(delta: number) {
    const targetFov = this.isNitroActive ? 74 : 60;
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 6, delta);
    this.camera.updateProjectionMatrix();

    const camOffsetZ = -7.5 - (this.carSpeed / this.maxSpeed) * 1.5;
    const targetCamX = this.carX * 0.75;
    const targetCamY = 3.6;
    const targetCamZ = this.carZ + camOffsetZ;

    this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamX, 8, delta);
    this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamY, 8, delta);
    this.camera.position.z = targetCamZ;

    _vec3.set(this.carX * 0.4, 1.4, this.carZ + 10);
    this.camera.lookAt(_vec3);
  }

  // --- CRASH & GAME OVER ---
  private triggerCrash(hitVehicle: THREE.Object3D) {
    if (this.isCrashing || this.isGameOver) return;
    this.isCrashing = true;
    this.crashTimer = 0;

    sound.stopEngine();
    sound.stopNitro();
    sound.stopPoliceSiren();
    sound.playCrash();

    const impactDir = this.carX > hitVehicle.position.x ? 1 : -1;
    this.crashVelocity.set(impactDir * 12, 14, this.carSpeed * 0.4);

    const sparkCount = 120;
    const sparkGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(sparkCount * 3);
    for (let i = 0; i < sparkCount; i++) {
      positions[i * 3] = this.carX + (Math.random() - 0.5) * 2;
      positions[i * 3 + 1] = 0.8 + (Math.random() - 0.5) * 1.5;
      positions[i * 3 + 2] = this.carZ + (Math.random() - 0.5) * 2;
    }
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const sparkMat = new THREE.PointsMaterial({
      color: 0xf97316,
      size: 0.35,
      blending: THREE.AdditiveBlending,
      transparent: true,
      opacity: 0.95,
    });
    this.crashSparks = new THREE.Points(sparkGeo, sparkMat);
    this.scene.add(this.crashSparks);
  }

  private updateCrashSequence(delta: number) {
    this.crashTimer += delta;
    this.playerCar.position.addScaledVector(this.crashVelocity, delta);
    this.playerCar.rotation.x += 6 * delta;
    this.playerCar.rotation.y += 8 * delta;
    this.playerCar.rotation.z += 5 * delta;
    this.crashVelocity.y -= 28 * delta;

    this.camera.position.x += (Math.random() - 0.5) * 0.4;
    this.camera.position.y += (Math.random() - 0.5) * 0.4;

    if (this.crashTimer > 1.8) {
      this.triggerGameOver('Wrecked! Crash Collision');
    }
  }

  private triggerGameOver(reason: string) {
    this.isGameOver = true;
    sound.stopEngine();
    sound.stopNitro();
    sound.stopPoliceSiren();

    const result: RaceResult = {
      mode: this.gameMode,
      distance: this.distance,
      coinsCollected: this.coinsCollected,
      nearMisses: this.nearMisses,
      score: this.score,
      timeSurvivedSeconds: Math.floor(this.timeSurvived),
      topSpeedReached: this.topSpeedReached,
      policeEvadedCount: this.policeEvadedCount,
      isNewHighScore: false,
    };

    this.onGameOver(result);
  }

  private broadcastHUD() {
    let currentRank = 1;
    if (this.gameMode === 'multiplayer') {
      const allRanks = [...this.remotePlayerList, { distance: this.distance, id: this.myPlayerId }].sort((a, b) => b.distance - a.distance);
      currentRank = allRanks.findIndex((p) => p.id === this.myPlayerId) + 1;
      if (currentRank === 0) currentRank = 1;
    }

    this.onHUDUpdate({
      speedKmh: Math.round(this.carSpeed * 3.6),
      distanceMeters: this.distance,
      score: this.score,
      coinsEarned: this.coinsCollected,
      nitroPercent: Math.round(this.nitro),
      timeRemainingSeconds: Math.ceil(this.timeRemaining),
      nearMissCombo: this.nearMissCombo,
      magnetActive: this.magnetTimer > 0,
      isPaused: this.isPaused,
      isGameOver: this.isGameOver,
      wantedLevel: this.wantedLevel,
      policeDistance: this.policeDistance,
      policeEvadedCount: this.policeEvadedCount,
      multiplayerPlayers: this.remotePlayerList,
      currentRank,
      isMultiplayerConnected: this.isMultiplayerConnected,
    });
  }

  public destroy() {
    this.isDestroyed = true;
    cancelAnimationFrame(this.frameId);

    sound.stopEngine();
    sound.stopNitro();
    sound.stopPoliceSiren();

    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }

    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('resize', this.handleResize);

    try {
      if (this.renderer && this.renderer.domElement && this.renderer.domElement.parentNode) {
        this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
      }
      this.renderer?.dispose();
    } catch {
      // ignore
    }
  }
}
