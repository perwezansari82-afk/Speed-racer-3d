import * as THREE from 'three';

export interface TrafficVehicle extends THREE.Group {
  userData: {
    speed: number;
    targetSpeed: number;
    lane: number;
    length: number;
    width: number;
    collisionRadius: number;
    type: 'sedan' | 'suv' | 'truck' | 'sport';
    wheels: THREE.Mesh[];
    passedPlayer: boolean;
  };
}

const TRAFFIC_COLORS = [
  0xf59e0b, // Amber / Taxi
  0x3b82f6, // Blue
  0x10b981, // Emerald
  0x64748b, // Silver / Gray
  0xef4444, // Red
  0xf8fafc, // White
  0x1e293b, // Dark Navy
  0x8b5cf6, // Purple
];

export function buildTrafficVehicle(type: 'sedan' | 'suv' | 'truck' | 'sport'): TrafficVehicle {
  const root = new THREE.Group() as TrafficVehicle;
  const wheels: THREE.Mesh[] = [];

  const randomColor = TRAFFIC_COLORS[Math.floor(Math.random() * TRAFFIC_COLORS.length)];
  const bodyMat = new THREE.MeshStandardMaterial({
    color: randomColor,
    roughness: 0.35,
    metalness: 0.5,
  });

  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.7,
    metalness: 0.2,
  });

  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.1,
    metalness: 0.9,
    transparent: true,
    opacity: 0.85,
  });

  const wheelGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.26, 12);
  wheelGeo.rotateZ(Math.PI / 2);
  const wheelMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });

  const headMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const tailMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });

  let length = 4.0;
  let width = 2.0;
  let height = 1.3;

  if (type === 'truck') {
    length = 7.2;
    width = 2.3;
    height = 2.4;

    // Truck Cab
    const cabGeo = new THREE.BoxGeometry(2.3, 1.8, 2.0);
    const cab = new THREE.Mesh(cabGeo, bodyMat);
    cab.position.set(0, 1.1, 2.4);
    cab.castShadow = true;
    root.add(cab);

    // Cab windshield
    const windGeo = new THREE.BoxGeometry(2.1, 0.7, 0.2);
    const wind = new THREE.Mesh(windGeo, glassMat);
    wind.position.set(0, 1.4, 3.35);
    root.add(wind);

    // Cargo Container
    const cargoGeo = new THREE.BoxGeometry(2.4, 2.2, 5.0);
    const cargoMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.5 });
    const cargo = new THREE.Mesh(cargoGeo, cargoMat);
    cargo.position.set(0, 1.4, -1.0);
    cargo.castShadow = true;
    root.add(cargo);

    // 6 Wheels
    const zOffsets = [2.4, -0.6, -2.4];
    zOffsets.forEach((z) => {
      [-1.15, 1.15].forEach((x) => {
        const w = new THREE.Mesh(wheelGeo, wheelMat);
        w.position.set(x, 0.38, z);
        root.add(w);
        wheels.push(w);
      });
    });
  } else if (type === 'suv') {
    length = 4.4;
    width = 2.1;
    height = 1.6;

    // SUV Body
    const bodyGeo = new THREE.BoxGeometry(2.1, 0.7, 4.4);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.set(0, 0.65, 0);
    body.castShadow = true;
    root.add(body);

    // SUV Roof Cabin
    const cabinGeo = new THREE.BoxGeometry(1.8, 0.65, 2.8);
    const cabin = new THREE.Mesh(cabinGeo, glassMat);
    cabin.position.set(0, 1.25, -0.3);
    cabin.castShadow = true;
    root.add(cabin);

    // Roof rack
    const rackGeo = new THREE.BoxGeometry(1.5, 0.08, 2.2);
    const rack = new THREE.Mesh(rackGeo, trimMat);
    rack.position.set(0, 1.6, -0.3);
    root.add(rack);

    // 4 Wheels
    [1.3, -1.3].forEach((z) => {
      [-1.08, 1.08].forEach((x) => {
        const w = new THREE.Mesh(wheelGeo, wheelMat);
        w.position.set(x, 0.38, z);
        root.add(w);
        wheels.push(w);
      });
    });
  } else {
    // Sedan or Sport
    length = 4.1;
    width = 2.0;
    height = 1.25;

    // Body
    const bodyGeo = new THREE.BoxGeometry(2.0, 0.45, 4.1);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.set(0, 0.52, 0);
    body.castShadow = true;
    root.add(body);

    // Cabin
    const cabinGeo = new THREE.BoxGeometry(1.5, 0.48, 2.2);
    const cabin = new THREE.Mesh(cabinGeo, glassMat);
    cabin.position.set(0, 0.95, -0.2);
    cabin.castShadow = true;
    root.add(cabin);

    // 4 Wheels
    [1.25, -1.25].forEach((z) => {
      [-1.02, 1.02].forEach((x) => {
        const w = new THREE.Mesh(wheelGeo, wheelMat);
        w.position.set(x, 0.35, z);
        root.add(w);
        wheels.push(w);
      });
    });
  }

  // Headlights (Front facing +Z)
  [-width * 0.35, width * 0.35].forEach((x) => {
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.12, 0.05), headMat);
    head.position.set(x, 0.55, length / 2 + 0.02);
    root.add(head);
  });

  // Taillights (Rear facing -Z)
  [-width * 0.38, width * 0.38].forEach((x) => {
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.1, 0.05), tailMat);
    tail.position.set(x, 0.62, -length / 2 - 0.02);
    root.add(tail);
  });

  // Contact shadow
  const shadowGeo = new THREE.PlaneGeometry(width * 1.1, length * 1.05);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.5,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.02;
  root.add(shadow);

  root.userData = {
    speed: 35,
    targetSpeed: 35,
    lane: 0,
    length,
    width,
    collisionRadius: Math.max(width, length) * 0.45,
    type,
    wheels,
    passedPlayer: false,
  };

  return root;
}
