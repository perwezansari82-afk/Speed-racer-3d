import React from 'react';
import {
  Flame,
  Shield,
  Award,
  Cpu,
  Zap,
  Car,
  Compass,
  Play,
  Wrench,
  Coins,
  Gift,
  CloudRain,
  Timer,
  ChevronRight,
  Sparkles,
  Layers,
  Palette
} from 'lucide-react';
import { useGame } from '../context/GameContext';
import { CARS_CATALOG } from '../utils/constants';
import { AdBanner } from '../components/AdBanner';
import { sound } from '../utils/audio';

export function AboutPage() {
  const { setActivePage } = useGame();

  const handleStartRace = () => {
    setActivePage('play');
    sound.playClick();
  };

  const handleGoGarage = () => {
    setActivePage('garage');
    sound.playClick();
  };

  return (
    <div className="w-full min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto space-y-16">
      {/* Hero Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-orbitron font-semibold">
          <Flame className="w-4 h-4 text-orange-400" />
          <span>OFFICIAL ABOUT GUIDE • SPEED RACER 3D</span>
        </div>

        <h1 className="font-orbitron font-black text-3xl sm:text-5xl lg:text-6xl text-white tracking-tight">
          NEXT-GEN HIGHWAY RACING IN YOUR BROWSER
        </h1>

        <p className="font-rajdhani text-base sm:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
          SPEED RACER 3D is an exhilarating, browser-based 3D highway racing game delivering raw speed, physics-driven traffic dynamics, extensive vehicle tuning, and a rewarding arcade progression system.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button
            onClick={handleStartRace}
            className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-orbitron font-black text-sm tracking-wider flex items-center gap-2.5 shadow-lg shadow-cyan-500/30 cursor-pointer transition-all transform active:scale-95"
          >
            <Play className="w-4 h-4 fill-black" />
            <span>PLAY SPEED RACER 3D</span>
          </button>

          <button
            onClick={handleGoGarage}
            className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-orbitron font-bold text-sm tracking-wider flex items-center gap-2 cursor-pointer transition-all"
          >
            <Wrench className="w-4 h-4 text-orange-400" />
            <span>VISIT 3D GARAGE</span>
          </button>
        </div>
      </div>

      {/* 1. What is SPEED RACER 3D? */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-8 sm:p-12 space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-cyan-950/80 border border-cyan-500/30 text-cyan-400">
            <Cpu className="w-7 h-7" />
          </div>
          <div>
            <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
              WHAT IS SPEED RACER 3D?
            </h2>
            <p className="font-rajdhani text-sm text-cyan-400 font-semibold">
              The Evolution of WebGL Racing Entertainment
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-slate-300 font-rajdhani text-base leading-relaxed">
          <div className="space-y-4">
            <p>
              SPEED RACER 3D is designed to recreate the heart-pumping thrill of arcade highway racing directly inside any standard desktop or mobile web browser. Built on top of <strong>Three.js</strong> and modern hardware-accelerated WebGL 2.0, the game requires no cumbersome client downloads, third-party plugins, or account setups.
            </p>
            <p>
              Every element—from the high-speed multi-lane asphalt highway to the reflective vehicle bodywork, dynamic roadside skyline, and synthesised engine acoustics—is procedurally computed in code. The result is instant load times, zero missing asset 404 dependencies, and rock-solid 60 FPS performance across phones, tablets, and gaming computers.
            </p>
          </div>

          <div className="space-y-4 bg-slate-950/60 border border-slate-800 p-6 rounded-2xl">
            <h4 className="font-orbitron font-bold text-white text-base">Key Technical Pillars</h4>
            <ul className="space-y-2.5 text-sm">
              <li className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span><strong>Three.js PBR Engine:</strong> Studio RoomEnvironment reflections, ACES Filmic Tone Mapping, and dynamic soft contact shadows.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <span><strong>Pure Web Audio Synthesis:</strong> Dual-oscillator engine pitch responding dynamically to speed and throttle RPM, plus synthwave music.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span><strong>Zero-Friction Persistence:</strong> Browser LocalStorage automatically preserves coins, unlocked cars, upgrade levels, and records.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* 2. The 3D Racing Experience */}
      <div className="space-y-6">
        <div>
          <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
            THE RACING EXPERIENCE
          </h2>
          <p className="font-rajdhani text-sm sm:text-base text-slate-400">
            Adrenaline-fueled traffic dodging, near-miss multipliers, and reactive physics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-3">
            <div className="p-3 rounded-xl bg-orange-950/60 border border-orange-500/30 text-orange-400 w-fit">
              <Flame className="w-6 h-6" />
            </div>
            <h3 className="font-orbitron font-bold text-lg text-white">High-Speed Traffic Dodging</h3>
            <p className="font-rajdhani text-sm text-slate-400 leading-relaxed">
              Navigate busy 4-lane highways packed with AI sedans, heavy freight container trucks, and sports cruisers. As your distance grows, traffic density ramps up, requiring millisecond-level steering reflexes.
            </p>
          </div>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-3">
            <div className="p-3 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 w-fit">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="font-orbitron font-bold text-lg text-white">Near-Miss Combo Multipliers</h3>
            <p className="font-rajdhani text-sm text-slate-400 leading-relaxed">
              Reward high-risk driving! Grazing past civilian vehicles with inches of clearance triggers the "Near Miss" sound effect and awards bonus gold coins, stacking consecutively into lucrative combo multipliers.
            </p>
          </div>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-3">
            <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-400 w-fit">
              <CloudRain className="w-6 h-6" />
            </div>
            <h3 className="font-orbitron font-bold text-lg text-white">4 Dynamic Weather Modes</h3>
            <p className="font-rajdhani text-sm text-slate-400 leading-relaxed">
              Race in brilliant Sunny Noon daylight, vibrant Neon Sunset, mysterious Midnight City with glowing neon headlamps, or tempestuous Rainy Highway with falling particle droplets and heightened asphalt reflections.
            </p>
          </div>
        </div>
      </div>

      {/* 3. The Car Collection */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-8 sm:p-12 space-y-8">
        <div>
          <div className="flex items-center gap-2">
            <Car className="w-6 h-6 text-cyan-400" />
            <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
              THE CAR FLEET
            </h2>
          </div>
          <p className="font-rajdhani text-slate-400 text-sm sm:text-base mt-1">
            Every driver starts with one free starter roadster. Additional supercars are unlocked using coins earned in-game.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CARS_CATALOG.map((car) => (
            <div
              key={car.id}
              className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-orbitron font-bold px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                    {car.badge}
                  </span>
                  <span className="text-xs font-orbitron font-bold text-amber-400">
                    {car.price === 0 ? 'FREE STARTER' : `${car.price} COINS`}
                  </span>
                </div>

                <h3 className="font-orbitron font-bold text-lg text-white mb-1">
                  {car.name}
                </h3>
                <p className="text-xs font-rajdhani text-slate-400 mb-4 leading-relaxed">
                  {car.description}
                </p>
              </div>

              <div className="space-y-1.5 pt-3 border-t border-slate-800 text-[11px] font-rajdhani font-semibold">
                <div className="flex justify-between text-slate-300">
                  <span>Top Speed:</span>
                  <span className="text-cyan-400 font-bold">{car.topSpeedKmh} KM/H</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Acceleration:</span>
                  <span>{car.baseAcceleration * 10}%</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Handling / Grip:</span>
                  <span>{car.baseHandling * 10}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. The 3D Garage & Tuning */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-7 space-y-5 text-slate-300 font-rajdhani text-base leading-relaxed">
          <div className="flex items-center gap-2">
            <Wrench className="w-6 h-6 text-orange-400" />
            <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
              THE 3D GARAGE & WORKSHOP
            </h2>
          </div>

          <p>
            The SPEED RACER 3D Garage serves as your personal showroom and tuning headquarters. Inside the garage, you can:
          </p>

          <ul className="space-y-3 pl-2">
            <li className="flex items-start gap-2.5">
              <ChevronRight className="w-4 h-4 text-cyan-400 shrink-0 mt-1" />
              <span><strong>Interactive 360° Turntable:</strong> Click or swipe to rotate any vehicle around its yaw axis, inspecting alloy rims, aerodynamics, and LED light bars under realistic showroom spotlights.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <ChevronRight className="w-4 h-4 text-cyan-400 shrink-0 mt-1" />
              <span><strong>4-Pillar Performance Upgrades:</strong> Spend your hard-earned race coins to upgrade <strong>Engine Block</strong> (faster acceleration), <strong>Turbo</strong> (elevated top speed), <strong>Suspension & Tires</strong> (sharper handling), and <strong>Nitrous Delivery</strong> (longer boost duration).</span>
            </li>
            <li className="flex items-start gap-2.5">
              <ChevronRight className="w-4 h-4 text-cyan-400 shrink-0 mt-1" />
              <span><strong>Custom Paint Booth:</strong> Choose from 12 signature metallic coats—including Neon Cyan, Speed Orange, Crimson Red, and Obsidian Matte—or pick any custom hex shade using the color selector.</span>
            </li>
          </ul>

          <div className="pt-2">
            <button
              onClick={handleGoGarage}
              className="px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-orbitron font-bold text-xs tracking-wider flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/30"
            >
              <span>ENTER GARAGE SHOWROOM</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-3xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <Palette className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
            <h4 className="font-orbitron font-bold text-white text-base">Customization Freedom</h4>
            <p className="text-xs text-slate-400 font-rajdhani mt-1">
              Every upgrade directly impacts vehicle handling and top speed on the highway.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <Coins className="w-8 h-8 text-amber-400 mx-auto mb-2" />
            <h4 className="font-orbitron font-bold text-white text-base">Zero Pay-to-Win</h4>
            <p className="text-xs text-slate-400 font-rajdhani mt-1">
              All vehicles and performance tiers are unlocked purely through in-game racing coins.
            </p>
          </div>
        </div>
      </div>

      {/* 5. Coin Rewards & Daily Login Bonus */}
      <div className="rounded-3xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-orange-950/30 border border-amber-500/30 p-8 sm:p-12 space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
            <Gift className="w-7 h-7" />
          </div>
          <div>
            <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
              COIN REWARDS & DAILY BONUS
            </h2>
            <p className="font-rajdhani text-sm text-amber-300 font-semibold">
              Fair Progression with Guaranteed Daily Coin Gifts
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-slate-300 font-rajdhani text-base leading-relaxed">
          <div className="space-y-4">
            <p>
              SPEED RACER 3D is founded on a 100% fair virtual economy. You earn coins in several engaging ways:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-400 pl-2">
              <li><strong>Distance Covered:</strong> Accumulate coins for every kilometer traveled along the highway.</li>
              <li><strong>Road Pickups:</strong> Collect gold coins (+1) and rare diamond octahedrons (+5) scattered across the lanes.</li>
              <li><strong>Near-Miss Overtakes:</strong> Thread the needle between speeding traffic cars to trigger coin combo bonuses.</li>
            </ul>
          </div>

          <div className="p-6 rounded-2xl bg-slate-950/70 border border-amber-500/30 space-y-3">
            <div className="flex items-center gap-2 text-amber-400 font-orbitron font-bold text-sm">
              <Gift className="w-5 h-5" />
              <span>Guaranteed Daily 20 Coins</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Every single day, players can open the Daily Bonus modal and claim exactly <strong>20 free gold coins</strong>. The system records your claim timestamp and calculates the exact countdown to midnight for your next calendar reward.
            </p>
          </div>
        </div>
      </div>

      {/* AdSense Placement */}
      <AdBanner format="leaderboard" />
    </div>
  );
}
