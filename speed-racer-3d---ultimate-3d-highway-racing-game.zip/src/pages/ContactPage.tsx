import React, { useState } from 'react';
import {
  Mail,
  Send,
  CheckCircle,
  Clock,
  MessageSquare,
  AlertCircle,
  ExternalLink,
  Copy,
  Loader2,
  HelpCircle,
  ShieldCheck,
  Headphones
} from 'lucide-react';
import { AdBanner } from '../components/AdBanner';
import { sound } from '../utils/audio';

interface ContactTicket {
  id: string;
  name: string;
  email: string;
  category: string;
  message: string;
  submittedAt: string;
}

const STORAGE_TICKETS_KEY = 'speed_racer_contact_tickets_v1';
const DEVELOPER_EMAIL = 'perwezansari59@gmail.com';

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('Feedback & Feature Request');
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTicket, setActiveTicket] = useState<ContactTicket | null>(null);
  const [serverNotice, setServerNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Load previous local tickets
  const [previousTickets, setPreviousTickets] = useState<ContactTicket[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_TICKETS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setServerNotice(null);

    // Client-side quick checks
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedMsg = message.trim();

    if (!trimmedName) {
      setError('Please provide your name or driver callsign.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!trimmedEmail || !emailRegex.test(trimmedEmail)) {
      setError('Please provide a valid email address (e.g., driver@speedracer3d.com).');
      return;
    }

    if (trimmedMsg.length < 15) {
      setError('Message must be at least 15 characters long.');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: trimmedName,
          email: trimmedEmail,
          category,
          message: trimmedMsg,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        setError(data.error || 'Server error processing your inquiry. Please try again.');
        setIsSubmitting(false);
        return;
      }

      // Successful server response with actual server-generated ticket ID
      const ticket: ContactTicket = {
        id: data.ticketId,
        name: trimmedName,
        email: trimmedEmail,
        category,
        message: trimmedMsg,
        submittedAt: new Date(data.submittedAt || Date.now()).toLocaleString(),
      };

      const updated = [ticket, ...previousTickets].slice(0, 10);
      setPreviousTickets(updated);
      try {
        localStorage.setItem(STORAGE_TICKETS_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }

      setServerNotice(data.message);
      setActiveTicket(ticket);
      sound.playUpgradeSuccess();
    } catch (err: unknown) {
      console.error('Contact form submission error:', err);
      // Real error message - never pretend success if backend is unreachable
      setError('Could not connect to the backend contact server. Please ensure your connection is active, or use the direct email link below.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyTicket = () => {
    if (!activeTicket) return;
    const body = `Support Ticket #${activeTicket.id}\nDriver: ${activeTicket.name} (${activeTicket.email})\nCategory: ${activeTicket.category}\nDate: ${activeTicket.submittedAt}\n\nMessage:\n${activeTicket.message}`;
    navigator.clipboard.writeText(body);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const mailtoUrl = activeTicket
    ? `mailto:${DEVELOPER_EMAIL}?subject=${encodeURIComponent(
        `[${activeTicket.id}] SPEED RACER 3D: ${activeTicket.category}`
      )}&body=${encodeURIComponent(
        `Driver: ${activeTicket.name}\nEmail: ${activeTicket.email}\nTicket ID: ${activeTicket.id}\nDate: ${activeTicket.submittedAt}\n\nMessage:\n${activeTicket.message}`
      )}`
    : `mailto:${DEVELOPER_EMAIL}?subject=${encodeURIComponent(
        `SPEED RACER 3D Support Dispatch`
      )}`;

  return (
    <div className="w-full min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-10">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-orbitron font-semibold">
          <Headphones className="w-4 h-4 text-cyan-400" />
          <span>DEVELOPER & RACING SUPPORT DISPATCH</span>
        </div>

        <h1 className="font-orbitron font-black text-3xl sm:text-5xl text-white">
          CONTACT SPEED RACER 3D
        </h1>

        <p className="font-rajdhani text-sm sm:text-base text-slate-400 max-w-2xl mx-auto">
          Need support with in-game vehicle tuning, discovered a physics bug, or have ideas for new tracks? Submit an official ticket to our engineering team below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Contact Form or Confirmation Ticket */}
        <div className="lg:col-span-7">
          {activeTicket ? (
            <div className="rounded-3xl bg-slate-900 border border-emerald-500/50 p-6 sm:p-8 space-y-5 shadow-2xl">
              <div className="flex items-center gap-3 text-emerald-400">
                <CheckCircle className="w-8 h-8 shrink-0" />
                <div>
                  <h3 className="font-orbitron font-black text-xl text-white">
                    TICKET REGISTERED ON SERVER
                  </h3>
                  <p className="font-rajdhani text-xs text-slate-300">
                    Your dispatch has been successfully recorded in the backend queue.
                  </p>
                </div>
              </div>

              {serverNotice && (
                <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs font-rajdhani">
                  {serverNotice}
                </div>
              )}

              {/* Ticket Details Box */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs font-rajdhani">
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Official Ticket Reference:</span>
                  <span className="font-orbitron font-bold text-cyan-400">{activeTicket.id}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Driver CallSign:</span>
                  <span className="text-white font-semibold">{activeTicket.name}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Contact Email:</span>
                  <span className="text-white font-semibold">{activeTicket.email}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Category:</span>
                  <span className="text-amber-300 font-semibold">{activeTicket.category}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Dispatch Target:</span>
                  <span className="text-cyan-400 font-semibold">{DEVELOPER_EMAIL}</span>
                </div>
                <div className="pt-1">
                  <span className="text-slate-400 block mb-1">Message Content:</span>
                  <p className="p-2.5 rounded bg-slate-900 text-slate-200 whitespace-pre-wrap font-sans text-xs">
                    {activeTicket.message}
                  </p>
                </div>
              </div>

              {/* Dispatch Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={mailtoUrl}
                  className="flex-1 py-3 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-orbitron font-black text-xs tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>OPEN IN EMAIL CLIENT</span>
                </a>

                <button
                  onClick={handleCopyTicket}
                  className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-orbitron font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Copy className="w-4 h-4 text-orange-400" />
                  <span>{copied ? 'COPIED TO CLIPBOARD!' : 'COPY DETAILS'}</span>
                </button>
              </div>

              <button
                onClick={() => {
                  setActiveTicket(null);
                  setName('');
                  setEmail('');
                  setMessage('');
                }}
                className="w-full text-center text-xs text-slate-400 hover:text-cyan-400 font-rajdhani underline cursor-pointer pt-2"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-5 shadow-2xl">
              <div className="flex items-center justify-between">
                <h3 className="font-orbitron font-black text-xl text-white">
                  SUBMIT AN INQUIRY
                </h3>
                <span className="text-[11px] font-rajdhani font-semibold text-cyan-400">
                  Backend Verified
                </span>
              </div>

              {error && (
                <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs font-rajdhani font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{error}</span>
                </div>
              )}

              {/* Name */}
              <div>
                <label className="block text-xs font-orbitron font-bold text-slate-300 mb-1.5 uppercase">
                  Your Name / Driver Callsign *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex Apex"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white font-rajdhani text-sm focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-orbitron font-bold text-slate-300 mb-1.5 uppercase">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. driver@domain.com"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white font-rajdhani text-sm focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-orbitron font-bold text-slate-300 mb-1.5 uppercase">
                  Inquiry Topic
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white font-rajdhani text-sm focus:outline-none focus:border-cyan-400 transition-colors cursor-pointer"
                >
                  <option value="Feedback & Feature Request">Feedback & Feature Request</option>
                  <option value="Physics & Collision Bug Report">Physics & Collision Bug Report</option>
                  <option value="Coin Economy & Garage Support">Coin Economy & Garage Support</option>
                  <option value="Google AdSense & Partnership">Google AdSense & Partnership</option>
                  <option value="General Question">General Question</option>
                </select>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-orbitron font-bold text-slate-300 mb-1.5 uppercase">
                  Message * (Min 15 characters)
                </label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your inquiry, bug report, or feedback in detail..."
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white font-rajdhani text-sm focus:outline-none focus:border-cyan-400 transition-colors resize-none"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 disabled:opacity-60 text-black font-orbitron font-black text-sm tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 transition-all cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>TRANSMITTING TO SERVER...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 fill-black" />
                    <span>SUBMIT MESSAGE TO SUPPORT</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        {/* Sidebar Info & Direct Dispatch details */}
        <div className="lg:col-span-5 space-y-5">
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
            <h4 className="font-orbitron font-bold text-base text-white">
              Direct Engineering Dispatch
            </h4>
            <p className="font-rajdhani text-sm text-slate-300 leading-relaxed">
              Every message is routed to our engineering review queue. If your ticket requires technical intervention or account assistance, our lead maintainer will reply directly.
            </p>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-rajdhani space-y-1">
              <span className="text-slate-400 block font-semibold">Lead Developer Email:</span>
              <a
                href={`mailto:${DEVELOPER_EMAIL}`}
                className="font-orbitron font-bold text-cyan-400 hover:underline block text-sm"
              >
                {DEVELOPER_EMAIL}
              </a>
            </div>

            <div className="flex items-center gap-2 text-xs font-rajdhani text-slate-400">
              <Clock className="w-4 h-4 text-orange-400" />
              <span>Turnaround: Reviewed within 24 to 48 business hours</span>
            </div>

            <div className="flex items-center gap-2 text-xs font-rajdhani text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Privacy Guarantee: Your email is never shared with third parties</span>
            </div>
          </div>

          {/* Previous Tickets Log in LocalStorage */}
          {previousTickets.length > 0 && (
            <div className="rounded-3xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h5 className="font-orbitron text-xs font-bold text-slate-300 uppercase">
                Your Recent Dispatches ({previousTickets.length})
              </h5>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {previousTickets.map((t) => (
                  <div key={t.id} className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 text-xs font-rajdhani">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="font-orbitron font-bold text-cyan-400">{t.id}</span>
                      <span className="text-[10px] text-slate-500">{t.submittedAt}</span>
                    </div>
                    <span className="text-slate-300 truncate block">{t.category}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* AdSense Placement */}
      <AdBanner format="leaderboard" />
    </div>
  );
}
