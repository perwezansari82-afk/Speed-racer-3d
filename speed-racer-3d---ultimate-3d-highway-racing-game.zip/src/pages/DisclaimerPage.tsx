import React from 'react';
import { AlertTriangle, ShieldCheck } from 'lucide-react';
import { AdBanner } from '../components/AdBanner';

export function DisclaimerPage() {
  return (
    <div className="w-full min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8 text-slate-300 font-rajdhani">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-950/80 border border-orange-500/40 text-orange-400 text-xs font-orbitron font-semibold">
          <AlertTriangle className="w-4 h-4 text-orange-400" />
          <span>IMPORTANT NOTICE</span>
        </div>
        <h1 className="font-orbitron font-black text-3xl sm:text-4xl text-white">
          SAFETY & LEGAL DISCLAIMER
        </h1>
        <p className="text-sm text-slate-400">
          SPEED RACER 3D Simulation Guidelines
        </p>
      </div>

      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-10 space-y-8 leading-relaxed text-sm sm:text-base">
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            <span>1. Real-World Driving Safety Warning</span>
          </h2>
          <p className="text-slate-200 font-semibold">
            SPEED RACER 3D is an exaggerated entertainment arcade video game simulation created exclusively for amusement.
          </p>
          <p>
            The driving mechanics, traffic overtaking maneuvers, near-miss bonuses, high speeds, and vehicle dynamics depicted in this game are entirely fictional and extremely dangerous if attempted on real public roads or highways.
          </p>
          <p>
            Always obey local traffic laws, posted speed limits, and traffic signals in real life. Never operate a real motor vehicle while distracted, intoxicated, or fatigued. Always wear your seatbelt.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            2. Virtual Economy & Rewards
          </h2>
          <p>
            All "coins", "daily login rewards", and "boosts" provided in SPEED RACER 3D are in-game entertainment credits. They carry zero real-world cash equivalence, cannot be cashed out, refunded, or exchanged for real-world currencies or prizes.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            3. "As-Is" Simulation Availability
          </h2>
          <p>
            SPEED RACER 3D is provided on an "as-is" and "as-available" basis without warranties of any kind regarding server uptime or client device compatibility. While we continuously optimize for 60 FPS across both modern desktop GPUs and Android mobile browsers, individual browser hardware configurations may vary.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            4. Third-Party Trademarks & Fictional Models
          </h2>
          <p>
            All vehicle models (e.g., Venom GT, Apex Phantom, Crimson Fury, Cyber Neon, Valkyrie Hyper, Shadow Stealth) are original procedural 3D designs created specifically for SPEED RACER 3D. Any resemblance to actual production models or trademarks is purely artistic homage and does not imply sponsorship or endorsement by any automotive manufacturer.
          </p>
        </section>
      </div>

      <AdBanner format="leaderboard" />
    </div>
  );
}
