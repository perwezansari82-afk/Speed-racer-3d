import React, { useRef, useState, useEffect } from 'react';
import {
  RotateCcw,
  Palette,
  Wrench,
  Gauge,
  Flame,
  Zap,
  Check,
  Lock,
  Coins,
  Play,
  Sparkles,
  Shield,
  Disc,
  Lightbulb
} from 'lucide-react';
import { useGame } from '../context/GameContext';
import {
  CARS_CATALOG,
  PAINT_COLORS,
  UPGRADE_TIER_COSTS,
  MAX_UPGRADE_LEVEL,
  SPOILER_OPTIONS,
  WHEEL_OPTIONS,
  WHEEL_COLOR_OPTIONS,
  NEON_UNDERGLOW_OPTIONS
} from '../utils/constants';
import { GarageScene } from '../game/GarageScene';
import { CarUpgrades, SpoilerStyle, WheelStyle, CarCustomization } from '../types/game';
import { sound } from '../utils/audio';

type GarageTab = 'tuning' | 'paint' | 'spoilers' | 'wheels' | 'neon';

export function GaragePage() {
  const {
    profile,
    setActivePage,
    selectCar,
    buyCar,
    changeCarColor,
    updateCarCustomization,
    upgradeCar,
  } = useGame();

  const containerRef = useRef<HTMLDivElement>(null);
  const garageSceneRef = useRef<GarageScene | null>(null);

  // Inspected car in garage
  const [selectedCarIndex, setSelectedCarIndex] = useState(() => {
    const idx = CARS_CATALOG.findIndex((c) => c.id === profile.selectedCarId);
    return idx >= 0 ? idx : 0;
  });

  const [activeTab, setActiveTab] = useState<GarageTab>('tuning');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const inspectedCar = CARS_CATALOG[selectedCarIndex];
  const isUnlocked = profile.unlockedCars.includes(inspectedCar.id);
  const isEquipped = profile.selectedCarId === inspectedCar.id;
  const currentColor = profile.carColors[inspectedCar.id] || inspectedCar.defaultColor;
  const currentUpgrades: CarUpgrades = profile.carUpgrades[inspectedCar.id] || { engine: 0, speed: 0, handling: 0, nitro: 0 };
  const currentCustomization: CarCustomization = profile.carCustomizations[inspectedCar.id] || {
    color: currentColor,
    spoiler: 'none',
    wheelStyle: 'sport5',
    wheelColor: '#d1d5db',
    neonUnderglow: 'none',
  };

  // Mount 3D garage scene
  useEffect(() => {
    if (!containerRef.current) return;

    if (!garageSceneRef.current) {
      garageSceneRef.current = new GarageScene(
        containerRef.current,
        inspectedCar.id,
        currentColor,
        currentCustomization
      );
    } else {
      garageSceneRef.current.loadCar(inspectedCar.id, currentColor, currentCustomization);
    }
  }, [inspectedCar.id]);

  // Clean up on component unmount
  useEffect(() => {
    return () => {
      if (garageSceneRef.current) {
        garageSceneRef.current.destroy();
        garageSceneRef.current = null;
      }
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSelectCar = (index: number) => {
    setSelectedCarIndex(index);
    const car = CARS_CATALOG[index];
    const color = profile.carColors[car.id] || car.defaultColor;
    const cust = profile.carCustomizations[car.id] || {
      color,
      spoiler: 'none',
      wheelStyle: 'sport5',
      wheelColor: '#d1d5db',
      neonUnderglow: 'none',
    };
    if (garageSceneRef.current) {
      garageSceneRef.current.loadCar(car.id, color, cust);
    }
    sound.playClick();
  };

  const handleEquip = () => {
    selectCar(inspectedCar.id);
    showToast(`${inspectedCar.name} equipped as primary race car!`);
  };

  const handleBuy = () => {
    const res = buyCar(inspectedCar.id);
    showToast(res.message);
  };

  const handleColorChange = (hex: string) => {
    changeCarColor(inspectedCar.id, hex);
    if (garageSceneRef.current) {
      garageSceneRef.current.updateColor(hex);
    }
  };

  const handleSpoilerChange = (spoiler: SpoilerStyle) => {
    updateCarCustomization(inspectedCar.id, { spoiler });
    const updated = { ...currentCustomization, spoiler };
    if (garageSceneRef.current) {
      garageSceneRef.current.loadCar(inspectedCar.id, currentColor, updated);
    }
    showToast(`Spoiler equipped: ${spoiler.toUpperCase()}`);
  };

  const handleWheelStyleChange = (wheelStyle: WheelStyle) => {
    updateCarCustomization(inspectedCar.id, { wheelStyle });
    const updated = { ...currentCustomization, wheelStyle };
    if (garageSceneRef.current) {
      garageSceneRef.current.loadCar(inspectedCar.id, currentColor, updated);
    }
    showToast(`Wheel style updated: ${wheelStyle}`);
  };

  const handleWheelColorChange = (wheelColor: string) => {
    updateCarCustomization(inspectedCar.id, { wheelColor });
    const updated = { ...currentCustomization, wheelColor };
    if (garageSceneRef.current) {
      garageSceneRef.current.loadCar(inspectedCar.id, currentColor, updated);
    }
  };

  const handleNeonChange = (neonColor: string) => {
    updateCarCustomization(inspectedCar.id, { neonUnderglow: neonColor });
    if (garageSceneRef.current) {
      garageSceneRef.current.updateNeonUnderglow(neonColor);
    }
    showToast(neonColor === 'none' ? 'Neon Underglow disabled' : 'Neon Underglow activated!');
  };

  const handleUpgrade = (attribute: keyof CarUpgrades) => {
    const res = upgradeCar(inspectedCar.id, attribute);
    showToast(res.message);
  };

  const upgradeAttributes: { id: keyof CarUpgrades; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      id: 'engine',
      label: 'Engine Block & ECU',
      icon: <Zap className="w-4 h-4 text-orange-400" />,
      desc: 'Increases 0-100 acceleration rate and launch torque.',
    },
    {
      id: 'speed',
      label: 'Turbo & Aerodynamics',
      icon: <Gauge className="w-4 h-4 text-cyan-400" />,
      desc: 'Extends top terminal velocity across highway straightaways.',
    },
    {
      id: 'handling',
      label: 'Suspension & Brakes',
      icon: <Sparkles className="w-4 h-4 text-emerald-400" />,
      desc: 'Sharper steering response and lateral drift stability.',
    },
    {
      id: 'nitro',
      label: 'Nitrous Delivery System',
      icon: <Flame className="w-4 h-4 text-amber-400" />,
      desc: 'Extends nitrous burn duration and speeds up recovery.',
    },
  ];

  return (
    <div className="w-full min-h-screen py-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-6">
      {/* Toast alert */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-5 py-3 rounded-xl bg-slate-900 border border-cyan-400 text-cyan-300 font-rajdhani font-bold text-sm shadow-xl shadow-cyan-950/60 animate-in fade-in slide-in-from-top-4">
          {toastMessage}
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
              CUSTOM RACE GARAGE
            </h1>
            <span className="text-xs font-rajdhani font-bold px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              3D SHOWROOM & TUNING SHOP
            </span>
          </div>
          <p className="font-rajdhani text-sm text-slate-400">
            Rotate the 360° platform, modify aerodynamics, swap custom alloy wheels, equip neon underglow, and tune performance.
          </p>
        </div>

        {/* Test Drive Button */}
        <button
          onClick={() => {
            if (isUnlocked && !isEquipped) selectCar(inspectedCar.id);
            setActivePage('play');
            sound.playClick();
          }}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-orbitron font-black text-sm tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-black" />
          <span>DRIVE THIS CAR NOW</span>
        </button>
      </div>

      {/* Main Garage Interactive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left & Center: 3D Turntable Viewport */}
        <div className="lg:col-span-7 xl:col-span-8 flex flex-col space-y-4">
          <div className="relative w-full h-[360px] sm:h-[480px] rounded-3xl bg-[#070b13] border border-cyan-500/30 overflow-hidden shadow-2xl">
            {/* 3D Canvas Container */}
            <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

            {/* Turntable Drag Hint Overlay */}
            <div className="absolute top-4 left-4 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-700/60 backdrop-blur-sm pointer-events-none text-[11px] font-rajdhani text-slate-300 flex items-center gap-2">
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Drag to rotate 360° • Auto-spins on idle</span>
            </div>

            {/* Car Name & Category Badge inside canvas */}
            <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-none">
              <div className="p-3.5 rounded-2xl bg-slate-950/85 border border-slate-800 backdrop-blur-md">
                <span className="text-[10px] font-orbitron font-bold text-cyan-400 tracking-wider block">
                  {inspectedCar.category.toUpperCase()} • TOP SPEED: {inspectedCar.topSpeedKmh} KM/H
                </span>
                <h3 className="font-orbitron font-black text-xl sm:text-2xl text-white">
                  {inspectedCar.name}
                </h3>
              </div>

              {/* Status Action Button */}
              <div className="pointer-events-auto">
                {isEquipped ? (
                  <div className="px-4 py-2 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-orbitron font-bold text-xs flex items-center gap-1.5">
                    <Check className="w-4 h-4" />
                    <span>EQUIPPED</span>
                  </div>
                ) : isUnlocked ? (
                  <button
                    onClick={handleEquip}
                    className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-orbitron font-bold text-xs tracking-wider cursor-pointer shadow-lg shadow-cyan-500/30"
                  >
                    EQUIP CAR
                  </button>
                ) : (
                  <button
                    onClick={handleBuy}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-orbitron font-black text-xs tracking-wider flex items-center gap-2 cursor-pointer shadow-lg shadow-orange-500/30"
                  >
                    <Coins className="w-4 h-4 fill-black" />
                    <span>UNLOCK FOR {inspectedCar.price} COINS</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Car Carousel Selector Thumbnails */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {CARS_CATALOG.map((car, index) => {
              const isCarUnlocked = profile.unlockedCars.includes(car.id);
              const isSelected = selectedCarIndex === index;
              const carColor = profile.carColors[car.id] || car.defaultColor;

              return (
                <button
                  key={car.id}
                  onClick={() => handleSelectCar(index)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-400 shadow-md shadow-cyan-500/20'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Color dot & Lock */}
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className="w-4 h-4 rounded-full border border-white/60 shadow"
                      style={{ backgroundColor: carColor }}
                    />
                    {!isCarUnlocked && (
                      <span className="flex items-center gap-1 text-[10px] font-orbitron font-bold text-amber-400">
                        <Lock className="w-3 h-3" />
                        <span>{car.price}</span>
                      </span>
                    )}
                  </div>

                  <p className="font-orbitron font-bold text-xs text-white truncate">
                    {car.name}
                  </p>
                  <p className="text-[10px] font-rajdhani text-slate-400">
                    {car.badge}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Sidebar: Customization & Tuning Shop */}
        <div className="lg:col-span-5 xl:col-span-4 space-y-4">
          {/* Tab Switcher */}
          <div className="flex flex-wrap p-1 rounded-2xl bg-slate-900 border border-slate-800 gap-1">
            <button
              onClick={() => {
                setActiveTab('tuning');
                sound.playClick();
              }}
              className={`flex-1 py-2 px-2 rounded-xl font-orbitron text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'tuning'
                  ? 'bg-cyan-600 text-black shadow-md shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Wrench className="w-3 h-3" />
              <span>TUNING</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('paint');
                sound.playClick();
              }}
              className={`flex-1 py-2 px-2 rounded-xl font-orbitron text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'paint'
                  ? 'bg-cyan-600 text-black shadow-md shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Palette className="w-3 h-3" />
              <span>PAINT</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('spoilers');
                sound.playClick();
              }}
              className={`flex-1 py-2 px-2 rounded-xl font-orbitron text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'spoilers'
                  ? 'bg-cyan-600 text-black shadow-md shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Shield className="w-3 h-3" />
              <span>SPOILER</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('wheels');
                sound.playClick();
              }}
              className={`flex-1 py-2 px-2 rounded-xl font-orbitron text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'wheels'
                  ? 'bg-cyan-600 text-black shadow-md shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Disc className="w-3 h-3" />
              <span>WHEELS</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('neon');
                sound.playClick();
              }}
              className={`flex-1 py-2 px-2 rounded-xl font-orbitron text-[11px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'neon'
                  ? 'bg-cyan-600 text-black shadow-md shadow-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Lightbulb className="w-3 h-3" />
              <span>NEON</span>
            </button>
          </div>

          {/* Performance Tuning Tab */}
          {activeTab === 'tuning' && (
            <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-5 space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="font-orbitron font-bold text-sm text-white uppercase tracking-wider">
                  Engine & Handling Tuning
                </h3>
                <span className="text-xs font-rajdhani font-semibold text-amber-400">
                  Wallet: {profile.coins} Coins
                </span>
              </div>

              {!isUnlocked && (
                <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-300 text-xs font-rajdhani">
                  Unlock this vehicle first to install performance upgrade tiers.
                </div>
              )}

              <div className="space-y-4">
                {upgradeAttributes.map((attr) => {
                  const currentLevel = currentUpgrades[attr.id];
                  const isMax = currentLevel >= MAX_UPGRADE_LEVEL;
                  const cost = isMax ? 0 : UPGRADE_TIER_COSTS[currentLevel];
                  const canAfford = profile.coins >= cost && isUnlocked && !isMax;

                  return (
                    <div key={attr.id} className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {attr.icon}
                          <span className="font-orbitron font-bold text-xs text-white">
                            {attr.label}
                          </span>
                        </div>
                        <span className="text-xs font-orbitron font-bold text-cyan-400">
                          LVL {currentLevel} / {MAX_UPGRADE_LEVEL}
                        </span>
                      </div>

                      <p className="text-[11px] font-rajdhani text-slate-400">
                        {attr.desc}
                      </p>

                      {/* 5-step progress pips */}
                      <div className="grid grid-cols-5 gap-1.5 py-1">
                        {Array.from({ length: MAX_UPGRADE_LEVEL }).map((_, i) => (
                          <div
                            key={i}
                            className={`h-2 rounded-full transition-all ${
                              i < currentLevel
                                ? 'bg-cyan-400 shadow-sm shadow-cyan-400'
                                : 'bg-slate-800'
                            }`}
                          />
                        ))}
                      </div>

                      {/* Upgrade action */}
                      <div className="pt-1 flex items-center justify-between">
                        <span className="text-xs font-rajdhani font-semibold text-slate-400">
                          {isMax ? 'Maximum Tuning' : `Next Tier: ${cost} Coins`}
                        </span>

                        <button
                          disabled={!canAfford}
                          onClick={() => handleUpgrade(attr.id)}
                          className={`px-3 py-1.5 rounded-lg font-orbitron font-bold text-[11px] transition-all cursor-pointer ${
                            isMax
                              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                              : canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-sm'
                              : 'bg-slate-800/80 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          {isMax ? 'MAXED' : `UPGRADE (+${cost})`}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Paint Booth Tab */}
          {activeTab === 'paint' && (
            <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-5 space-y-5">
              <div>
                <h3 className="font-orbitron font-bold text-sm text-white uppercase tracking-wider">
                  Metallic & Neon Enamels
                </h3>
                <p className="font-rajdhani text-xs text-slate-400 mt-0.5">
                  Click any color finish to instantly spray the vehicle body.
                </p>
              </div>

              {/* 12 Presets Swatches */}
              <div className="grid grid-cols-4 gap-3">
                {PAINT_COLORS.map((col) => {
                  const isActive = currentColor.toLowerCase() === col.hex.toLowerCase();
                  return (
                    <button
                      key={col.hex}
                      onClick={() => handleColorChange(col.hex)}
                      className={`group p-2 rounded-xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                        isActive
                          ? 'border-cyan-400 bg-slate-800 shadow-md shadow-cyan-500/20'
                          : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'
                      }`}
                    >
                      <div
                        className="w-8 h-8 rounded-full border border-white/40 shadow-inner group-hover:scale-110 transition-transform"
                        style={{ backgroundColor: col.hex }}
                      />
                      <span className="text-[10px] font-rajdhani font-semibold text-slate-300 text-center truncate w-full">
                        {col.name}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Custom Hex Picker */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <span className="text-xs font-rajdhani font-semibold text-slate-300">
                  Custom Hex Pigment:
                </span>
                <input
                  type="color"
                  value={currentColor}
                  onChange={(e) => handleColorChange(e.target.value)}
                  className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
                />
              </div>
            </div>
          )}

          {/* Spoilers Tab */}
          {activeTab === 'spoilers' && (
            <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-5 space-y-4">
              <div>
                <h3 className="font-orbitron font-bold text-sm text-white uppercase tracking-wider">
                  Aerodynamic Spoilers & Wings
                </h3>
                <p className="font-rajdhani text-xs text-slate-400 mt-0.5">
                  Equip high-downforce racing wings to stabilize high-speed highway cornering.
                </p>
              </div>

              <div className="space-y-3">
                {SPOILER_OPTIONS.map((sp) => {
                  const isCurrent = currentCustomization.spoiler === sp.id;
                  return (
                    <button
                      key={sp.id}
                      onClick={() => handleSpoilerChange(sp.id)}
                      className={`w-full p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                        isCurrent
                          ? 'bg-cyan-950/70 border-cyan-400 shadow-md shadow-cyan-500/20'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-orbitron font-bold text-xs text-white">
                            {sp.name}
                          </span>
                          {isCurrent && (
                            <span className="text-[10px] font-orbitron font-bold px-1.5 py-0.2 rounded bg-cyan-500 text-black">
                              ACTIVE
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] font-rajdhani text-slate-400 mt-0.5">
                          {sp.desc}
                        </p>
                      </div>

                      <div className="pl-3 text-right">
                        {isCurrent ? (
                          <Check className="w-5 h-5 text-cyan-400" />
                        ) : (
                          <span className="text-xs font-orbitron font-bold text-cyan-400">
                            EQUIP
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Wheels Tab */}
          {activeTab === 'wheels' && (
            <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-5 space-y-5">
              <div>
                <h3 className="font-orbitron font-bold text-sm text-white uppercase tracking-wider">
                  Forged Alloys & Rim Finishes
                </h3>
                <p className="font-rajdhani text-xs text-slate-400 mt-0.5">
                  Select wheel spoke geometry and metallic anodized coating.
                </p>
              </div>

              {/* Wheel Styles */}
              <div className="space-y-2.5">
                <span className="text-xs font-orbitron font-bold text-slate-300 block">
                  WHEEL MODEL
                </span>
                <div className="grid grid-cols-2 gap-2.5">
                  {WHEEL_OPTIONS.map((wh) => {
                    const isCurrent = currentCustomization.wheelStyle === wh.id;
                    return (
                      <button
                        key={wh.id}
                        onClick={() => handleWheelStyleChange(wh.id)}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-cyan-950/70 border-cyan-400 shadow-sm shadow-cyan-500/20'
                            : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-orbitron font-bold text-xs text-white truncate">
                            {wh.name}
                          </span>
                          {isCurrent && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                        </div>
                        <p className="text-[10px] font-rajdhani text-slate-400 mt-0.5 line-clamp-1">
                          {wh.desc}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Wheel Rim Colors */}
              <div className="space-y-2.5 pt-2 border-t border-slate-800">
                <span className="text-xs font-orbitron font-bold text-slate-300 block">
                  RIM FINISH COLOR
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {WHEEL_COLOR_OPTIONS.map((wc) => {
                    const isCurrent = currentCustomization.wheelColor === wc.hex;
                    return (
                      <button
                        key={wc.hex}
                        onClick={() => handleWheelColorChange(wc.hex)}
                        className={`p-2 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                          isCurrent
                            ? 'border-cyan-400 bg-slate-800'
                            : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                        }`}
                      >
                        <div
                          className="w-4 h-4 rounded-full border border-white/40 shadow-sm"
                          style={{ backgroundColor: wc.hex }}
                        />
                        <span className="text-[10px] font-rajdhani font-semibold text-slate-300 truncate">
                          {wc.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Neon Underglow Tab */}
          {activeTab === 'neon' && (
            <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-5 space-y-4">
              <div>
                <h3 className="font-orbitron font-bold text-sm text-white uppercase tracking-wider">
                  Neon Ground Illumination
                </h3>
                <p className="font-rajdhani text-xs text-slate-400 mt-0.5">
                  Cast vibrant cyberpunk underglow onto the highway asphalt surface.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {NEON_UNDERGLOW_OPTIONS.map((neon) => {
                  const isCurrent = currentCustomization.neonUnderglow === neon.hex;
                  return (
                    <button
                      key={neon.hex}
                      onClick={() => handleNeonChange(neon.hex)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                        isCurrent
                          ? 'border-cyan-400 bg-slate-800 shadow-md shadow-cyan-500/20'
                          : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 rounded-full border border-white/40 flex items-center justify-center ${
                          neon.hex === 'none' ? 'bg-slate-800 text-slate-500 text-[10px]' : ''
                        }`}
                        style={{
                          backgroundColor: neon.hex === 'none' ? undefined : neon.hex,
                          boxShadow: neon.hex === 'none' ? undefined : `0 0 10px ${neon.hex}`,
                        }}
                      >
                        {neon.hex === 'none' && '✕'}
                      </div>
                      <div>
                        <span className="font-orbitron font-bold text-xs text-white block">
                          {neon.name}
                        </span>
                        <span className="text-[10px] font-rajdhani text-slate-400">
                          {isCurrent ? 'Equipped' : 'Click to equip'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

