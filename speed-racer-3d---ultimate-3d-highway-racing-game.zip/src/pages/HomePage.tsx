import React from 'react';
import {
  Play,
  Wrench,
  Gift,
  Flame,
  Zap,
  Timer,
  Coins,
  Sun,
  Sunset,
  Moon,
  CloudRain,
  ChevronRight,
  ShieldAlert,
  Car,
  Users,
  Sparkles,
  Trophy,
  Gauge,
  Compass,
  Check
} from 'lucide-react';
import { useGame } from '../context/GameContext';
import { CARS_CATALOG, WEATHER_ENVIRONMENTS } from '../utils/constants';
import { GameMode, WeatherMode } from '../types/game';
import { AdBanner } from '../components/AdBanner';
import { sound } from '../utils/audio';

export function HomePage() {
  const {
    profile,
    setActivePage,
    selectedGameMode,
    setSelectedGameMode,
    selectedWeather,
    setSelectedWeather,
    setIsDailyBonusModalOpen,
    setIsLuckySpinModalOpen,
    setIsMissionsModalOpen,
    canClaimDailyBonus,
    canSpinLuckyWheel,
  } = useGame();

  const selectedCar = CARS_CATALOG.find((c) => c.id === profile.selectedCarId) || CARS_CATALOG[0];
  const userCarColor = profile.carColors[selectedCar.id] || selectedCar.defaultColor;

  const gameModes: {
    id: GameMode;
    title: string;
    subtitle: string;
    icon: React.ReactNode;
    badge: string;
    color: string;
  }[] = [
    {
      id: 'endless',
      title: 'Endless Highway',
      subtitle: 'Survive the high-speed traffic for as long as possible. Traffic density ramps up dynamically.',
      icon: <Flame className="w-6 h-6 text-orange-400" />,
      badge: 'ENDURANCE',
      color: 'border-orange-500/40 hover:border-orange-400',
    },
    {
      id: 'policeChase',
      title: 'Police Pursuit 5★',
      subtitle: 'Evade high-speed police cruisers with active sirens, escalating Wanted levels, and highway roadblocks!',
      icon: <ShieldAlert className="w-6 h-6 text-rose-500" />,
      badge: 'ACTION',
      color: 'border-rose-500/50 hover:border-rose-400',
    },
    {
      id: 'multiplayer',
      title: 'Online Multiplayer',
      subtitle: 'Race real players online over real-time WebSockets! See live cars, distance positions, and speed rankings.',
      icon: <Users className="w-6 h-6 text-emerald-400" />,
      badge: 'REAL-TIME WS',
      color: 'border-emerald-500/40 hover:border-emerald-400',
    },
    {
      id: 'trafficChallenge',
      title: 'Traffic Challenge',
      subtitle: 'Heavy bumper-to-bumper rush hour congestion. Weave through tight lane gaps for huge coin rewards.',
      icon: <Car className="w-6 h-6 text-cyan-400" />,
      badge: 'AGILITY',
      color: 'border-cyan-500/40 hover:border-cyan-400',
    },
    {
      id: 'timeAttack',
      title: 'Time Challenge',
      subtitle: 'Race against the clock! Cross highway checkpoints every 450m to add +14 seconds to your timer.',
      icon: <Timer className="w-6 h-6 text-sky-400" />,
      badge: 'CHECKPOINTS',
      color: 'border-sky-500/40 hover:border-sky-400',
    },
    {
      id: 'coinRush',
      title: 'Coin Collection Rush',
      subtitle: 'Rich gold and diamond coin deposits. Collect magnet power-ups to accumulate massive wealth.',
      icon: <Coins className="w-6 h-6 text-amber-400" />,
      badge: 'WEALTH',
      color: 'border-amber-500/40 hover:border-amber-400',
    },
  ];

  const startRace = (mode?: GameMode) => {
    if (mode) setSelectedGameMode(mode);
    setActivePage('play');
    sound.playClick();
  };

  const completedMissionsCount = profile.dailyMissions.missions.filter((m) => m.completed && !m.claimed).length;

  return (
    <div className="w-full min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Hero Showcase Section */}
      <div className="relative rounded-3xl bg-gradient-to-br from-[#0c1322] via-[#090d16] to-[#140e1f] border border-cyan-500/30 p-8 sm:p-12 overflow-hidden shadow-2xl shadow-cyan-950/40">
        {/* Glow backdrop shapes */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Hero Copy */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-orbitron font-semibold">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>ULTIMATE 3D HIGHWAY RACING SIMULATION</span>
            </div>

            <h1 className="font-orbitron font-black text-4xl sm:text-6xl lg:text-7xl text-white tracking-tight leading-[1.08]">
              SPEED RACER <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-orange-400 glow-text-cyan">3D</span>
            </h1>

            <p className="text-slate-300 font-rajdhani text-base sm:text-lg max-w-xl leading-relaxed">
              Dodge intense 3D highway traffic, deploy nitrous oxide boosts, evade 5-Star police cruisers, compete in live real-time multiplayer, and race through 8 dynamic weather environments.
            </p>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => startRace()}
                className="px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-orbitron font-black text-base tracking-wider shadow-xl shadow-cyan-500/30 glow-cyan transition-all transform active:scale-95 flex items-center gap-3 cursor-pointer"
              >
                <Play className="w-5 h-5 fill-black" />
                <span>PLAY NOW</span>
              </button>

              <button
                onClick={() => {
                  setActivePage('garage');
                  sound.playClick();
                }}
                className="px-6 py-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-white font-orbitron font-bold text-sm tracking-wider flex items-center gap-2.5 transition-all cursor-pointer"
              >
                <Wrench className="w-4 h-4 text-orange-400" />
                <span>3D GARAGE</span>
              </button>

              <button
                onClick={() => {
                  setIsLuckySpinModalOpen(true);
                  sound.playClick();
                }}
                className="relative px-5 py-4 rounded-2xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 hover:from-purple-500/30 hover:to-pink-500/30 border border-purple-500/50 text-purple-300 font-rajdhani font-bold text-sm flex items-center gap-2 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Lucky Spin</span>
                {canSpinLuckyWheel && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </button>

              <button
                onClick={() => {
                  setIsMissionsModalOpen(true);
                  sound.playClick();
                }}
                className="relative px-5 py-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 font-rajdhani font-bold text-sm flex items-center gap-2 transition-all cursor-pointer"
              >
                <Compass className="w-4 h-4 text-cyan-400" />
                <span>Missions</span>
                {completedMissionsCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-orange-500 text-black text-[10px] font-orbitron font-bold">
                    {completedMissionsCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  setIsDailyBonusModalOpen(true);
                  sound.playClick();
                }}
                className="relative px-5 py-4 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 border border-amber-500/50 text-amber-300 font-rajdhani font-bold text-sm flex items-center gap-2 transition-all cursor-pointer"
              >
                <Gift className="w-4 h-4 text-amber-400" />
                <span>{canClaimDailyBonus ? 'Daily Bonus (20 Coins)' : 'Daily Bonus'}</span>
                {canClaimDailyBonus && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                )}
              </button>
            </div>
          </div>

          {/* Hero Featured Car Card */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-slate-900/80 border border-slate-700/80 p-6 relative overflow-hidden backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-orbitron font-bold text-slate-400 uppercase tracking-wider">
                  Active Vehicle
                </span>
                <span className="text-[11px] font-rajdhani font-bold px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
                  {selectedCar.badge}
                </span>
              </div>

              {/* Color swatch & Car Title */}
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-5 h-5 rounded-full border-2 border-white/80 shadow-md"
                  style={{ backgroundColor: userCarColor }}
                />
                <div>
                  <h3 className="font-orbitron font-black text-xl text-white">
                    {selectedCar.name}
                  </h3>
                  <span className="text-xs font-rajdhani text-slate-400">
                    Category: {selectedCar.category}
                  </span>
                </div>
              </div>

              {/* Stat bars */}
              <div className="space-y-2.5 text-xs font-rajdhani font-semibold">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Top Speed: {selectedCar.topSpeedKmh} KM/H</span>
                    <span>{selectedCar.baseSpeed * 10}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                      style={{ width: `${selectedCar.baseSpeed * 10}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Acceleration</span>
                    <span>{selectedCar.baseAcceleration * 10}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full"
                      style={{ width: `${selectedCar.baseAcceleration * 10}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Handling / Agility</span>
                    <span>{selectedCar.baseHandling * 10}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
                      style={{ width: `${selectedCar.baseHandling * 10}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Enter Garage CTA */}
              <button
                onClick={() => {
                  setActivePage('garage');
                  sound.playClick();
                }}
                className="mt-5 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600/70 text-slate-200 text-xs font-orbitron font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <span>Customize & Upgrade In Garage</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Select Environment / 8 Weather Modes Gallery */}
      <div className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-orbitron font-black text-xl sm:text-2xl text-white">
                8 DYNAMIC WEATHER ENVIRONMENTS
              </h3>
              <span className="text-[10px] font-orbitron font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40">
                REAL-TIME 3D
              </span>
            </div>
            <p className="font-rajdhani text-sm text-slate-400 mt-1">
              Select any atmospheric mode to transform the 3D sky dome, roadside flora, ground fog, road surface reflections, and weather particles.
            </p>
          </div>

          <div className="text-xs font-rajdhani text-cyan-400 font-bold px-3 py-1.5 rounded-xl bg-cyan-950/50 border border-cyan-500/30 w-fit">
            Selected: <span className="uppercase text-white">{selectedWeather}</span>
          </div>
        </div>

        {/* 8 Weather Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {WEATHER_ENVIRONMENTS.map((env) => {
            const isSelected = selectedWeather === env.id;
            return (
              <button
                key={env.id}
                onClick={() => {
                  setSelectedWeather(env.id);
                  sound.playClick();
                }}
                className={`group relative rounded-2xl p-4 text-left border-2 transition-all cursor-pointer overflow-hidden flex flex-col justify-between min-h-[160px] ${
                  isSelected
                    ? 'border-cyan-400 bg-slate-900 shadow-xl shadow-cyan-950/60'
                    : 'border-slate-800 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                {/* Wallpaper gradient banner */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${env.gradient} opacity-20 group-hover:opacity-30 transition-opacity`}
                />

                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-orbitron font-black text-base text-white">
                      {env.name}
                    </span>
                    {isSelected ? (
                      <span className="p-1 rounded-full bg-cyan-400 text-black">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    ) : (
                      <div
                        className="w-3.5 h-3.5 rounded-full border border-white/50"
                        style={{ backgroundColor: env.skyColor }}
                      />
                    )}
                  </div>

                  <p className="text-xs font-rajdhani font-semibold text-slate-300 leading-snug">
                    {env.tagline}
                  </p>
                </div>

                {/* Features pill list */}
                <div className="relative z-10 pt-3 border-t border-white/10 flex flex-wrap gap-1 mt-2">
                  {env.features.slice(0, 2).map((feat, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-rajdhani font-bold px-1.5 py-0.5 rounded bg-black/40 text-slate-300"
                    >
                      {feat}
                    </span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Game Modes Selection */}
      <div className="space-y-6">
        <div>
          <h2 className="font-orbitron font-black text-2xl sm:text-3xl text-white">
            CHOOSE GAME MODE
          </h2>
          <p className="font-rajdhani text-slate-400 text-sm">
            Six thrilling gameplay types ranging from high-speed police chases and real-time multiplayer to traffic weaving challenges.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gameModes.map((mode) => {
            const isSelected = selectedGameMode === mode.id;
            const highScore = profile.highScores[mode.id as keyof typeof profile.highScores] || 0;

            return (
              <div
                key={mode.id}
                onClick={() => {
                  setSelectedGameMode(mode.id);
                  sound.playClick();
                }}
                className={`relative rounded-2xl bg-slate-900/80 border-2 p-6 flex flex-col justify-between transition-all cursor-pointer ${
                  isSelected
                    ? `${mode.color} bg-slate-900 shadow-xl shadow-cyan-950/50`
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 rounded-xl bg-slate-800">
                      {mode.icon}
                    </div>
                    <span className="text-[10px] font-orbitron font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {mode.badge}
                    </span>
                  </div>

                  <h3 className="font-orbitron font-black text-xl text-white mb-2">
                    {mode.title}
                  </h3>
                  <p className="font-rajdhani text-sm text-slate-400 leading-relaxed">
                    {mode.subtitle}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-rajdhani font-semibold text-cyan-400">
                    High Score: {highScore.toLocaleString()} pts
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      startRace(mode.id);
                    }}
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-black font-orbitron font-black text-xs tracking-wider flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>RACE</span>
                    <Play className="w-3.5 h-3.5 fill-black" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AdSense Placement */}
      <AdBanner format="leaderboard" />

      {/* Game Features Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4">
        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-4">
          <div className="p-3 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
            <Gauge className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-orbitron font-bold text-white text-base">
              Physics & Aerodynamics
            </h4>
            <p className="font-rajdhani text-sm text-slate-400 mt-1">
              Realistic suspension roll, cornering lateral grip, acceleration dive, and nitro FOV expansion.
            </p>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-4">
          <div className="p-3 rounded-xl bg-orange-950/60 border border-orange-500/30 text-orange-400">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-orbitron font-bold text-white text-base">
              Near-Miss Multipliers
            </h4>
            <p className="font-rajdhani text-sm text-slate-400 mt-1">
              Graze past oncoming and overtaking vehicles at breakneck speed to earn consecutive bonus coins.
            </p>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-4">
          <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/30 text-amber-400">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-orbitron font-bold text-white text-base">
              Supercar Collection & Tuning
            </h4>
            <p className="font-rajdhani text-sm text-slate-400 mt-1">
              Unlock 6 sports, super, and hypercars with custom spoilers, forged wheels, neon underglow, and ECU upgrades.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

