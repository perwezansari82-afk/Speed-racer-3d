import React, { useState } from 'react';
import { Trophy, Medal, Flame, Timer, Coins, Award, User, Crown, ShieldAlert, Car } from 'lucide-react';
import { useGame } from '../context/GameContext';
import { GameMode } from '../types/game';
import { AdBanner } from '../components/AdBanner';
import { sound } from '../utils/audio';

export function LeaderboardPage() {
  const { profile, leaderboardEntries, setActivePage } = useGame();
  const [selectedMode, setSelectedMode] = useState<GameMode>('endless');

  const modes: { id: GameMode; label: string; icon: React.ReactNode }[] = [
    { id: 'endless', label: 'Endless', icon: <Flame className="w-4 h-4 text-orange-400" /> },
    { id: 'policeChase', label: 'Police 5★', icon: <ShieldAlert className="w-4 h-4 text-rose-500" /> },
    { id: 'trafficChallenge', label: 'Traffic', icon: <Car className="w-4 h-4 text-cyan-400" /> },
    { id: 'timeAttack', label: 'Time Attack', icon: <Timer className="w-4 h-4 text-sky-400" /> },
    { id: 'coinRush', label: 'Coin Rush', icon: <Coins className="w-4 h-4 text-amber-400" /> },
  ];

  const personalBest = (profile.highScores as Record<string, number>)[selectedMode] ?? 0;

  return (
    <div className="w-full min-h-screen py-8 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-orbitron font-semibold">
          <Crown className="w-4 h-4" />
          <span>GLOBAL HIGHWAY HALL OF FAME</span>
        </div>

        <h1 className="font-orbitron font-black text-3xl sm:text-5xl text-white">
          SPEED RACER LEADERBOARDS
        </h1>

        <p className="font-rajdhani text-sm sm:text-base text-slate-400 max-w-xl mx-auto">
          Top records achieved across global highway sessions. Compete against top times and push your car to its absolute limits.
        </p>
      </div>

      {/* Mode Filter Tabs */}
      <div className="flex justify-center">
        <div className="inline-flex p-1.5 rounded-2xl bg-slate-900 border border-slate-800">
          {modes.map((m) => {
            const isActive = selectedMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setSelectedMode(m.id);
                  sound.playClick();
                }}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-orbitron text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-cyan-600 text-black shadow-md shadow-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {m.icon}
                <span>{m.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Leaderboard Table Card */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 overflow-hidden shadow-2xl">
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="font-orbitron font-bold text-base text-white">
              Top Ranked Drivers ({modes.find((m) => m.id === selectedMode)?.label})
            </h3>
          </div>
          <span className="text-xs font-rajdhani text-cyan-400 font-semibold">
            Your Personal Best: {personalBest.toLocaleString()} pts
          </span>
        </div>

        {/* Entries List */}
        <div className="divide-y divide-slate-800/80">
          {leaderboardEntries.map((entry) => {
            const isCurrentPlayer = entry.id === 'player';
            return (
              <div
                key={entry.id}
                className={`p-4 sm:p-5 flex items-center justify-between transition-colors ${
                  isCurrentPlayer
                    ? 'bg-cyan-950/40 border-l-4 border-l-cyan-400'
                    : 'hover:bg-slate-850/50'
                }`}
              >
                {/* Rank & Driver */}
                <div className="flex items-center gap-4">
                  {/* Rank badge */}
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-orbitron font-black text-sm ${
                      entry.rank === 1
                        ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/30'
                        : entry.rank === 2
                        ? 'bg-slate-300 text-black'
                        : entry.rank === 3
                        ? 'bg-amber-700 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {entry.rank}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-orbitron font-bold text-sm sm:text-base text-white">
                        {entry.name}
                      </span>
                      {isCurrentPlayer && (
                        <span className="text-[10px] font-orbitron font-extrabold px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                          YOU
                        </span>
                      )}
                    </div>
                    <span className="text-xs font-rajdhani text-slate-400">
                      Vehicle: {entry.car} • {entry.date}
                    </span>
                  </div>
                </div>

                {/* Score */}
                <div className="text-right">
                  <span className="font-orbitron font-black text-base sm:text-xl text-cyan-300 block">
                    {entry.score.toLocaleString()}
                  </span>
                  <span className="text-[10px] font-rajdhani text-slate-500 uppercase tracking-wider">
                    POINTS
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AdSense Placement */}
      <AdBanner format="leaderboard" />
    </div>
  );
}
