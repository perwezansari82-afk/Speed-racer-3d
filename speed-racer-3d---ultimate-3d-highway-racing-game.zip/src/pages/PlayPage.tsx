import React, { useRef, useState, useEffect } from 'react';
import { useGame } from '../context/GameContext';
import { RacingGame, GameHUDState } from '../game/RacingGame';
import { CARS_CATALOG } from '../utils/constants';
import { GameHUD } from '../components/GameHUD';
import { MobileControls } from '../components/MobileControls';
import { GameOverModal } from '../components/GameOverModal';
import { RaceResult } from '../types/game';
import { sound } from '../utils/audio';

export function PlayPage() {
  const {
    profile,
    setActivePage,
    selectedGameMode,
    selectedWeather,
    recordRaceResult,
    updateMissionProgress,
  } = useGame();

  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<RacingGame | null>(null);

  const [roomId, setRoomId] = useState('speedway-alpha');
  const [hudState, setHudState] = useState<GameHUDState>({
    speedKmh: 0,
    distanceMeters: 0,
    score: 0,
    coinsEarned: 0,
    nitroPercent: 100,
    timeRemainingSeconds: 60,
    nearMissCombo: 0,
    magnetActive: false,
    isPaused: false,
    isGameOver: false,
    wantedLevel: 0,
    policeDistance: 120,
    policeEvadedCount: 0,
    multiplayerPlayers: [],
    currentRank: 1,
    isMultiplayerConnected: false,
  });

  const [gameOverResult, setGameOverResult] = useState<RaceResult | null>(null);
  const [isNewHighScore, setIsNewHighScore] = useState(false);
  const [nearMissFlash, setNearMissFlash] = useState<number | null>(null);
  const [showControlsHint, setShowControlsHint] = useState(true);

  // Fade out controls hint after 6 seconds
  useEffect(() => {
    const timer = setTimeout(() => setShowControlsHint(false), 6500);
    return () => clearTimeout(timer);
  }, []);

  const selectedCar = CARS_CATALOG.find((c) => c.id === profile.selectedCarId) || CARS_CATALOG[0];
  const userCarColor = profile.carColors[selectedCar.id] || selectedCar.defaultColor;
  const userUpgrades = profile.carUpgrades[selectedCar.id] || { engine: 0, speed: 0, handling: 0, nitro: 0 };
  const userCustomization = profile.carCustomizations[selectedCar.id] || {
    color: userCarColor,
    spoiler: 'none',
    wheelStyle: 'sport5',
    wheelColor: '#d1d5db',
    neonUnderglow: 'none',
  };

  const initGame = () => {
    if (!containerRef.current) return;

    if (gameRef.current) {
      gameRef.current.destroy();
      gameRef.current = null;
    }

    setGameOverResult(null);
    setIsNewHighScore(false);

    const game = new RacingGame({
      container: containerRef.current,
      carDef: selectedCar,
      upgrades: userUpgrades,
      carColor: userCarColor,
      customization: userCustomization,
      gameMode: selectedGameMode,
      weather: selectedWeather,
      playerName: profile.name || 'SpeedRacer',
      multiplayerRoomId: roomId,
      onHUDUpdate: (hud) => {
        setHudState(hud);
      },
      onGameOver: (result) => {
        const { isNewHighScore } = recordRaceResult(result);
        setIsNewHighScore(isNewHighScore);
        setGameOverResult(result);
      },
      onNearMissBonus: (combo) => {
        setNearMissFlash(combo);
        setTimeout(() => setNearMissFlash(null), 1400);
      },
      onMissionProgress: (type, amount) => {
        updateMissionProgress(type, amount);
      },
    });

    gameRef.current = game;
  };

  useEffect(() => {
    initGame();
    return () => {
      if (gameRef.current) {
        gameRef.current.destroy();
        gameRef.current = null;
      }
    };
  }, [selectedCar.id, userCarColor, selectedGameMode, selectedWeather, roomId]);

  const handleTogglePause = () => {
    if (gameRef.current) {
      gameRef.current.togglePause();
      sound.playClick();
    }
  };

  const handleRestart = () => {
    initGame();
  };

  const handleGoToGarage = () => {
    setActivePage('garage');
  };

  return (
    <div className="relative w-full h-[calc(100vh-4.5rem)] bg-black overflow-hidden select-none">
      {/* 3D Canvas Mount */}
      <div ref={containerRef} className="w-full h-full" />

      {/* Interactive HUD Overlay */}
      <GameHUD
        hudState={hudState}
        gameMode={selectedGameMode}
        weather={selectedWeather}
        onTogglePause={handleTogglePause}
        nearMissFlash={nearMissFlash}
      />

      {/* Mobile Touch Controls Overlay */}
      <MobileControls gameInstance={gameRef.current} />

      {/* Desktop Keyboard Controls Overlay Reminder */}
      {showControlsHint && !hudState.isGameOver && (
        <div className="hidden md:flex absolute top-20 left-1/2 -translate-x-1/2 px-4 py-2 rounded-xl bg-slate-900/85 border border-cyan-500/30 text-xs font-rajdhani font-semibold text-slate-300 pointer-events-none backdrop-blur-sm z-30 transition-opacity animate-in fade-in">
          <span>[A / D] or [← / →] Steer • [W / ↑] Accelerate • [S / ↓] Brake • [Shift / Space] Nitro • [Esc / P] Pause</span>
        </div>
      )}

      {/* Game Over Modal */}
      {gameOverResult && (
        <GameOverModal
          result={gameOverResult}
          isNewHighScore={isNewHighScore}
          onRestart={handleRestart}
          onGoToGarage={handleGoToGarage}
        />
      )}
    </div>
  );
}

