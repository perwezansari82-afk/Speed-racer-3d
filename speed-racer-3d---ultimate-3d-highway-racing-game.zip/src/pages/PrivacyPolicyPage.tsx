import React from 'react';
import { Shield, Lock, FileText, CheckCircle, Cookie, Eye, ExternalLink, Mail } from 'lucide-react';
import { AdBanner } from '../components/AdBanner';

const OWNER_EMAIL = 'perwezansari59@gmail.com';

export function PrivacyPolicyPage() {
  return (
    <div className="w-full min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8 text-slate-300 font-rajdhani">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-orbitron font-semibold">
          <Shield className="w-4 h-4 text-cyan-400" />
          <span>OFFICIAL PRIVACY POLICY</span>
        </div>
        <h1 className="font-orbitron font-black text-3xl sm:text-5xl text-white">
          PRIVACY POLICY
        </h1>
        <p className="text-sm text-slate-400">
          Last Updated: November 2026 • Valid for SPEED RACER 3D Worldwide
        </p>
      </div>

      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-10 space-y-8 leading-relaxed text-sm sm:text-base">
        {/* Section 1: Introduction */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white flex items-center gap-2">
            <span>1. Introduction & Overview</span>
          </h2>
          <p>
            Welcome to <strong>SPEED RACER 3D</strong>. We recognize the importance of player privacy and are dedicated to safeguarding any data processed while you enjoy our 3D web racing game.
          </p>
          <p>
            SPEED RACER 3D does not require user account registration, passwords, credit card credentials, or personal identity verification. You can enjoy the full racing simulation, upgrade vehicles, and claim rewards with zero personal friction.
          </p>
        </section>

        {/* Section 2: Data Collection & Local Storage */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white flex items-center gap-2">
            <Lock className="w-5 h-5 text-cyan-400" />
            <span>2. Data Collection & LocalStorage Technology</span>
          </h2>
          <p>
            To deliver seamless gameplay and persistent progress without transmitting personal data to third-party databases, SPEED RACER 3D utilizes client-side HTML5 <code>localStorage</code> within your device browser. The data stored includes:
          </p>
          <ul className="list-disc list-inside space-y-1.5 text-slate-400 pl-2">
            <li><strong>Driver Profile:</strong> Your chosen nickname or driver callsign (e.g., VelocityRacer).</li>
            <li><strong>Virtual Economy:</strong> Your virtual gold coin balance, unlocked car IDs, and installed tuning levels (Engine, Speed, Handling, Nitro).</li>
            <li><strong>Customization:</strong> Saved vehicle color paint codes and presets.</li>
            <li><strong>Daily Bonus Stamp:</strong> The calendar date (<code className="text-cyan-400">YYYY-MM-DD</code>) of your last daily reward claim to enforce the once-per-day 20 coin bonus.</li>
            <li><strong>Driver Preferences:</strong> Audio master volumes, music toggle, and chosen graphic quality level.</li>
          </ul>
          <p>
            This data remains strictly stored on your own device. You can reset or clear all saved game progress anytime by clicking the "Reset Progress" option in the game settings or clearing your browser cache.
          </p>
        </section>

        {/* Section 3: Cookies, Analytics & Third-Party Services */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white flex items-center gap-2">
            <Cookie className="w-5 h-5 text-amber-400" />
            <span>3. Cookies, Analytics & Third-Party Services</span>
          </h2>
          <p>
            Cookies are small text files placed on your device to enhance your experience and support essential website services. SPEED RACER 3D may use standard web cookies and performance analytics to:
          </p>
          <ul className="list-disc list-inside space-y-1.5 text-slate-400 pl-2">
            <li>Analyze aggregate gameplay metrics (e.g., frame rate stability, browser compatibility).</li>
            <li>Monitor server response times and contact ticket deliveries.</li>
            <li>Prevent abuse, automated bot traffic, or denial-of-service attempts.</li>
          </ul>
          <p>
            You can configure your browser to decline cookies or notify you when cookies are placed. However, disabling all cookies may affect minor web features.
          </p>
        </section>

        {/* Section 4: Google AdSense & Advertising Information */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white flex items-center gap-2">
            <Eye className="w-5 h-5 text-orange-400" />
            <span>4. Google AdSense Advertising & Cookies</span>
          </h2>
          <p>
            To keep SPEED RACER 3D free for all players, we may display third-party advertisements via <strong>Google AdSense</strong> and authorized digital advertising partners.
          </p>
          <p>
            Google, as a third-party advertising vendor, uses cookies to serve contextual and interest-based ads on this website:
          </p>
          <ul className="list-disc list-inside space-y-1.5 text-slate-400 pl-2">
            <li>Google's use of advertising cookies (such as the DoubleClick cookie) enables it and its partners to serve ads based on prior visits to our site or other websites across the Internet.</li>
            <li>All advertising banners on SPEED RACER 3D are clearly demarcated with the explicit marker <span className="text-cyan-400 font-semibold">[ADVERTISEMENT]</span> and are strictly positioned away from game steering and acceleration controls to prevent accidental clicks.</li>
            <li>Users can opt out of personalized advertising at any time by visiting Google's <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline font-semibold inline-flex items-center gap-1">Ad Settings <ExternalLink className="w-3 h-3" /></a>.</li>
            <li>You can also opt out of third-party vendor cookies for personalized advertising by visiting <a href="https://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline font-semibold inline-flex items-center gap-1">AboutAds.info <ExternalLink className="w-3 h-3" /></a> or the <a href="https://www.networkadvertising.org/choices/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline font-semibold inline-flex items-center gap-1">Network Advertising Initiative <ExternalLink className="w-3 h-3" /></a>.</li>
          </ul>
        </section>

        {/* Section 5: WebGL & Hardware Access */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            <span>5. Graphics, Hardware & Audio Permissions</span>
          </h2>
          <p>
            SPEED RACER 3D utilizes the HTML5 WebGL 2.0 API to render 3D geometry and the Web Audio API to synthesize engine frequencies. We do not access:
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
            <li>Your camera or webcam</li>
            <li>Your microphone or voice inputs</li>
            <li>Your GPS location coordinates or address</li>
            <li>Your local files or contact lists</li>
          </ul>
        </section>

        {/* Section 6: Children's Privacy (COPPA Compliance) */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white">
            6. Children's Online Privacy Protection (COPPA)
          </h2>
          <p>
            SPEED RACER 3D is a general-audience casual gaming site. We do not knowingly solicit or collect personal identifiable information from children under the age of 13. If you believe that a minor has submitted personal contact information via our contact form, please notify us immediately so we can promptly erase the record from our server queues.
          </p>
        </section>

        {/* Section 7: User Rights & Data Deletion */}
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white">
            7. Your Privacy Rights (GDPR & CCPA)
          </h2>
          <p>
            Depending on your jurisdiction (such as the European Union or California), you retain the right to:
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
            <li>Request access to any information submitted via the contact form.</li>
            <li>Request immediate deletion of any submitted support dispatches.</li>
            <li>Opt out of any non-essential cookies and targeted advertising.</li>
          </ul>
        </section>

        {/* Section 8: How to Contact the Owner */}
        <section className="space-y-3 p-5 rounded-2xl bg-slate-950 border border-slate-800">
          <h2 className="font-orbitron font-bold text-lg sm:text-xl text-white flex items-center gap-2">
            <Mail className="w-5 h-5 text-cyan-400" />
            <span>8. Contacting the Website Owner About Privacy</span>
          </h2>
          <p>
            If you have any questions, inquiries, or data requests regarding this Privacy Policy or our information practices, you may directly reach the website owner and developer at:
          </p>
          <div className="pt-2 text-sm">
            <p className="font-semibold text-white">SPEED RACER 3D Engineering & Privacy Office</p>
            <p className="text-slate-400">Direct Email: <a href={`mailto:${OWNER_EMAIL}`} className="text-cyan-400 font-bold hover:underline">{OWNER_EMAIL}</a></p>
            <p className="text-slate-400">Online Support Form: Available under the Contact Us section</p>
          </div>
        </section>
      </div>

      <AdBanner format="leaderboard" />
    </div>
  );
}
