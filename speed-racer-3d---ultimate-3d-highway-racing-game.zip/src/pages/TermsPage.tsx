import React from 'react';
import { FileText, CheckCircle } from 'lucide-react';
import { AdBanner } from '../components/AdBanner';

export function TermsPage() {
  return (
    <div className="w-full min-h-screen py-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-8 text-slate-300 font-rajdhani">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-orbitron font-semibold">
          <FileText className="w-4 h-4 text-cyan-400" />
          <span>TERMS OF SERVICE</span>
        </div>
        <h1 className="font-orbitron font-black text-3xl sm:text-4xl text-white">
          TERMS AND CONDITIONS
        </h1>
        <p className="text-sm text-slate-400">
          Last Updated: November 2026
        </p>
      </div>

      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-10 space-y-8 leading-relaxed text-sm sm:text-base">
        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            1. Acceptance of Terms
          </h2>
          <p>
            By accessing or playing SPEED RACER 3D, you agree to comply with and be bound by these Terms and Conditions. If you disagree with any portion of these terms, please discontinue use of the game.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            2. In-Game Virtual Currency & Upgrades
          </h2>
          <p>
            All coins, vehicles, upgrade tiers, and badges earned or collected within SPEED RACER 3D are purely virtual digital tokens. They possess no cash value, cannot be redeemed for real-world fiat or cryptocurrency, and cannot be transferred or traded between independent players.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            3. Intellectual Property Rights
          </h2>
          <p>
            The software, 3D procedural car geometry, audio synthesis algorithms, graphics, user interface designs, and code underlying SPEED RACER 3D are protected by copyright, trademark, and proprietary software rights. Users may not reverse-engineer, redistribute, or commercially exploit any code or game assets without explicit written authorization.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            4. Fair Play & Prohibited Conduct
          </h2>
          <p>
            Players agree not to exploit automated bot scripts or tamper with browser code to artificially manipulate leaderboard high scores or coin counts. SPEED RACER 3D reserves the right to sanitize corrupted or manipulated client saves.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-orbitron font-bold text-lg text-white">
            5. Modifications to the Service
          </h2>
          <p>
            We reserve the right to update vehicle statistics, game mechanics, and feature availability at any time to balance competitive gameplay.
          </p>
        </section>
      </div>

      <AdBanner format="leaderboard" />
    </div>
  );
}
