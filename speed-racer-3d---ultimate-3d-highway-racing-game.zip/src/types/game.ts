export type GameMode =
  | 'endless'
  | 'timeAttack'
  | 'coinRush'
  | 'policeChase'
  | 'trafficChallenge'
  | 'multiplayer';

export type WeatherMode =
  | 'day'
  | 'night'
  | 'rain'
  | 'snow'
  | 'desert'
  | 'forest'
  | 'ocean'
  | 'sunset';

export type CameraView = 'chase' | 'hood' | 'cinematic';

export type SpoilerStyle = 'none' | 'lip' | 'gtWing' | 'cyberFins' | 'extremeCarbon';

export type WheelStyle = 'sport5' | 'mesh12' | 'cyberDish' | 'concave';

export interface CarCustomization {
  color: string;
  spoiler: SpoilerStyle;
  wheelStyle: WheelStyle;
  wheelColor: string;
  neonUnderglow: string; // hex or 'none'
}

export interface CarUpgrades {
  engine: number;    // 0 - 5 (acceleration)
  speed: number;     // 0 - 5 (top speed)
  handling: number;  // 0 - 5 (steering responsiveness & grip)
  nitro: number;     // 0 - 5 (nitro duration & boost power)
}

export interface CarDefinition {
  id: string;
  name: string;
  category: 'Starter' | 'Sports' | 'Supercar' | 'Hypercar' | 'Concept' | 'Stealth';
  price: number; // 0 = free starter car
  baseSpeed: number;        // 1 to 10
  baseAcceleration: number; // 1 to 10
  baseHandling: number;     // 1 to 10
  baseNitro: number;        // 1 to 10
  defaultColor: string;
  accentColor: string;
  description: string;
  badge: string;
  topSpeedKmh: number;
}

export interface DailyMission {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  unit: string;
  rewardCoins: number;
  completed: boolean;
  claimed: boolean;
}

export interface PlayerProfile {
  name: string;
  coins: number;
  selectedCarId: string;
  unlockedCars: string[];
  carColors: Record<string, string>;
  carCustomizations: Record<string, CarCustomization>;
  carUpgrades: Record<string, CarUpgrades>;
  highScores: {
    endless: number;
    timeAttack: number;
    coinRush: number;
    policeChase: number;
    trafficChallenge: number;
  };
  bestDistance: number;
  totalDistanceKm: number;
  totalCoinsEarned: number;
  totalRaces: number;
  nearMisses: number;
  policeEvaded: number;
  dailyBonus: {
    lastClaimDate: string; // YYYY-MM-DD
    streak: number;
  };
  luckySpin: {
    lastSpinDate: string; // YYYY-MM-DD
    totalSpins: number;
  };
  dailyMissions: {
    date: string; // YYYY-MM-DD
    missions: DailyMission[];
  };
  settings: {
    soundVolume: number;
    musicVolume: number;
    quality: 'high' | 'medium' | 'low';
    cameraView: CameraView;
    steeringSensitivity: number;
    mobileControlStyle: 'buttons' | 'pedals';
  };
}

export interface RaceResult {
  mode: GameMode;
  distance: number;
  coinsCollected: number;
  nearMisses: number;
  score: number;
  timeSurvivedSeconds: number;
  topSpeedReached: number;
  policeEvadedCount?: number;
  isNewHighScore: boolean;
}

export interface LeaderboardEntry {
  id: string;
  rank: number;
  name: string;
  score: number;
  car: string;
  mode: GameMode;
  date: string;
}

export interface RemotePlayerState {
  id: string;
  name: string;
  carId: string;
  carColor: string;
  x: number;
  z: number;
  speed: number;
  distance: number;
  nitro: boolean;
  rank: number;
}
