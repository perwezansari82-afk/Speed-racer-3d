import {
  CarDefinition,
  CarUpgrades,
  CarCustomization,
  WeatherMode,
  SpoilerStyle,
  WheelStyle,
  DailyMission
} from '../types/game';

export const CARS_CATALOG: CarDefinition[] = [
  {
    id: 'car_venom_gt',
    name: 'Venom GT Roadster',
    category: 'Starter',
    price: 0,
    baseSpeed: 5.5,
    baseAcceleration: 6.0,
    baseHandling: 6.5,
    baseNitro: 5.0,
    defaultColor: '#00d4ff', // Cyan
    accentColor: '#0ea5e9',
    description: 'The iconic agile roadster. Lightweight chassis with crisp handling and excellent cornering stability.',
    badge: 'STARTER CAR',
    topSpeedKmh: 240,
  },
  {
    id: 'car_apex_phantom',
    name: 'Apex Phantom GT',
    category: 'Sports',
    price: 180,
    baseSpeed: 6.8,
    baseAcceleration: 7.0,
    baseHandling: 7.2,
    baseNitro: 6.0,
    defaultColor: '#f97316', // Neon Orange
    accentColor: '#ea580c',
    description: 'Track-tuned sports coupe featuring active aerodynamics, dual rear air diffusers, and rapid gearshifts.',
    badge: 'PERFORMANCE',
    topSpeedKmh: 275,
  },
  {
    id: 'car_crimson_fury',
    name: 'Crimson Fury V10',
    category: 'Supercar',
    price: 450,
    baseSpeed: 8.0,
    baseAcceleration: 8.2,
    baseHandling: 7.8,
    baseNitro: 7.5,
    defaultColor: '#ef4444', // Red
    accentColor: '#991b1b',
    description: 'A roaring mid-engine Italian supercar with extreme low-end torque and blistering straight-line acceleration.',
    badge: 'SUPERCAR',
    topSpeedKmh: 310,
  },
  {
    id: 'car_cyber_neon',
    name: 'Cyber Neon 2077',
    category: 'Concept',
    price: 850,
    baseSpeed: 8.8,
    baseAcceleration: 9.0,
    baseHandling: 8.5,
    baseNitro: 8.8,
    defaultColor: '#a855f7', // Cyber Purple
    accentColor: '#3b82f6',
    description: 'Futuristic hybrid concept with dual vector thrust pods, holographic tailfin, and intense neon underglow.',
    badge: 'CONCEPT',
    topSpeedKmh: 345,
  },
  {
    id: 'car_valkyrie_hyper',
    name: 'Valkyrie Hypercar',
    category: 'Hypercar',
    price: 1500,
    baseSpeed: 9.5,
    baseAcceleration: 9.4,
    baseHandling: 9.0,
    baseNitro: 9.2,
    defaultColor: '#eab308', // Racing Gold
    accentColor: '#ca8a04',
    description: 'Extreme Le Mans endurance-inspired hypercar. Featherweight carbon monocoque and massive aerodynamic downforce.',
    badge: 'HYPERCAR',
    topSpeedKmh: 385,
  },
  {
    id: 'car_shadow_stealth',
    name: 'Shadow Stealth Prototype',
    category: 'Stealth',
    price: 2500,
    baseSpeed: 10.0,
    baseAcceleration: 10.0,
    baseHandling: 9.6,
    baseNitro: 10.0,
    defaultColor: '#18181b', // Obsidian Black
    accentColor: '#06b6d4',
    description: 'Experimental black-ops racing missile. Matte radar-absorbent body panels and jet-turbine nitro booster.',
    badge: 'LEGENDARY',
    topSpeedKmh: 420,
  },
];

export const PAINT_COLORS = [
  { name: 'Neon Cyan', hex: '#00d4ff' },
  { name: 'Speed Orange', hex: '#f97316' },
  { name: 'Crimson Red', hex: '#ef4444' },
  { name: 'Cyber Purple', hex: '#a855f7' },
  { name: 'Acid Lime', hex: '#84cc16' },
  { name: 'Electric Blue', hex: '#3b82f6' },
  { name: 'Solar Yellow', hex: '#eab308' },
  { name: 'Obsidian Matte', hex: '#18181b' },
  { name: 'Pure Snow', hex: '#f8fafc' },
  { name: 'Hot Magenta', hex: '#ec4899' },
  { name: 'Emerald Green', hex: '#10b981' },
  { name: 'Titanium Gunmetal', hex: '#64748b' },
];

export const SPOILER_OPTIONS: { id: SpoilerStyle; name: string; price: number; desc: string }[] = [
  { id: 'none', name: 'Factory Clean', price: 0, desc: 'Sleek aerodynamic stock profile with zero wing drag.' },
  { id: 'lip', name: 'Ducktail Carbon Lip', price: 60, desc: 'Subtle high-speed downforce lip on the rear decklid.' },
  { id: 'gtWing', name: 'GT Circuit Wing', price: 140, desc: 'Aerodynamic carbon racing wing on dual vertical stanchions.' },
  { id: 'cyberFins', name: 'Cyber Stabilizer Fins', price: 220, desc: 'Futuristic twin vertical stabilizers with neon edge glow.' },
  { id: 'extremeCarbon', name: 'Valkyrie Extreme Wing', price: 350, desc: 'Maximized track downforce dual-element carbon wing.' },
];

export const WHEEL_OPTIONS: { id: WheelStyle; name: string; price: number; desc: string }[] = [
  { id: 'sport5', name: '5-Spoke Star Alloy', price: 0, desc: 'Classic lightweight forged star design with open ventilation.' },
  { id: 'mesh12', name: 'GT Radial Multi-Spoke', price: 80, desc: 'Motorsport-spec 12-spoke mesh for maximum structural rigidity.' },
  { id: 'cyberDish', name: 'Cyber Aero Turbodisc', price: 160, desc: 'Solid aerodynamic face that channels brake cooling airflow.' },
  { id: 'concave', name: 'Deep Concave Monoblock', price: 260, desc: 'Ultra-aggressive staggered concave stance for supercars.' },
];

export const WHEEL_COLOR_OPTIONS = [
  { name: 'Polished Chrome', hex: '#d1d5db' },
  { name: 'Obsidian Black', hex: '#1e2124' },
  { name: 'Racing Gold', hex: '#eab308' },
  { name: 'Anodized Cyan', hex: '#06b6d4' },
  { name: 'Flame Red', hex: '#ef4444' },
  { name: 'Burnt Bronze', hex: '#b45309' },
];

export const NEON_UNDERGLOW_OPTIONS = [
  { name: 'Off / None', hex: 'none' },
  { name: 'Electric Cyan', hex: '#00d4ff' },
  { name: 'Sunset Orange', hex: '#f97316' },
  { name: 'Hot Pink / Magenta', hex: '#ec4899' },
  { name: 'Acid Lime', hex: '#84cc16' },
  { name: 'Ultra Violet', hex: '#a855f7' },
  { name: 'Solar Gold', hex: '#facc15' },
];

export const WEATHER_ENVIRONMENTS: {
  id: WeatherMode;
  name: string;
  tagline: string;
  skyColor: string;
  gradient: string;
  features: string[];
}[] = [
  {
    id: 'day',
    name: 'Day Sunny',
    tagline: 'Bright sunlight, blue sky & lush green roadside trees',
    skyColor: '#60a5fa',
    gradient: 'from-sky-500 via-blue-600 to-emerald-600',
    features: ['Crisp blue sky', 'Fluffy procedural clouds', 'Green palms & trees', 'Clear visibility'],
  },
  {
    id: 'night',
    name: 'Night City',
    tagline: 'Dark midnight sky, glowing moon, stars & neon city towers',
    skyColor: '#030712',
    gradient: 'from-slate-950 via-indigo-950 to-cyan-950',
    features: ['Moon & twinkling stars', 'Headlight beams', 'Warm streetlamp cones', 'Glowing skyscrapers'],
  },
  {
    id: 'rain',
    name: 'Rainy Storm',
    tagline: 'Falling rain, wet reflective road & tire splash particles',
    skyColor: '#1e293b',
    gradient: 'from-slate-900 via-cyan-950 to-slate-950',
    features: ['Falling rain particles', 'Water splash spray', 'Wet road reflections', 'Thunder atmosphere'],
  },
  {
    id: 'snow',
    name: 'Snow Blizzard',
    tagline: 'Falling snow, frosty white road verge & frozen winter peaks',
    skyColor: '#94a3b8',
    gradient: 'from-slate-300 via-sky-200 to-indigo-300',
    features: ['Gentle falling snowflakes', 'Snow-covered road shoulders', 'Snowy mountain ridges', 'Winter chill fog'],
  },
  {
    id: 'desert',
    name: 'Desert Dunes',
    tagline: 'Endless golden sand dunes, amber sun & blowing dust haze',
    skyColor: '#d97706',
    gradient: 'from-amber-600 via-orange-600 to-yellow-700',
    features: ['Golden sand dunes', 'Dust storm particles', 'Warm desert sun', 'High-speed straightaways'],
  },
  {
    id: 'forest',
    name: 'Mountain Forest',
    tagline: 'Dense green pines, fresh forest mist & winding canopy route',
    skyColor: '#166534',
    gradient: 'from-emerald-800 via-teal-900 to-slate-900',
    features: ['Dense pine groves', 'Lush mossy shoulders', 'Forest canopy mist', 'Natural wilderness'],
  },
  {
    id: 'ocean',
    name: 'Coastal Ocean',
    tagline: 'Ocean highway bridge, realistic animated water & seaside view',
    skyColor: '#0284c7',
    gradient: 'from-cyan-500 via-blue-600 to-teal-500',
    features: ['Deep blue ocean waves', 'Highway bridge piers', 'Coastal palm trees', 'Salt breeze horizon'],
  },
  {
    id: 'sunset',
    name: 'Neon Sunset',
    tagline: 'Deep purple-orange horizon, long shadows & warm rim light',
    skyColor: '#3b0764',
    gradient: 'from-purple-900 via-pink-700 to-orange-500',
    features: ['Purple & orange sky', 'Golden hour rim lighting', 'Dramatic long shadows', 'Synthwave aura'],
  },
];

export const LUCKY_SPIN_PRIZES = [
  { id: '1', label: '+25 Coins', coins: 25, color: '#0ea5e9' },
  { id: '2', label: '+50 Coins', coins: 50, color: '#f59e0b' },
  { id: '3', label: '+100 Coins', coins: 100, color: '#10b981' },
  { id: '4', label: '+250 Coins', coins: 250, color: '#8b5cf6' },
  { id: '5', label: '+500 Coins', coins: 500, color: '#f97316' },
  { id: '6', label: '+75 Coins', coins: 75, color: '#06b6d4' },
  { id: '7', label: 'JACKPOT +1,000', coins: 1000, color: '#eab308' },
  { id: '8', label: '+150 Coins', coins: 150, color: '#ec4899' },
];

export const UPGRADE_TIER_COSTS = [50, 100, 180, 280, 420];
export const MAX_UPGRADE_LEVEL = 5;

export const DEFAULT_UPGRADES: CarUpgrades = {
  engine: 0,
  speed: 0,
  handling: 0,
  nitro: 0,
};

export const DEFAULT_CUSTOMIZATION: CarCustomization = {
  color: '#00d4ff',
  spoiler: 'none',
  wheelStyle: 'sport5',
  wheelColor: '#d1d5db',
  neonUnderglow: '#00d4ff',
};

export const DAILY_BONUS_AMOUNT = 20;

export function generateDailyMissions(): DailyMission[] {
  return [
    {
      id: 'm_dist',
      title: 'Highway Cruiser',
      description: 'Travel a cumulative 2,500 meters across any game mode.',
      target: 2500,
      current: 0,
      unit: 'M',
      rewardCoins: 80,
      completed: false,
      claimed: false,
    },
    {
      id: 'm_nearmiss',
      title: 'Apex Daredevil',
      description: 'Perform 8 high-speed Near Miss overtakes past traffic cars.',
      target: 8,
      current: 0,
      unit: 'Overtakes',
      rewardCoins: 100,
      completed: false,
      claimed: false,
    },
    {
      id: 'm_coins',
      title: 'Gold Harvester',
      description: 'Collect 35 roadside coins during racing sessions.',
      target: 35,
      current: 0,
      unit: 'Coins',
      rewardCoins: 75,
      completed: false,
      claimed: false,
    },
    {
      id: 'm_speed',
      title: 'Sound Barrier',
      description: 'Reach a top speed of at least 260 KM/H with Nitro boost.',
      target: 260,
      current: 0,
      unit: 'KM/H',
      rewardCoins: 120,
      completed: false,
      claimed: false,
    },
  ];
}
