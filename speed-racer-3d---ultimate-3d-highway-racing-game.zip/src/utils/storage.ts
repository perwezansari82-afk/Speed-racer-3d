import { PlayerProfile, CarUpgrades, CarCustomization } from '../types/game';
import { CARS_CATALOG, DEFAULT_UPGRADES, DEFAULT_CUSTOMIZATION, generateDailyMissions } from './constants';

const STORAGE_KEY = 'speed_racer_3d_profile_v2';

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getDefaultProfile(): PlayerProfile {
  const starterCar = CARS_CATALOG[0];
  const initialColors: Record<string, string> = {};
  const initialCustomizations: Record<string, CarCustomization> = {};
  const initialUpgrades: Record<string, CarUpgrades> = {};

  CARS_CATALOG.forEach((car) => {
    initialColors[car.id] = car.defaultColor;
    initialCustomizations[car.id] = {
      ...DEFAULT_CUSTOMIZATION,
      color: car.defaultColor,
      neonUnderglow: car.defaultColor,
    };
    initialUpgrades[car.id] = { ...DEFAULT_UPGRADES };
  });

  const today = getTodayDateString();

  return {
    name: 'VelocityRacer',
    coins: 100,
    selectedCarId: starterCar.id,
    unlockedCars: [starterCar.id],
    carColors: initialColors,
    carCustomizations: initialCustomizations,
    carUpgrades: initialUpgrades,
    highScores: {
      endless: 0,
      timeAttack: 0,
      coinRush: 0,
      policeChase: 0,
      trafficChallenge: 0,
    },
    bestDistance: 0,
    totalDistanceKm: 0,
    totalCoinsEarned: 100,
    totalRaces: 0,
    nearMisses: 0,
    policeEvaded: 0,
    dailyBonus: {
      lastClaimDate: '',
      streak: 0,
    },
    luckySpin: {
      lastSpinDate: '',
      totalSpins: 0,
    },
    dailyMissions: {
      date: today,
      missions: generateDailyMissions(),
    },
    settings: {
      soundVolume: 0.8,
      musicVolume: 0.5,
      quality: 'high',
      cameraView: 'chase',
      steeringSensitivity: 1.0,
      mobileControlStyle: 'buttons',
    },
  };
}

export function loadProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('speed_racer_3d_profile_v1');
    if (!raw) return getDefaultProfile();
    const parsed = JSON.parse(raw);
    const def = getDefaultProfile();
    const today = getTodayDateString();

    const carColors = { ...def.carColors, ...(parsed.carColors || {}) };
    const carUpgrades = { ...def.carUpgrades, ...(parsed.carUpgrades || {}) };
    const unlockedCars = Array.isArray(parsed.unlockedCars) && parsed.unlockedCars.length > 0
      ? Array.from(new Set([CARS_CATALOG[0].id, ...parsed.unlockedCars]))
      : [CARS_CATALOG[0].id];

    // Build car customizations
    const carCustomizations: Record<string, CarCustomization> = {};
    CARS_CATALOG.forEach((c) => {
      carCustomizations[c.id] = {
        ...DEFAULT_CUSTOMIZATION,
        color: carColors[c.id] || c.defaultColor,
        neonUnderglow: carColors[c.id] || c.defaultColor,
        ...(parsed.carCustomizations?.[c.id] || {}),
      };
    });

    // Check daily missions date reset
    let dailyMissions = parsed.dailyMissions;
    if (!dailyMissions || dailyMissions.date !== today) {
      dailyMissions = {
        date: today,
        missions: generateDailyMissions(),
      };
    }

    return {
      ...def,
      ...parsed,
      carColors,
      carCustomizations,
      carUpgrades,
      unlockedCars,
      highScores: { ...def.highScores, ...(parsed.highScores || {}) },
      settings: { ...def.settings, ...(parsed.settings || {}) },
      dailyBonus: { ...def.dailyBonus, ...(parsed.dailyBonus || {}) },
      luckySpin: { ...def.luckySpin, ...(parsed.luckySpin || {}) },
      dailyMissions,
    };
  } catch (err) {
    console.error('Error loading save profile:', err);
    return getDefaultProfile();
  }
}

export function saveProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (err) {
    console.error('Error saving profile:', err);
  }
}

export function isDailyBonusAvailable(lastClaimDate: string): boolean {
  if (!lastClaimDate) return true;
  const today = getTodayDateString();
  return lastClaimDate !== today;
}

export function isLuckySpinAvailable(lastSpinDate: string): boolean {
  if (!lastSpinDate) return true;
  const today = getTodayDateString();
  return lastSpinDate !== today;
}

export function getTimeUntilNextMidnight(): { hours: number; minutes: number; seconds: number } {
  const now = new Date();
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
  const diffMs = Math.max(0, tomorrow.getTime() - now.getTime());

  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

  return { hours, minutes, seconds };
}
